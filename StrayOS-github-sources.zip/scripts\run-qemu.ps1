$ErrorActionPreference = "Stop"

wsl sh -lc "cd /mnt/f/StrayOS/build/minimal && ./run-qemu.sh"
