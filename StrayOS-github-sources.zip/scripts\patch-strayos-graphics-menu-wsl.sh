#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
SOURCE_IMG="${SOURCE_IMG:-$PROJECT_DIR/disks/strayos-5g.img}"
BOOT_IMG="${BOOT_IMG:-$PROJECT_DIR/disks/StrayOS-bootable-5g.img}"

patch_one() {
  local image="$1" mount_dir="$2" loop_dev part partuuid

  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup_one() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup_one RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi

  sudo mount "$part" "$mount_dir"
  partuuid="$(sudo blkid -s PARTUUID -o value "$part" 2>/dev/null || true)"

  sudo rm -f \
    "$mount_dir/etc/X11/xorg.conf.d/10-strayos-fbdev.conf" \
    "$mount_dir/etc/X11/xorg.conf.d/10-strayos-auto.conf"

  if [[ -n "$partuuid" && -d "$mount_dir/boot/grub" ]]; then
    cat <<EOF | sudo tee "$mount_dir/boot/grub/grub.cfg" >/dev/null
set timeout=7
set default=0

menuentry "StrayOS 5GB bootable disk" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=8 init=/init console=tty0 panic=0
}

menuentry "StrayOS safe graphics (nomodeset)" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=8 init=/init console=tty0 nomodeset panic=0
}

menuentry "StrayOS debug console" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=8 init=/init console=ttyS0 console=tty0 panic=0 ignore_loglevel
}
EOF
  fi

  sudo sync
  cleanup_one
  trap - RETURN
}

patch_one "$SOURCE_IMG" /tmp/strayos-graphics-menu-source
patch_one "$BOOT_IMG" /tmp/strayos-graphics-menu-boot

sha256sum "$BOOT_IMG" > "$BOOT_IMG.sha256"
echo "Patched StrayOS graphics boot menu and removed forced Xorg driver."
