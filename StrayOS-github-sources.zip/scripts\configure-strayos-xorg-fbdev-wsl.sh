#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-xorg-fix}"
PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR/proc"; then sudo umount "$MOUNT_DIR/proc"; fi
  if mountpoint -q "$MOUNT_DIR/sys"; then sudo umount "$MOUNT_DIR/sys"; fi
  if mountpoint -q "$MOUNT_DIR/dev/pts"; then sudo umount "$MOUNT_DIR/dev/pts"; fi
  if mountpoint -q "$MOUNT_DIR/dev"; then sudo umount "$MOUNT_DIR/dev"; fi
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup EXIT

sudo mount --bind /dev "$MOUNT_DIR/dev"
sudo mount -t devpts devpts "$MOUNT_DIR/dev/pts"
sudo mount -t proc proc "$MOUNT_DIR/proc"
sudo mount -t sysfs sysfs "$MOUNT_DIR/sys"
sudo cp /etc/resolv.conf "$MOUNT_DIR/etc/resolv.conf"

sudo chroot "$MOUNT_DIR" apt-get update
sudo chroot "$MOUNT_DIR" apt-get install -y \
  xserver-xorg-video-fbdev \
  xserver-xorg-video-vesa \
  dbus-x11 \
  xterm \
  openbox

sudo mkdir -p "$MOUNT_DIR/etc/X11/xorg.conf.d" "$MOUNT_DIR/root"
sudo tee "$MOUNT_DIR/etc/X11/xorg.conf.d/10-strayos-fbdev.conf" >/dev/null <<'EOF'
Section "Device"
    Identifier "StrayOS Framebuffer"
    Driver "fbdev"
    Option "fbdev" "/dev/fb0"
EndSection

Section "Screen"
    Identifier "Screen0"
    Device "StrayOS Framebuffer"
    DefaultDepth 24
EndSection
EOF

sudo tee "$MOUNT_DIR/root/.xinitrc" >/dev/null <<'EOF'
#!/bin/sh
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
export XDG_RUNTIME_DIR=/run/user/0
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"

dbus-daemon --system --fork 2>/dev/null || true

if command -v cinnamon-session >/dev/null 2>&1; then
  exec dbus-launch --exit-with-session cinnamon-session
fi

if command -v openbox-session >/dev/null 2>&1; then
  xterm &
  exec openbox-session
fi

exec xterm
EOF
sudo chmod +x "$MOUNT_DIR/root/.xinitrc"

cat > "$PROJECT_DIR/build/disk/run-qemu-cinnamon.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"

qemu-system-x86_64 \
  -m 3072M \
  -kernel "$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage" \
  -append "root=/dev/sda rw init=/init console=tty0 vga=791 nomodeset panic=-1 strayos.gui=1" \
  -drive "file=$PROJECT_DIR/disks/strayos-5g.img,format=raw,if=ide,index=0,media=disk" \
  -display sdl \
  -device VGA
EOF
chmod +x "$PROJECT_DIR/build/disk/run-qemu-cinnamon.sh"

sudo sync
echo "Configured Xorg fbdev fallback for StrayOS."
