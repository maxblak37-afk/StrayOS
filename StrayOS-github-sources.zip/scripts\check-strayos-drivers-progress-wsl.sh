#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-drivers-progress-check}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

echo "--- size ---"
df -h "$MOUNT_DIR"
sudo ls -lh "$IMG" "$MOUNT_DIR/boot/vmlinuz-strayos" "$MOUNT_DIR/swapfile"

echo "--- firmware ---"
test -d "$MOUNT_DIR/lib/firmware"
sudo find "$MOUNT_DIR/lib/firmware" -maxdepth 2 -type f | wc -l

echo "--- modules ---"
sudo find "$MOUNT_DIR/lib/modules" -type f -name '*.ko*' | wc -l
sudo find "$MOUNT_DIR/lib/modules" -type f \( -name 'iwlwifi.ko*' -o -name 'rtw88*.ko*' -o -name 'rtw89*.ko*' -o -name 'ath9k*.ko*' -o -name 'brcmfmac.ko*' -o -name 'btusb.ko*' \) -print | sed -n '1,80p'

echo "--- commands ---"
for path in \
  "$MOUNT_DIR/usr/local/sbin/strayos-install-progress" \
  "$MOUNT_DIR/usr/local/sbin/strayos-install-gui" \
  "$MOUNT_DIR/usr/local/bin/strayos-installer-gui" \
  "$MOUNT_DIR/usr/bin/nmcli" \
  "$MOUNT_DIR/usr/sbin/rfkill"; do
  test -x "$path"
  echo "OK $path"
done

grep -q 'zenity --progress' "$MOUNT_DIR/usr/local/sbin/strayos-install-gui"
grep -q 'Copying StrayOS files' "$MOUNT_DIR/usr/local/sbin/strayos-install-progress"

echo "--- installed firmware packages ---"
sudo chroot "$MOUNT_DIR" sh -lc 'dpkg-query -W firmware-iwlwifi firmware-realtek firmware-atheros firmware-brcm80211 firmware-amd-graphics firmware-misc-nonfree network-manager wpasupplicant rfkill 2>/dev/null || true'

echo "Drivers/progress installer check: OK"
