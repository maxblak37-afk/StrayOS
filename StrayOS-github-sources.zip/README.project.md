# StrayOS

StrayOS is a from-scratch Linux distribution project.

Initial target:
- Architecture: x86_64
- Boot mode: UEFI first, BIOS later if needed
- First goal: bootable minimal command-line system in a virtual machine
- Package stack: Debian-style `apt` + `dpkg`
- Later goals: package manager, installer, desktop profile, release ISO

Project layout:
- `docs/` - design notes, roadmap, decisions
- `scripts/` - build automation
- `sources/` - downloaded upstream source archives
- `build/` - temporary build output
- `rootfs/` - assembled target filesystem
- `iso/` - bootable ISO output
- `packages/` - built binary packages

Downloaded starting sources are stored in `sources/`, with checksums in
`sources/SHA256SUMS`.

The practical first milestone is not a beautiful desktop. It is a tiny system
that boots, mounts a root filesystem, starts init, and gives a shell.

Current milestone status: minimal StrayOS boots in QEMU with Linux 7.0.4 and a
BusyBox initramfs. See `docs/BUILD_AND_RUN.md`.
