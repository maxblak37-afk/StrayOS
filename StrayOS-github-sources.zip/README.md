﻿# StrayOS Sources

This folder contains the lightweight source files for GitHub: scripts, documentation, and build/patch tools.

Do not commit generated images here. Upload ISO/IMG files as GitHub Release assets.

Current release image:
- File: F:\StrayOS\iso\StrayOS-full-amd64.iso
- Size: 1.16 GB
- SHA256: 6e4c9dc1bb1627c1925907f297724cdfcce61ceba1eae7d39e319d9fe781eb39

Main source folders:
- docs/ - project notes and build/run docs
- scripts/ - build, patch, installer, QEMU, and verification scripts
- tools/ - ISO patching tools used from the Codex workspace
- release/ - release notes and asset list
