$ErrorActionPreference = "Stop"

wsl sh -lc "cd /mnt/f/StrayOS/build/full-kernel && ./run-qemu.sh"
