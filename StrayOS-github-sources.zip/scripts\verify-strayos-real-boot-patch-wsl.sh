#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
KERNEL="${KERNEL:-/mnt/f/StrayOS/build/full-kernel/strayos-full-source-bzImage}"
LOG="${LOG:-/mnt/f/StrayOS/build/logs/strayos-real-boot-patch.log}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-real-boot-verify}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"
PARTUUID="$(sudo blkid -s PARTUUID -o value "${LOOP_DEV}p1")"

grep -q 'console=tty0 nomodeset panic=0' "$MOUNT_DIR/boot/grub/grub.cfg"
grep -q 'while true' "$MOUNT_DIR/init"
grep -q 'Shell exited. Restarting StrayOS console' "$MOUNT_DIR/init"
grep -q "root=PARTUUID=$PARTUUID" "$MOUNT_DIR/boot/grub/grub.cfg"

sudo umount "$MOUNT_DIR"
sudo losetup -d "$LOOP_DEV"
LOOP_DEV=""

rm -f "$LOG"
set +e
timeout 180 qemu-system-x86_64 \
  -m 4096M \
  -smp 2 \
  -kernel "$KERNEL" \
  -append "root=PARTUUID=$PARTUUID rw rootwait rootdelay=8 init=/init console=ttyS0 nomodeset panic=0" \
  -drive "file=$IMG,format=raw,if=ide" \
  -serial stdio \
  -display none \
  >"$LOG" 2>&1
STATUS=$?
set -e

if grep -q 'root@strayos' "$LOG" && grep -q 'StrayOS base is still Debian APT' "$LOG"; then
  echo "Real boot patch verified with 4GB RAM: OK"
  exit 0
fi

echo "Boot verification did not reach shell. QEMU status: $STATUS" >&2
tail -120 "$LOG" >&2 || true
exit 1
