#!/usr/bin/env bash
set -euo pipefail

for image in /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img /mnt/f/StrayOS/disks/strayos-5g.img; do
  mount_dir="/tmp/strayos-fullwipe-progress-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then part="$loop_dev"; fi
  sudo mount "$part" "$mount_dir"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/sbin/strayos-install-progress" >/dev/null
#!/bin/sh
set -u

INPUT_FILE="${1:-}"
LOG="${2:-/tmp/strayos-install-progress.log}"

[ -n "$INPUT_FILE" ] && [ -f "$INPUT_FILE" ] || {
  echo "# Missing installer input file"
  echo 100
  exit 1
}

mode="$(sed -n '1p' "$INPUT_FILE" 2>/dev/null)"
target_disk=""
target_size=0
if [ "$mode" = "1" ]; then
  target_disk="$(sed -n '2p' "$INPUT_FILE" 2>/dev/null)"
  if [ -b "$target_disk" ]; then
    target_size="$(blockdev --getsize64 "$target_disk" 2>/dev/null || echo 0)"
  fi
fi

rm -f "$LOG"
echo "# Preparing installer"
echo 2

(strayos-install < "$INPUT_FILE" > "$LOG" 2>&1) &
pid="$!"

last=2
while kill -0 "$pid" 2>/dev/null; do
  if grep -q 'Overwriting the whole disk with zeroes' "$LOG" 2>/dev/null; then
    stage="Full wiping selected disk"
    copied="$(grep -ao '[0-9][0-9]* bytes' "$LOG" 2>/dev/null | tail -1 | awk '{print $1}')"
    if [ -n "${copied:-}" ] && [ "$target_size" -gt 0 ] 2>/dev/null; then
      pct=$((10 + (copied * 25 / target_size)))
      [ "$pct" -lt 10 ] && pct=10
      [ "$pct" -gt 35 ] && pct=35
    else
      pct=$((last + 1))
      [ "$pct" -gt 20 ] && pct=20
    fi
  elif grep -q 'Removing old signatures' "$LOG" 2>/dev/null; then
    stage="Removing old disk signatures"
    pct=6
  elif grep -q 'mkfs.ext4' "$LOG" 2>/dev/null; then
    stage="Formatting target"
    pct=40
  elif grep -q 'Copying StrayOS' "$LOG" 2>/dev/null; then
    stage="Copying StrayOS files"
    pct=$((last + 2))
    [ "$pct" -lt 45 ] && pct=45
    [ "$pct" -gt 78 ] && pct=78
  elif grep -q 'Installing GRUB' "$LOG" 2>/dev/null; then
    stage="Installing bootloader"
    pct=88
  elif grep -q 'Install complete' "$LOG" 2>/dev/null; then
    stage="Finishing"
    pct=98
  else
    stage="Working"
    pct=$((last + 1))
    [ "$pct" -gt 5 ] && pct=5
  fi

  last="$pct"
  echo "# $stage"
  echo "$pct"
  sleep 1
done

wait "$pid"
status="$?"

if [ "$status" -eq 0 ] && grep -q 'Install complete' "$LOG"; then
  echo "# Installation complete"
  echo 100
  exit 0
fi

echo "# Installation failed"
echo 100
exit "${status:-1}"
EOF
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-install-progress"
  sudo sync
  cleanup
  trap - RETURN
done

sha256sum /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img > /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img.sha256
sha256sum /mnt/f/StrayOS/disks/strayos-5g.img > /mnt/f/StrayOS/disks/strayos-5g.img.sha256
echo "Patched full-wipe progress percentage."
