#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
images=(
  "$PROJECT_DIR/disks/strayos-5g.img"
  "$PROJECT_DIR/disks/StrayOS-bootable-5g.img"
)

write_apps() {
  local mount_dir="$1"

  cat <<'PY' | sudo tee "$mount_dir/usr/local/bin/strayos-system-info" >/dev/null
#!/usr/bin/env python3
import os, platform, subprocess, textwrap

FEATURES = [
    ("Desktop", "LightDM login + StrayOS GNOME safe Xorg session"),
    ("Browser", "Firefox ESR built in"),
    ("Installer", "GNOME app: Install StrayOS"),
    ("Network", "Wi-Fi GUI, saved profiles, autoconnect"),
    ("Recovery", "Boot-time recovery initramfs with e2fsck"),
    ("Packages", "Debian APT + StrayOS Package Manager"),
    ("Updates", "Обновление системы server: 78.17.6.198"),
]

COMMANDS = [
    "strayos-lightdm", "strayos-gnome", "strayos-browser",
    "strayos-wifi-gui", "strayos-package-manager", "strayos-updater",
    "strayos-installer-gui", "strayos-repair-boot", "strayos-poweroff",
]

def sh(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return ""

def info_text():
    os_release = sh("grep '^PRETTY_NAME=' /etc/os-release | cut -d= -f2- | tr -d '\"'") or "StrayOS"
    apt = sh("apt --version | head -1") or "APT unavailable"
    user = sh("id -un") or "unknown"
    lang = os.environ.get("LANG", "")
    ip = sh("hostname -I | awk '{print $1}'") or "offline"
    return f"""
StrayOS System Info

OS: {os_release}
Kernel: {platform.release()}
User: {user}
Language: {lang}
Network IP: {ip}
APT: {apt}
Update server: http://78.17.6.198/strayos/

Features:
""" + "\n".join(f"  - {k}: {v}" for k, v in FEATURES) + "\n\nUseful commands:\n" + "\n".join(f"  - {c}" for c in COMMANDS)

def gui(text):
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk
    win = Gtk.Window(title="StrayOS System Info")
    win.set_default_size(760, 560)
    win.connect("destroy", Gtk.main_quit)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
    box.set_border_width(12)
    title = Gtk.Label()
    title.set_markup("<b>StrayOS System Info</b>")
    title.set_xalign(0)
    box.pack_start(title, False, False, 0)
    view = Gtk.TextView()
    view.set_editable(False)
    view.set_monospace(True)
    view.get_buffer().set_text(text)
    scroll = Gtk.ScrolledWindow()
    scroll.add(view)
    box.pack_start(scroll, True, True, 0)
    close = Gtk.Button(label="Close")
    close.connect("clicked", lambda *_: Gtk.main_quit())
    box.pack_start(close, False, False, 0)
    win.add(box)
    win.show_all()
    Gtk.main()

text = info_text()
if os.environ.get("DISPLAY"):
    try:
        gui(text)
    except Exception:
        print(text)
else:
    print(text)
PY

  cat <<'PY' | sudo tee "$mount_dir/usr/local/bin/strayos-updater" >/dev/null
#!/usr/bin/env python3
import os, subprocess, threading

SERVER = "78.17.6.198"
LINKS = {
    "Manifest": f"http://{SERVER}/strayos/updates/manifest.json",
    "Latest version": f"http://{SERVER}/strayos/updates/latest.txt",
    "ISO SHA256": f"http://{SERVER}/strayos/updates/StrayOS-full-amd64.iso.sha256",
    "APT mirror": f"http://{SERVER}/strayos/apt/",
    "Releases": f"http://{SERVER}/strayos/releases/",
}

def run(cmd, cb):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    for line in p.stdout:
        cb(line)
    p.wait()
    cb(f"\n[exit {p.returncode}]\n")

def main():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib
    win = Gtk.Window(title=f"Обновление системы (ip:{SERVER})")
    win.set_default_size(820, 560)
    win.connect("destroy", Gtk.main_quit)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
    box.set_border_width(12)
    header = Gtk.Label()
    header.set_markup(f"<b>Обновление системы</b>  ip:{SERVER}")
    header.set_xalign(0)
    box.pack_start(header, False, False, 0)
    link_text = "\n".join(f"{k}: {v}" for k, v in LINKS.items())
    links = Gtk.Label(label=link_text)
    links.set_selectable(True)
    links.set_xalign(0)
    box.pack_start(links, False, False, 0)
    view = Gtk.TextView()
    view.set_editable(False)
    view.set_monospace(True)
    buf = view.get_buffer()
    scroll = Gtk.ScrolledWindow()
    scroll.add(view)
    box.pack_start(scroll, True, True, 0)
    buttons = Gtk.Box(spacing=8)
    box.pack_start(buttons, False, False, 0)
    def append(s):
        def _():
            end = buf.get_end_iter()
            buf.insert(end, s)
            view.scroll_to_iter(buf.get_end_iter(), 0.0, False, 0, 0)
            return False
        GLib.idle_add(_)
    def start(cmd):
        append(f"\n$ {cmd}\n")
        threading.Thread(target=run, args=(cmd, append), daemon=True).start()
    checks = {
        "Check StrayOS server": f"wget -qO- {LINKS['Latest version']} || curl -fsSL {LINKS['Latest version']} || true",
        "APT update": "apt-get update",
        "APT upgrade": "apt-get -y upgrade",
        "Show links": "printf '%s\\n' '" + link_text.replace("'", "'\\''") + "'",
    }
    for label, cmd in checks.items():
        b = Gtk.Button(label=label)
        b.connect("clicked", lambda _, c=cmd: start(c))
        buttons.pack_start(b, False, False, 0)
    win.add(box)
    win.show_all()
    Gtk.main()

if os.geteuid() != 0:
    env = f"DISPLAY={os.environ.get('DISPLAY','')} XAUTHORITY={os.environ.get('XAUTHORITY','')} XDG_RUNTIME_DIR={os.environ.get('XDG_RUNTIME_DIR','')}"
    if subprocess.call(f"command -v pkexec >/dev/null 2>&1", shell=True) == 0:
        os.execvp("pkexec", ["pkexec", "env"] + env.split() + [__file__])
    os.execvp("xterm", ["xterm", "-e", "sudo", __file__])
main()
PY

  cat <<'PY' | sudo tee "$mount_dir/usr/local/bin/strayos-package-manager" >/dev/null
#!/usr/bin/env python3
import os, re, subprocess, threading

SIZE_RE = re.compile(r"\[([0-9.]+)\s*([kMGT]?B)\]")
MULT = {"B":1, "kB":1024, "MB":1024**2, "GB":1024**3, "TB":1024**4}

def size_to_bytes(s):
    m = re.match(r"([0-9.]+)\s*([kMGT]?B)", s.strip())
    if not m: return 0
    return int(float(m.group(1)) * MULT.get(m.group(2), 1))

def human(n):
    for unit in ["B","KB","MB","GB"]:
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024

def main():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib

    win = Gtk.Window(title="StrayOS Package Manager")
    win.set_default_size(980, 640)
    win.connect("destroy", Gtk.main_quit)
    root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
    root.set_border_width(12)

    top = Gtk.Box(spacing=8)
    search = Gtk.Entry()
    search.set_placeholder_text("Search APT packages, example: vlc, gimp, chromium, libreoffice")
    btn_search = Gtk.Button(label="Search")
    btn_update = Gtk.Button(label="APT update")
    top.pack_start(search, True, True, 0)
    top.pack_start(btn_search, False, False, 0)
    top.pack_start(btn_update, False, False, 0)
    root.pack_start(top, False, False, 0)

    store = Gtk.ListStore(str, str)
    tree = Gtk.TreeView(model=store)
    for i, title in enumerate(["Package", "Description"]):
        col = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=i)
        col.set_resizable(True)
        tree.append_column(col)
    scroll_results = Gtk.ScrolledWindow()
    scroll_results.set_vexpand(True)
    scroll_results.add(tree)
    root.pack_start(scroll_results, True, True, 0)

    actions = Gtk.Box(spacing=8)
    btn_install = Gtk.Button(label="Install selected")
    status = Gtk.Label(label="Ready")
    status.set_xalign(0)
    progress = Gtk.ProgressBar()
    actions.pack_start(btn_install, False, False, 0)
    actions.pack_start(progress, True, True, 0)
    root.pack_start(actions, False, False, 0)
    root.pack_start(status, False, False, 0)

    log = Gtk.TextView()
    log.set_editable(False)
    log.set_monospace(True)
    logbuf = log.get_buffer()
    logscroll = Gtk.ScrolledWindow()
    logscroll.set_size_request(-1, 190)
    logscroll.add(log)
    root.pack_start(logscroll, False, True, 0)

    def append(s):
        def _():
            end = logbuf.get_end_iter()
            logbuf.insert(end, s)
            log.scroll_to_iter(logbuf.get_end_iter(), 0.0, False, 0, 0)
            return False
        GLib.idle_add(_)

    def set_status(s):
        GLib.idle_add(lambda: (status.set_text(s), False)[1])

    def pulse():
        progress.pulse()
        return True

    pulse_id = None
    def start_pulse():
        nonlocal pulse_id
        if pulse_id is None:
            pulse_id = GLib.timeout_add(120, pulse)
    def stop_pulse():
        nonlocal pulse_id
        if pulse_id is not None:
            GLib.source_remove(pulse_id)
            pulse_id = None
        progress.set_fraction(0)

    def search_packages(_=None):
        term = search.get_text().strip()
        if not term:
            return
        store.clear()
        set_status(f"Searching: {term}")
        def worker():
            out = subprocess.getoutput(f"apt-cache search --names-only {subprocess.list2cmdline([term])}")
            def fill():
                for line in out.splitlines()[:500]:
                    if " - " in line:
                        pkg, desc = line.split(" - ", 1)
                        store.append([pkg.strip(), desc.strip()])
                status.set_text(f"Found {len(store)} packages")
                return False
            GLib.idle_add(fill)
        threading.Thread(target=worker, daemon=True).start()

    def selected_pkg():
        sel = tree.get_selection()
        model, itr = sel.get_selected()
        return model[itr][0] if itr else ""

    def run_cmd(cmd, label):
        append(f"\n$ {cmd}\n")
        set_status(label)
        start_pulse()
        def worker():
            total = 0
            got = 0
            p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                append(line)
                if "Need to get" in line:
                    m = re.search(r"Need to get ([0-9.,]+) ([kMGT]?B)", line)
                    if m:
                        total = size_to_bytes(m.group(1).replace(",", ".") + " " + m.group(2))
                if line.startswith("Get:"):
                    for n, u in SIZE_RE.findall(line):
                        got += size_to_bytes(n + " " + u)
                    if total:
                        GLib.idle_add(progress.set_fraction, min(got / total, 1.0))
                        set_status(f"Downloading: {human(got)} / {human(total)}")
                if line.startswith("Fetched "):
                    set_status(line.strip())
            rc = p.wait()
            GLib.idle_add(stop_pulse)
            set_status("Done" if rc == 0 else f"Failed: exit {rc}")
        threading.Thread(target=worker, daemon=True).start()

    def install_selected(_=None):
        pkg = selected_pkg()
        if not pkg:
            set_status("Select a package first")
            return
        run_cmd(f"apt-get install -y {pkg}", f"Installing {pkg}")

    btn_search.connect("clicked", search_packages)
    search.connect("activate", search_packages)
    btn_update.connect("clicked", lambda *_: run_cmd("apt-get update", "Updating APT lists"))
    btn_install.connect("clicked", install_selected)

    win.add(root)
    win.show_all()
    Gtk.main()

if os.geteuid() != 0:
    env = f"DISPLAY={os.environ.get('DISPLAY','')} XAUTHORITY={os.environ.get('XAUTHORITY','')} XDG_RUNTIME_DIR={os.environ.get('XDG_RUNTIME_DIR','')}"
    if subprocess.call("command -v pkexec >/dev/null 2>&1", shell=True) == 0:
        os.execvp("pkexec", ["pkexec", "env"] + env.split() + [__file__])
    os.execvp("xterm", ["xterm", "-e", "sudo", __file__])
main()
PY

  sudo chmod +x "$mount_dir/usr/local/bin/strayos-system-info" \
    "$mount_dir/usr/local/bin/strayos-updater" \
    "$mount_dir/usr/local/bin/strayos-package-manager"

  sudo mkdir -p "$mount_dir/usr/share/applications"
  cat <<'EOF' | sudo tee "$mount_dir/usr/share/applications/strayos-system-info.desktop" >/dev/null
[Desktop Entry]
Type=Application
Name=StrayOS System Info
Comment=Show StrayOS version, features, commands, and update server
Exec=/usr/local/bin/strayos-system-info
Icon=computer
Terminal=false
Categories=System;
StartupNotify=true
EOF

  cat <<'EOF' | sudo tee "$mount_dir/usr/share/applications/strayos-updater.desktop" >/dev/null
[Desktop Entry]
Type=Application
Name=Обновление системы
Comment=Check StrayOS updates from 78.17.6.198 and run APT upgrades
Exec=/usr/local/bin/strayos-updater
Icon=system-software-update
Terminal=false
Categories=System;Settings;
StartupNotify=true
EOF

  cat <<'EOF' | sudo tee "$mount_dir/usr/share/applications/strayos-package-manager.desktop" >/dev/null
[Desktop Entry]
Type=Application
Name=StrayOS Package Manager
Comment=Search and install Debian APT applications
Exec=/usr/local/bin/strayos-package-manager
Icon=system-software-install
Terminal=false
Categories=System;PackageManager;
StartupNotify=true
EOF

  # Keep the old About command useful while adding the new GUI app.
  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-about" >/dev/null
#!/bin/sh
exec /usr/local/bin/strayos-system-info "$@"
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-about"

  if ! sudo grep -q 'strayos-package-manager' "$mount_dir/init"; then
    sudo sed -i '/strayos-browser/a echo "  strayos-package-manager"\
  echo "  strayos-updater"\
  echo "  strayos-system-info"' "$mount_dir/init" 2>/dev/null || true
  fi

  sudo python3 -m py_compile "$mount_dir/usr/local/bin/strayos-system-info" \
    "$mount_dir/usr/local/bin/strayos-updater" \
    "$mount_dir/usr/local/bin/strayos-package-manager"
}

patch_image() {
  local image="$1" mount_dir loop_dev part
  mount_dir="/tmp/strayos-system-tools-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  sleep 1
  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  sudo mount "$part" "$mount_dir"
  write_apps "$mount_dir"
  sudo test -f "$mount_dir/usr/share/applications/strayos-package-manager.desktop"
  sudo test -f "$mount_dir/usr/share/applications/strayos-updater.desktop"
  sudo grep -q '78.17.6.198' "$mount_dir/usr/local/bin/strayos-updater"
  sudo grep -q 'apt-cache search' "$mount_dir/usr/local/bin/strayos-package-manager"
  sudo sync
  cleanup
  trap - RETURN
}

for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum "$PROJECT_DIR/disks/StrayOS-bootable-5g.img" > "$PROJECT_DIR/disks/StrayOS-bootable-5g.img.sha256"
sha256sum "$PROJECT_DIR/disks/strayos-5g.img" > "$PROJECT_DIR/disks/strayos-5g.img.sha256"
echo "Patched StrayOS system info, updater, and APT package manager apps."
