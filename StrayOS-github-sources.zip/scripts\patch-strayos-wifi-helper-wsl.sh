#!/usr/bin/env bash
set -euo pipefail

for image in /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img /mnt/f/StrayOS/disks/strayos-5g.img; do
  mount_dir="/tmp/strayos-wifi-helper-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then part="$loop_dev"; fi
  sudo mount "$part" "$mount_dir"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-wifi" >/dev/null
#!/bin/sh
set +e

echo "Starting StrayOS Wi-Fi helper..."
strayos-start-udev 2>/dev/null || true

for mod in iwlwifi iwldvm iwlmvm ath9k ath9k_htc ath10k_pci brcmfmac b43 rt2800usb mt7601u rtw88_core rtw88_pci rtw88_usb rtw89_core rtw89_pci btusb; do
  modprobe "$mod" 2>/dev/null || true
done

rfkill unblock all 2>/dev/null || true
mkdir -p /run/NetworkManager

if ! pgrep NetworkManager >/dev/null 2>&1; then
  NetworkManager --no-daemon >/tmp/strayos-networkmanager.log 2>&1 &
  sleep 3
fi

echo
echo "Network devices:"
nmcli device 2>/dev/null || true
echo

if command -v nmtui >/dev/null 2>&1; then
  echo "Opening network menu..."
  exec nmtui
fi

echo "Available Wi-Fi networks:"
nmcli device wifi list 2>/dev/null || true
echo
echo "Connect example:"
echo "  nmcli device wifi connect \"SSID\" password \"PASSWORD\""
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-wifi"

  if ! grep -q 'echo "  strayos-wifi"' "$mount_dir/init"; then
    sudo sed -i '/echo "  strayos-diag"/a echo "  strayos-wifi"' "$mount_dir/init" 2>/dev/null || true
  fi

  sudo sync
  cleanup
  trap - RETURN
done

sha256sum /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img > /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img.sha256
sha256sum /mnt/f/StrayOS/disks/strayos-5g.img > /mnt/f/StrayOS/disks/strayos-5g.img.sha256
echo "Added strayos-wifi helper."
