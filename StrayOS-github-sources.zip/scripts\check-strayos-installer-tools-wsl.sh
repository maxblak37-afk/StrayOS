#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-installer-tools}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR/proc"; then sudo umount "$MOUNT_DIR/proc"; fi
  if mountpoint -q "$MOUNT_DIR/sys"; then sudo umount "$MOUNT_DIR/sys"; fi
  if mountpoint -q "$MOUNT_DIR/dev/pts"; then sudo umount "$MOUNT_DIR/dev/pts"; fi
  if mountpoint -q "$MOUNT_DIR/dev"; then sudo umount "$MOUNT_DIR/dev"; fi
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup EXIT

sudo mount --bind /dev "$MOUNT_DIR/dev"
sudo mount -t devpts devpts "$MOUNT_DIR/dev/pts"
sudo mount -t proc proc "$MOUNT_DIR/proc"
sudo mount -t sysfs sysfs "$MOUNT_DIR/sys"

echo "--- commands ---"
for command in lsblk parted sfdisk mkfs.ext4 grub-install update-grub grub-mkconfig rsync findmnt blkid mount umount; do
  printf "%-14s " "$command"
  sudo chroot "$MOUNT_DIR" command -v "$command" || true
done

echo "--- packages ---"
for package in grub-pc grub-common parted e2fsprogs util-linux rsync dosfstools; do
  printf "%-14s " "$package"
  sudo chroot "$MOUNT_DIR" dpkg-query -W -f='${Status} ${Version}\n' "$package" 2>/dev/null || echo not-installed
done
