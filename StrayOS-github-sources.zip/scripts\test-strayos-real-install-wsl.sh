#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
TEST_DIR="$PROJECT_DIR/build/installer-test"
TARGET_IMG="$TEST_DIR/strayos-install-target.img"
LOG="$TEST_DIR/install-qemu.log"
MOUNT_DIR="/tmp/strayos-installed-test"

KERNEL="/root/strayos-img-iso/iso-tree/strayos/vmlinuz"
INITRD="/root/strayos-img-iso/iso-tree/strayos/initramfs.cpio.gz"

mkdir -p "$TEST_DIR"
rm -f "$TARGET_IMG" "$LOG"
qemu-img create -f raw "$TARGET_IMG" 8G

echo "Created test install disk: $TARGET_IMG"
echo "Running real StrayOS install inside QEMU. This can take several minutes..."

set +e
(
  sleep 85
  printf 'strayos-install\n'
  sleep 3
  printf '1\n'
  sleep 3
  printf '/dev/sda\n'
  sleep 3
  printf 'ERASE /dev/sda\n'
  sleep 8
  printf 'INSTALL GRUB /dev/sda\n'
  sleep 720
  printf 'poweroff -f\n'
) | timeout 1200 qemu-system-x86_64 \
  -m 8192M \
  -smp 4 \
  -kernel "$KERNEL" \
  -initrd "$INITRD" \
  -append 'init=/init console=ttyS0 panic=-1 nomodeset' \
  -drive "file=$TARGET_IMG,format=raw,if=ide" \
  -serial stdio \
  -display none \
  >"$LOG" 2>&1
QEMU_STATUS=$?
set -e

echo "QEMU exited with status: $QEMU_STATUS"
echo "Install log: $LOG"

if ! grep -q 'Install complete' "$LOG"; then
  echo "Install did not reach completion. Last log lines:" >&2
  tail -80 "$LOG" >&2 || true
  exit 1
fi

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

LOOP_DEV="$(sudo losetup --find --show --partscan "$TARGET_IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

PART="${LOOP_DEV}p1"
sudo mount "$PART" "$MOUNT_DIR"

test -f "$MOUNT_DIR/boot/vmlinuz-strayos"
test -f "$MOUNT_DIR/boot/grub/grub.cfg"
test -f "$MOUNT_DIR/etc/os-release"
grep -q 'PRETTY_NAME="StrayOS"' "$MOUNT_DIR/etc/os-release"
grep -q 'StrayOS' "$MOUNT_DIR/boot/grub/grub.cfg"

echo "--- installed StrayOS check ---"
cat "$MOUNT_DIR/etc/os-release"
echo "--- grub.cfg ---"
sed -n '1,80p' "$MOUNT_DIR/boot/grub/grub.cfg"
echo "--- target disk ---"
sudo lsblk "$LOOP_DEV" -o NAME,SIZE,TYPE,FSTYPE,LABEL,MOUNTPOINTS

echo "Real installer test passed."
