#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
BOOT_IMG="${BOOT_IMG:-$PROJECT_DIR/disks/StrayOS-bootable-5g.img}"
SOURCE_IMG="${SOURCE_IMG:-$PROJECT_DIR/disks/strayos-5g.img}"

patch_one() {
  local image="$1" mount_dir="$2" loop_dev part partuuid

  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup_one() {
    if mountpoint -q "$mount_dir/dev/pts"; then sudo umount "$mount_dir/dev/pts"; fi
    if mountpoint -q "$mount_dir/dev"; then sudo umount "$mount_dir/dev"; fi
    if mountpoint -q "$mount_dir/proc"; then sudo umount "$mount_dir/proc"; fi
    if mountpoint -q "$mount_dir/sys"; then sudo umount "$mount_dir/sys"; fi
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup_one RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi

  sudo mount "$part" "$mount_dir"
  partuuid="$(sudo blkid -s PARTUUID -o value "$part" 2>/dev/null || true)"

  if [[ -n "$partuuid" && -d "$mount_dir/boot/grub" ]]; then
    cat <<EOF | sudo tee "$mount_dir/boot/grub/grub.cfg" >/dev/null
set timeout=7
set default=0

menuentry "StrayOS 5GB bootable disk" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=8 init=/init console=tty0 nomodeset panic=0
}

menuentry "StrayOS hardware graphics (experimental)" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=8 init=/init console=tty0 panic=0
}

menuentry "StrayOS debug console" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=8 init=/init console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel
}
EOF
  fi

  sudo mkdir -p "$mount_dir/usr/local/bin" "$mount_dir/usr/local/sbin"

  if [[ -x "$mount_dir/usr/bin/apt-get" ]]; then
    sudo mount --bind /dev "$mount_dir/dev"
    sudo mount -t devpts devpts "$mount_dir/dev/pts" 2>/dev/null || true
    sudo mount -t proc proc "$mount_dir/proc"
    sudo mount -t sysfs sysfs "$mount_dir/sys"
    sudo cp /etc/resolv.conf "$mount_dir/etc/resolv.conf"
    sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get update
    sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get install -y \
      zenity \
      openbox \
      xterm \
      x11-xserver-utils \
      dbus-x11
  fi

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/sbin/strayos-install-gui" >/dev/null
#!/bin/sh
set -u

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

die() {
  zenity --error --width=520 --title="StrayOS Installer" --text="$1" 2>/dev/null || echo "ERROR: $1" >&2
  exit 1
}

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Missing command: $1"
}

need_cmd zenity
need_cmd xterm
need_cmd lsblk
need_cmd strayos-install

[ "$(id -u)" = "0" ] || die "Run installer as root."

zenity --warning \
  --width=620 \
  --title="StrayOS Installer" \
  --text="This is a real installer. It can erase a whole disk or format one selected partition.\n\nCheck size and model carefully. Windows disks can be destroyed if you choose the wrong target." \
  2>/dev/null || exit 1

mode="$(zenity --list --radiolist \
  --width=620 --height=260 \
  --title="StrayOS Installer" \
  --text="Choose install mode" \
  --column="" --column="Mode" --column="Meaning" \
  TRUE "Whole disk" "Erase a disk, create one StrayOS ext4 partition, install GRUB" \
  FALSE "Selected partition" "Format only one selected partition/volume" \
  2>/dev/null)" || exit 1

[ -n "$mode" ] || exit 1

run_script="/tmp/strayos-gui-install-run.sh"
rm -f "$run_script"

if [ "$mode" = "Whole disk" ]; then
  disk="$(
    lsblk -dn -P -o PATH,SIZE,MODEL,TYPE |
    while IFS= read -r line; do
      eval "$line"
      [ "${TYPE:-}" = "disk" ] || continue
      case "${PATH:-}" in /dev/sr*|/dev/loop*) continue ;; esac
      printf '%s\n%s\n%s\n' "$PATH" "${SIZE:-?}" "${MODEL:-unknown}"
    done |
    zenity --list --width=760 --height=360 \
      --title="Select target disk" \
      --text="Choose the disk to erase completely" \
      --column="Device" --column="Size" --column="Model" \
      2>/dev/null
  )" || exit 1

  [ -n "$disk" ] || exit 1

  confirm="$(zenity --entry --width=620 --title="Confirm erase" \
    --text="To erase $disk and install StrayOS, type exactly:\n\nERASE $disk" 2>/dev/null)" || exit 1
  [ "$confirm" = "ERASE $disk" ] || die "Confirmation did not match."

  confirm_grub="$(zenity --entry --width=620 --title="Confirm bootloader" \
    --text="To install GRUB bootloader to $disk, type exactly:\n\nINSTALL GRUB $disk" 2>/dev/null)" || exit 1
  [ "$confirm_grub" = "INSTALL GRUB $disk" ] || die "Bootloader confirmation did not match."

  cat > "$run_script" <<EOF_RUN
#!/bin/sh
printf '1\n$disk\nERASE $disk\nINSTALL GRUB $disk\n' | strayos-install
echo
echo "Installer finished. Press Enter to close."
read _
EOF_RUN
else
  part="$(
    lsblk -pn -P -o PATH,SIZE,FSTYPE,LABEL,TYPE,MOUNTPOINTS |
    while IFS= read -r line; do
      eval "$line"
      case "${TYPE:-}" in part|lvm) ;;
        *) continue ;;
      esac
      case "${PATH:-}" in /dev/loop*|/dev/sr*) continue ;; esac
      printf '%s\n%s\n%s\n%s\n%s\n' "$PATH" "${SIZE:-?}" "${FSTYPE:-}" "${LABEL:-}" "${MOUNTPOINTS:-}"
    done |
    zenity --list --width=860 --height=420 \
      --title="Select target partition" \
      --text="Choose the partition/volume to format as StrayOS root" \
      --column="Device" --column="Size" --column="FS" --column="Label" --column="Mounted at" \
      2>/dev/null
  )" || exit 1

  [ -n "$part" ] || exit 1

  confirm="$(zenity --entry --width=620 --title="Confirm format" \
    --text="To format $part as StrayOS root, type exactly:\n\nFORMAT $part" 2>/dev/null)" || exit 1
  [ "$confirm" = "FORMAT $part" ] || die "Confirmation did not match."

  parent="$(lsblk -no PKNAME "$part" 2>/dev/null | head -1)"
  boot_disk=""
  install_grub="no"
  if [ -n "$parent" ]; then
    boot_disk="/dev/$parent"
    if zenity --question --width=560 --title="Bootloader" \
      --text="Install GRUB bootloader to parent disk?\n\n$boot_disk" 2>/dev/null; then
      install_grub="yes"
    fi
  fi

  if [ "$install_grub" = "yes" ]; then
    confirm_grub="$(zenity --entry --width=620 --title="Confirm bootloader" \
      --text="To install GRUB bootloader to $boot_disk, type exactly:\n\nINSTALL GRUB $boot_disk" 2>/dev/null)" || exit 1
    [ "$confirm_grub" = "INSTALL GRUB $boot_disk" ] || die "Bootloader confirmation did not match."
    cat > "$run_script" <<EOF_RUN
#!/bin/sh
printf '2\n$part\nFORMAT $part\nyes\nINSTALL GRUB $boot_disk\n' | strayos-install
echo
echo "Installer finished. Press Enter to close."
read _
EOF_RUN
  else
    cat > "$run_script" <<EOF_RUN
#!/bin/sh
printf '2\n$part\nFORMAT $part\nno\n' | strayos-install
echo
echo "Installer finished. Press Enter to close."
read _
EOF_RUN
  fi
fi

chmod +x "$run_script"
exec xterm -fa Monospace -fs 12 -geometry 120x36+30+30 -title "StrayOS Installer Log" -e "$run_script"
EOF
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-install-gui"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-installer-gui-session" >/dev/null
#!/bin/sh
export LIBGL_ALWAYS_SOFTWARE=1
export XDG_SESSION_TYPE=x11
xsetroot -solid '#1f1f1f' 2>/dev/null || true
openbox >/tmp/strayos-installer-openbox.log 2>&1 &
sleep 1
/usr/local/sbin/strayos-install-gui
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-installer-gui-session"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-installer-gui" >/dev/null
#!/bin/sh
swapon /swapfile 2>/dev/null || true
strayos-start-udev 2>/dev/null || true
mkdir -p /run/dbus /run/user/0 /tmp
chmod 700 /run/user/0 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true

if [ -n "${DISPLAY:-}" ]; then
  exec /usr/local/sbin/strayos-install-gui
fi

echo "Starting StrayOS graphical installer..."
exec dbus-run-session -- startx /usr/local/bin/strayos-installer-gui-session -- :0 vt2 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-installer-gui"

  if ! grep -q 'echo "  strayos-installer-gui"' "$mount_dir/init"; then
    sudo sed -i '/echo "  strayos-install"/a echo "  strayos-installer-gui"' "$mount_dir/init"
  fi

  sudo sync
  cleanup_one
  trap - RETURN
}

patch_one "$BOOT_IMG" /tmp/strayos-gui-installer-boot
patch_one "$SOURCE_IMG" /tmp/strayos-gui-installer-source

sha256sum "$BOOT_IMG" > "$BOOT_IMG.sha256"
echo "Patched main boot mode and graphical installer."
echo "Updated: $BOOT_IMG"
