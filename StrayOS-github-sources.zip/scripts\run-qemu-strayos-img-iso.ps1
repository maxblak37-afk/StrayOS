$ErrorActionPreference = "Stop"

wsl sh -lc "qemu-system-x86_64 -m 8192M -smp 4 -cdrom /mnt/f/StrayOS/iso/StrayOS-base-gnome-debian-apt-amd64.iso -boot d -display sdl -vga std"
