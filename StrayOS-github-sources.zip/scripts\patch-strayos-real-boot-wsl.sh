#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
SOURCE_IMG="${SOURCE_IMG:-/mnt/f/StrayOS/disks/strayos-5g.img}"

patch_one() {
  local image="$1" mount_dir="$2" loop_dev part partuuid

  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"

  cleanup_one() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup_one RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi

  sudo mount "$part" "$mount_dir"
  partuuid="$(sudo blkid -s PARTUUID -o value "$part" 2>/dev/null || true)"

  if [[ -f "$mount_dir/boot/grub/grub.cfg" && -n "$partuuid" ]]; then
    cat <<EOF | sudo tee "$mount_dir/boot/grub/grub.cfg" >/dev/null
set timeout=5
set default=0

menuentry "StrayOS 5GB bootable disk" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=8 init=/init console=tty0 nomodeset panic=0
}

menuentry "StrayOS debug console" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=8 init=/init console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel
}
EOF
  fi

  cat <<'EOF' | sudo tee "$mount_dir/init" >/dev/null
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TERM=linux
export LANG=C.UTF-8

mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
mkdir -p /dev/pts /run /tmp /root /run/user/0
mount -t devpts devpts /dev/pts 2>/dev/null || true
chmod 1777 /tmp 2>/dev/null || true
chmod 700 /run/user/0 2>/dev/null || true
hostname strayos 2>/dev/null || true

ip link set lo up 2>/dev/null || true
ip link set eth0 up 2>/dev/null || true
dhclient -1 eth0 2>/dev/null || true

show_banner() {
  clear 2>/dev/null || true
  cat /etc/issue 2>/dev/null || echo "StrayOS"
  echo "Kernel: $(uname -r)"
  echo "Disk: 5 GB persistent ext4 image"
  echo
  echo "StrayOS base is still Debian APT:"
  apt --version 2>/dev/null || true
  echo
  echo "Try:"
  echo "  neofetch"
  echo "  apt-get check"
  echo "  strayos-gnome"
  echo "  strayos-install-help"
  echo "  strayos-install"
  echo
  echo "GNOME is manual, not autostarted."
  echo "Power off: poweroff -f"
  echo
}

if grep -q 'strayos.autotest=1' /proc/cmdline 2>/dev/null; then
  show_banner
  echo "[autotest] identity:"
  cat /etc/os-release
  echo
  echo "[autotest] apt:"
  apt --version
  echo
  echo "[autotest] neofetch:"
  neofetch --version
  echo
  echo "[autotest] packages:"
  dpkg-query -W -f='${binary:Package}\n' gnome-shell gnome-session yaru-theme-gtk yaru-theme-icon gnome-shell-extension-dashtodock neofetch
  echo
  poweroff -f
fi

cd /root || cd /

while true; do
  show_banner

  if grep -q 'console=ttyS0' /proc/cmdline 2>/dev/null; then
    /bin/busybox cttyhack /bin/bash -l || /bin/bash -l </dev/console >/dev/console 2>&1 || /bin/sh </dev/console >/dev/console 2>&1
  else
    /bin/busybox setsid /bin/bash -l </dev/tty1 >/dev/tty1 2>&1 || \
      /bin/bash -l </dev/console >/dev/console 2>&1 || \
      /bin/sh </dev/console >/dev/console 2>&1
  fi

  echo "Shell exited. Restarting StrayOS console..." >/dev/console 2>&1 || true
  sleep 1
done
EOF

  sudo chmod +x "$mount_dir/init"
  sudo sync
  cleanup_one
  trap - RETURN
}

patch_one "$IMG" /tmp/strayos-real-boot-img
patch_one "$SOURCE_IMG" /tmp/strayos-real-boot-source

sha256sum "$IMG" > "$IMG.sha256"
echo "Patched real-PC boot behavior in:"
echo "  $IMG"
echo "  $SOURCE_IMG"
