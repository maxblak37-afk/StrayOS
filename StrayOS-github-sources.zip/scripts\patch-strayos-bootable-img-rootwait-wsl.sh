#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-rootwait-patch}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  sudo losetup -d "$LOOP_DEV" || true
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

sudo sed -i \
  -e 's/rw init=\/init/rw rootwait rootdelay=5 init=\/init/g' \
  -e 's/rootdelay=5 rootwait/rootwait rootdelay=5/g' \
  "$MOUNT_DIR/boot/grub/grub.cfg"

sudo sync
sudo grep -n 'linux /boot/vmlinuz-strayos' "$MOUNT_DIR/boot/grub/grub.cfg"

cleanup
trap - EXIT

sha256sum "$IMG" > "$IMG.sha256"
echo "Patched rootwait in $IMG"
