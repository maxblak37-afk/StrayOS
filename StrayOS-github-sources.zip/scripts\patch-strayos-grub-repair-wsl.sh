#!/usr/bin/env bash
set -euo pipefail

for image in /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img /mnt/f/StrayOS/disks/strayos-5g.img; do
  mount_dir="/tmp/strayos-grub-repair-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir/dev/pts"; then sudo umount "$mount_dir/dev/pts"; fi
    if mountpoint -q "$mount_dir/dev"; then sudo umount "$mount_dir/dev"; fi
    if mountpoint -q "$mount_dir/proc"; then sudo umount "$mount_dir/proc"; fi
    if mountpoint -q "$mount_dir/sys"; then sudo umount "$mount_dir/sys"; fi
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then part="$loop_dev"; fi
  sudo mount "$part" "$mount_dir"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/sbin/strayos-repair-boot" >/dev/null
#!/bin/bash
set -euo pipefail

TARGET_MOUNT="/mnt/strayos-repair"

die() { echo "ERROR: $*" >&2; exit 1; }
say() { printf "\n==> %s\n" "$*"; }

need_root() {
  [[ "$(id -u)" -eq 0 ]] || die "Run as root."
}

confirm_exact() {
  local expected="$1" answer
  echo
  echo "To continue, type exactly:"
  echo "  $expected"
  read -r answer
  [[ "$answer" == "$expected" ]] || die "Confirmation did not match. Aborted."
}

parent_disk_for_partition() {
  local part="$1" pk
  pk="$(lsblk -no PKNAME "$part" 2>/dev/null | head -1 || true)"
  [[ -n "$pk" ]] || return 1
  echo "/dev/$pk"
}

write_grub_cfg() {
  local target="$1" root_part="$2" uuid partuuid
  uuid="$(blkid -s UUID -o value "$root_part")"
  partuuid="$(blkid -s PARTUUID -o value "$root_part" 2>/dev/null || true)"
  [[ -n "$uuid" ]] || die "Could not read UUID for $root_part."

  mkdir -p "$target/boot/grub"
  cat > "$target/boot/grub/grub.cfg" <<EOF_GRUB
set timeout=7
set default=0

insmod part_msdos
insmod part_gpt
insmod ext2
search --no-floppy --fs-uuid --set=root $uuid

menuentry "StrayOS" {
    search --no-floppy --fs-uuid --set=root $uuid
    linux /boot/vmlinuz-strayos root=UUID=$uuid rw rootwait rootdelay=8 init=/init console=tty0 nomodeset panic=0
}

menuentry "StrayOS hardware graphics (experimental)" {
    search --no-floppy --fs-uuid --set=root $uuid
    linux /boot/vmlinuz-strayos root=UUID=$uuid rw rootwait rootdelay=8 init=/init console=tty0 panic=0
}

menuentry "StrayOS debug console" {
    search --no-floppy --fs-uuid --set=root $uuid
    linux /boot/vmlinuz-strayos root=UUID=$uuid rw rootwait rootdelay=8 init=/init console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel
}
EOF_GRUB

  cat > "$target/etc/fstab" <<EOF_FSTAB
UUID=$uuid / ext4 defaults 0 1
proc /proc proc defaults 0 0
sysfs /sys sysfs defaults 0 0
devpts /dev/pts devpts defaults 0 0
tmpfs /tmp tmpfs mode=1777 0 0
/swapfile none swap sw 0 0
EOF_FSTAB

  echo "Root UUID: $uuid"
  [[ -n "$partuuid" ]] && echo "Root PARTUUID: $partuuid"
}

main() {
  need_root
  say "StrayOS boot repair"
  echo "Detected disks and partitions:"
  lsblk -o NAME,SIZE,TYPE,FSTYPE,LABEL,MOUNTPOINTS,MODEL
  echo

  read -rp "Installed StrayOS root partition, example /dev/sda1: " root_part
  [[ -b "$root_part" ]] || die "$root_part is not a block device."

  boot_disk="$(parent_disk_for_partition "$root_part" || true)"
  if [[ -z "$boot_disk" ]]; then
    read -rp "Boot disk for GRUB, example /dev/sda: " boot_disk
  else
    echo "Parent boot disk appears to be: $boot_disk"
    read -rp "Boot disk for GRUB [$boot_disk]: " answer
    [[ -n "${answer:-}" ]] && boot_disk="$answer"
  fi
  [[ -b "$boot_disk" ]] || die "$boot_disk is not a block device."

  confirm_exact "REPAIR GRUB $boot_disk"

  mkdir -p "$TARGET_MOUNT"
  if mountpoint -q "$TARGET_MOUNT"; then umount "$TARGET_MOUNT"; fi
  mount "$root_part" "$TARGET_MOUNT"
  trap 'umount "$TARGET_MOUNT" 2>/dev/null || true' EXIT

  mkdir -p "$TARGET_MOUNT"/{dev,proc,sys,run,tmp,boot}
  chmod 1777 "$TARGET_MOUNT/tmp" 2>/dev/null || true

  if [[ ! -f "$TARGET_MOUNT/boot/vmlinuz-strayos" && -f /boot/vmlinuz-strayos ]]; then
    cp /boot/vmlinuz-strayos "$TARGET_MOUNT/boot/vmlinuz-strayos"
  fi
  [[ -f "$TARGET_MOUNT/boot/vmlinuz-strayos" ]] || die "Missing /boot/vmlinuz-strayos on installed system."

  write_grub_cfg "$TARGET_MOUNT" "$root_part"

  say "Installing GRUB to $boot_disk"
  grub-install --target=i386-pc --boot-directory="$TARGET_MOUNT/boot" --recheck "$boot_disk"

  sync
  umount "$TARGET_MOUNT"
  trap - EXIT
  say "Boot repair complete."
  echo "Now reboot and boot from $boot_disk."
}

main "$@"
EOF
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-repair-boot"

  # Make future installs use UUID search and a rechecked GRUB install.
  sudo perl -0pi -e 's/set timeout=5\nset default=0\n\nmenuentry "StrayOS" \{\n    linux \/boot\/vmlinuz-strayos root=UUID=\$uuid rw init=\/init console=tty0 nomodeset panic=-1\n\}\n\nmenuentry "StrayOS debug console" \{\n    linux \/boot\/vmlinuz-strayos root=UUID=\$uuid rw init=\/init console=ttyS0 console=tty0 nomodeset panic=-1\n\}/set timeout=7\nset default=0\n\ninsmod part_msdos\ninsmod part_gpt\ninsmod ext2\nsearch --no-floppy --fs-uuid --set=root \$uuid\n\nmenuentry "StrayOS" {\n    search --no-floppy --fs-uuid --set=root \$uuid\n    linux \/boot\/vmlinuz-strayos root=UUID=\$uuid rw rootwait rootdelay=8 init=\/init console=tty0 nomodeset panic=0\n}\n\nmenuentry "StrayOS hardware graphics (experimental)" {\n    search --no-floppy --fs-uuid --set=root \$uuid\n    linux \/boot\/vmlinuz-strayos root=UUID=\$uuid rw rootwait rootdelay=8 init=\/init console=tty0 panic=0\n}\n\nmenuentry "StrayOS debug console" {\n    search --no-floppy --fs-uuid --set=root \$uuid\n    linux \/boot\/vmlinuz-strayos root=UUID=\$uuid rw rootwait rootdelay=8 init=\/init console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel\n}/s' "$mount_dir/usr/local/sbin/strayos-install"
  sudo sed -i 's/grub-install --target=i386-pc --boot-directory="$target\/boot" "$boot_disk"/grub-install --target=i386-pc --boot-directory="$target\/boot" --recheck "$boot_disk"/' "$mount_dir/usr/local/sbin/strayos-install"

  if ! grep -q 'echo "  strayos-repair-boot"' "$mount_dir/init"; then
    sudo sed -i '/echo "  strayos-installer-gui"/a echo "  strayos-repair-boot"' "$mount_dir/init" 2>/dev/null || true
  fi

  sudo sync
  cleanup
  trap - RETURN
done

sha256sum /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img > /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img.sha256
sha256sum /mnt/f/StrayOS/disks/strayos-5g.img > /mnt/f/StrayOS/disks/strayos-5g.img.sha256
echo "Added StrayOS GRUB repair and hardened future installs."
