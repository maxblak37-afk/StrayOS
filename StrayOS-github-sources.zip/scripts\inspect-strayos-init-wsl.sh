#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-init-inspect}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  sudo losetup -d "$LOOP_DEV" || true
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"
echo "--- file ---"
sudo file "$MOUNT_DIR/init"
echo "--- ls ---"
sudo ls -l "$MOUNT_DIR/init" "$MOUNT_DIR/bin/sh" "$MOUNT_DIR/bin/bash" 2>/dev/null || true
echo "--- init head ---"
sudo sed -n '1,220p' "$MOUNT_DIR/init" || true
