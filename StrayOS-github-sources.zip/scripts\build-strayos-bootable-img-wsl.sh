#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
SOURCE_IMG="${SOURCE_IMG:-$PROJECT_DIR/disks/strayos-5g.img}"
OUT_IMG="${OUT_IMG:-$PROJECT_DIR/disks/StrayOS-bootable-5g.img}"
KERNEL="${KERNEL:-$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage}"
WORK_DIR="${WORK_DIR:-/tmp/strayos-bootable-img}"
SRC_MOUNT="$WORK_DIR/source"
DST_MOUNT="$WORK_DIR/target"

if [[ ! -f "$SOURCE_IMG" ]]; then
  echo "Missing source image: $SOURCE_IMG" >&2
  exit 1
fi

if [[ ! -f "$KERNEL" ]]; then
  echo "Missing kernel: $KERNEL" >&2
  exit 1
fi

for cmd in qemu-img parted partprobe losetup mkfs.ext4 rsync grub-install blkid; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "Missing command: $cmd" >&2
    exit 1
  }
done

sudo mkdir -p "$SRC_MOUNT" "$DST_MOUNT"

cleanup() {
  if mountpoint -q "$DST_MOUNT/dev"; then sudo umount "$DST_MOUNT/dev"; fi
  if mountpoint -q "$DST_MOUNT/proc"; then sudo umount "$DST_MOUNT/proc"; fi
  if mountpoint -q "$DST_MOUNT/sys"; then sudo umount "$DST_MOUNT/sys"; fi
  if mountpoint -q "$DST_MOUNT"; then sudo umount "$DST_MOUNT"; fi
  if mountpoint -q "$SRC_MOUNT"; then sudo umount "$SRC_MOUNT"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

if mountpoint -q "$SRC_MOUNT"; then sudo umount "$SRC_MOUNT"; fi
if mountpoint -q "$DST_MOUNT"; then sudo umount "$DST_MOUNT"; fi

rm -f "$OUT_IMG"
qemu-img create -f raw "$OUT_IMG" 5G

parted -s "$OUT_IMG" mklabel msdos
parted -s "$OUT_IMG" mkpart primary ext4 1MiB 100%
parted -s "$OUT_IMG" set 1 boot on

LOOP_DEV="$(sudo losetup --find --show --partscan "$OUT_IMG")"
sleep 2
PART="${LOOP_DEV}p1"

sudo mkfs.ext4 -F -L STRAYOS_ROOT "$PART"

sudo mount -o loop,ro "$SOURCE_IMG" "$SRC_MOUNT"
sudo mount "$PART" "$DST_MOUNT"

sudo rsync -aH --numeric-ids \
  --exclude=/dev/* \
  --exclude=/proc/* \
  --exclude=/sys/* \
  --exclude=/run/* \
  --exclude=/tmp/* \
  --exclude=/mnt/* \
  --exclude=/media/* \
  --exclude=/lost+found \
  "$SRC_MOUNT"/ "$DST_MOUNT"/

sudo mkdir -p "$DST_MOUNT"/{dev,proc,sys,run,tmp,mnt,media,boot,boot/grub}
sudo chmod 1777 "$DST_MOUNT/tmp"
sudo cp "$KERNEL" "$DST_MOUNT/boot/vmlinuz-strayos"

UUID="$(sudo blkid -s UUID -o value "$PART")"
PARTUUID="$(sudo blkid -s PARTUUID -o value "$PART")"
cat <<EOF | sudo tee "$DST_MOUNT/etc/fstab" >/dev/null
UUID=$UUID / ext4 defaults 0 1
proc /proc proc defaults 0 0
sysfs /sys sysfs defaults 0 0
devpts /dev/pts devpts defaults 0 0
tmpfs /tmp tmpfs mode=1777 0 0
EOF

cat <<EOF | sudo tee "$DST_MOUNT/boot/grub/grub.cfg" >/dev/null
serial --unit=0 --speed=115200
terminal_input console serial
terminal_output console serial

set timeout=5
set default=0

menuentry "StrayOS 5GB bootable disk" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$PARTUUID rw rootwait rootdelay=8 init=/init console=tty0 nomodeset panic=0
}

menuentry "StrayOS debug console" {
    linux /boot/vmlinuz-strayos root=PARTUUID=$PARTUUID rw rootwait rootdelay=8 init=/init console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel
}
EOF

sudo grub-install \
  --target=i386-pc \
  --boot-directory="$DST_MOUNT/boot" \
  --modules="part_msdos ext2 normal linux biosdisk" \
  "$LOOP_DEV"

sudo sync
cleanup
trap - EXIT

sha256sum "$OUT_IMG" > "$OUT_IMG.sha256"
ls -lh "$OUT_IMG" "$OUT_IMG.sha256"
echo "Built bootable StrayOS image for low-RAM boot: $OUT_IMG"
