#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
WORK_DIR="${WORK_DIR:-$HOME/strayos-ubuntu-gnome-iso}"
SUITE="${SUITE:-jammy}"
MIRROR="${MIRROR:-http://archive.ubuntu.com/ubuntu}"
SECURITY_MIRROR="${SECURITY_MIRROR:-http://security.ubuntu.com/ubuntu}"
ROOTFS="$WORK_DIR/rootfs"
ISO_TREE="$WORK_DIR/iso-tree"
OUT_DIR="$PROJECT_DIR/iso"
LOG_DIR="$PROJECT_DIR/build/logs"
ISO_NAME="${ISO_NAME:-StrayOS-GNOME-Ubuntu-$SUITE-amd64.iso}"
ISO_PATH="$OUT_DIR/$ISO_NAME"

mkdir -p "$WORK_DIR" "$OUT_DIR" "$LOG_DIR"

cleanup_mounts() {
  for target in "$ROOTFS/run" "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/dev/pts" "$ROOTFS/dev"; do
    if mountpoint -q "$target"; then
      sudo umount "$target" || true
    fi
  done
}
trap cleanup_mounts EXIT

if [[ ! -d "$ROOTFS/bin" ]]; then
  sudo rm -rf "$ROOTFS"
  sudo debootstrap --arch=amd64 "$SUITE" "$ROOTFS" "$MIRROR" 2>&1 | tee "$LOG_DIR/strayos-ubuntu-debootstrap.log"
fi

sudo tee "$ROOTFS/etc/apt/sources.list" >/dev/null <<EOF
deb $MIRROR $SUITE main restricted universe multiverse
deb $MIRROR $SUITE-updates main restricted universe multiverse
deb $SECURITY_MIRROR $SUITE-security main restricted universe multiverse
EOF

sudo rm -f "$ROOTFS/etc/resolv.conf"
sudo tee "$ROOTFS/etc/resolv.conf" >/dev/null <<'EOF'
nameserver 1.1.1.1
nameserver 8.8.8.8
EOF
sudo mount --bind /dev "$ROOTFS/dev"
sudo mount -t devpts devpts "$ROOTFS/dev/pts"
sudo mount -t sysfs sysfs "$ROOTFS/sys"
sudo mount -t proc proc "$ROOTFS/proc"
sudo mount -t tmpfs tmpfs "$ROOTFS/run"

sudo tee "$ROOTFS/usr/sbin/policy-rc.d" >/dev/null <<'EOF'
#!/bin/sh
exit 101
EOF
sudo chmod +x "$ROOTFS/usr/sbin/policy-rc.d"

sudo chroot "$ROOTFS" /bin/bash -lc "export DEBIAN_FRONTEND=noninteractive; apt-get update"

sudo chroot "$ROOTFS" /bin/bash -lc "export DEBIAN_FRONTEND=noninteractive; apt-get install -y --no-install-recommends \
  linux-generic \
  casper \
  laptop-detect \
  os-prober \
  network-manager \
  systemd-sysv \
  sudo \
  nano \
  less \
  curl \
  wget \
  ca-certificates \
  dbus-x11 \
  xterm \
  ubuntu-desktop-minimal \
  ubuntu-session \
  gnome-shell-extension-ubuntu-dock \
  yaru-theme-gtk \
  yaru-theme-icon \
  yaru-theme-sound \
  gnome-session-flashback \
  lightdm \
  gdm3" 2>&1 | tee "$LOG_DIR/strayos-ubuntu-gnome-install.log"

sudo chroot "$ROOTFS" /bin/bash -lc "export DEBIAN_FRONTEND=noninteractive; apt-get install -y \
  ubuntu-wallpapers \
  fonts-ubuntu \
  language-pack-en \
  language-pack-ru \
  gnome-terminal \
  nautilus" 2>&1 | tee -a "$LOG_DIR/strayos-ubuntu-gnome-install.log"

sudo tee "$ROOTFS/etc/casper.conf" >/dev/null <<'EOF'
export USERNAME="stray"
export USERFULLNAME="StrayOS Live User"
export HOST="strayos"
export BUILD_SYSTEM="Ubuntu"
EOF

sudo tee "$ROOTFS/etc/hostname" >/dev/null <<'EOF'
strayos
EOF

sudo tee "$ROOTFS/etc/hosts" >/dev/null <<'EOF'
127.0.0.1 localhost
127.0.1.1 strayos
EOF

sudo tee "$ROOTFS/etc/os-release" >/dev/null <<'EOF'
PRETTY_NAME="StrayOS GNOME"
NAME="StrayOS"
VERSION_ID="0.1-ubuntu-gnome"
VERSION="0.1 Ubuntu GNOME"
ID=strayos
ID_LIKE="ubuntu debian"
HOME_URL="https://example.invalid/strayos"
SUPPORT_URL="https://example.invalid/strayos"
BUG_REPORT_URL="https://example.invalid/strayos"
PRIVACY_POLICY_URL="https://example.invalid/strayos"
VERSION_CODENAME=jammy
UBUNTU_CODENAME=jammy
EOF

sudo tee "$ROOTFS/etc/lsb-release" >/dev/null <<'EOF'
DISTRIB_ID=StrayOS
DISTRIB_RELEASE=0.1
DISTRIB_CODENAME=jammy
DISTRIB_DESCRIPTION="StrayOS GNOME"
EOF

sudo tee "$ROOTFS/etc/issue" >/dev/null <<'EOF'
StrayOS GNOME Live \n \l

EOF

sudo mkdir -p "$ROOTFS/etc/dconf/db/local.d" "$ROOTFS/etc/dconf/profile"
sudo tee "$ROOTFS/etc/dconf/profile/user" >/dev/null <<'EOF'
user-db:user
system-db:local
EOF
sudo tee "$ROOTFS/etc/dconf/db/local.d/00-strayos-ubuntu-session" >/dev/null <<'EOF'
[org/gnome/desktop/interface]
gtk-theme='Yaru'
icon-theme='Yaru'
cursor-theme='Yaru'

[org/gnome/shell]
enabled-extensions=['ubuntu-dock@ubuntu.com']
favorite-apps=['org.gnome.Nautilus.desktop', 'org.gnome.Terminal.desktop']

[org/gnome/desktop/background]
picture-options='zoom'
primary-color='#241f31'
secondary-color='#e95420'
EOF

sudo chroot "$ROOTFS" /bin/bash -lc "dconf update || true"

sudo rm -f "$ROOTFS/usr/sbin/policy-rc.d"
sudo chroot "$ROOTFS" /bin/bash -lc "apt-get clean"
sudo rm -rf "$ROOTFS/tmp/"* "$ROOTFS/var/tmp/"* "$ROOTFS/var/lib/apt/lists/"*
sudo truncate -s 0 "$ROOTFS/etc/machine-id" || true
sudo rm -f "$ROOTFS/var/lib/dbus/machine-id" || true

cleanup_mounts
trap - EXIT

rm -rf "$ISO_TREE"
mkdir -p "$ISO_TREE/casper" "$ISO_TREE/boot/grub"

KERNEL="$(ls "$ROOTFS"/boot/vmlinuz-* | sort -V | tail -1)"
INITRD="$(ls "$ROOTFS"/boot/initrd.img-* | sort -V | tail -1)"
cp "$KERNEL" "$ISO_TREE/casper/vmlinuz"
cp "$INITRD" "$ISO_TREE/casper/initrd"

sudo mksquashfs "$ROOTFS" "$ISO_TREE/casper/filesystem.squashfs" \
  -e boot \
  -comp xz \
  -b 1M \
  -noappend 2>&1 | tee "$LOG_DIR/strayos-ubuntu-mksquashfs.log"

sudo du -sx --block-size=1 "$ROOTFS" | cut -f1 > "$ISO_TREE/casper/filesystem.size"
sudo chroot "$ROOTFS" dpkg-query -W --showformat='${Package} ${Version}\n' | sudo tee "$ISO_TREE/casper/filesystem.manifest" >/dev/null

cat > "$ISO_TREE/README.diskdefines" <<EOF
#define DISKNAME  StrayOS GNOME Ubuntu Live
#define TYPE  binary
#define TYPEbinary  1
#define ARCH  amd64
#define ARCHamd64  1
#define DISKNUM  1
#define DISKNUM1  1
#define TOTALNUM  0
#define TOTALNUM0  1
EOF

cat > "$ISO_TREE/boot/grub/grub.cfg" <<'EOF'
set timeout=8
set default=0

menuentry "Try StrayOS GNOME (Ubuntu session)" {
    linux /casper/vmlinuz boot=casper maybe-ubiquity quiet splash ---
    initrd /casper/initrd
}

menuentry "Try StrayOS GNOME (safe graphics)" {
    linux /casper/vmlinuz boot=casper nomodeset quiet splash ---
    initrd /casper/initrd
}

menuentry "Try StrayOS GNOME Flashback style" {
    linux /casper/vmlinuz boot=casper quiet splash ---
    initrd /casper/initrd
}
EOF

grub-mkrescue -o "$ISO_PATH" "$ISO_TREE" 2>&1 | tee "$LOG_DIR/strayos-ubuntu-grub-mkrescue.log"

sha256sum "$ISO_PATH" > "$ISO_PATH.sha256"
ls -lh "$ISO_PATH" "$ISO_PATH.sha256"
echo "Built ISO: $ISO_PATH"
