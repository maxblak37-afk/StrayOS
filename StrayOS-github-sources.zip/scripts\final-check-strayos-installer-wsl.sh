#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
ISO="${ISO:-/mnt/f/StrayOS/iso/StrayOS-base-gnome-debian-apt-amd64.iso}"
SHA="${SHA:-/mnt/f/StrayOS/iso/StrayOS-base-gnome-debian-apt-amd64.iso.sha256}"
INSTALL_LOG="${INSTALL_LOG:-/mnt/f/StrayOS/build/installer-test/install-qemu.log}"
TEST_IMG="${TEST_IMG:-/mnt/f/StrayOS/build/installer-test/strayos-install-target.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-final-check}"
TEST_MOUNT="${TEST_MOUNT:-/tmp/strayos-final-installed-check}"

sha256sum -c "$SHA"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi
sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup_main() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup_main EXIT

test -f "$ISO"
test -x "$MOUNT_DIR/usr/local/sbin/strayos-install"
test -x "$MOUNT_DIR/usr/local/sbin/strayos-install-help"
grep -q 'install_grub="${install_grub:-yes}"' "$MOUNT_DIR/usr/local/sbin/strayos-install"
test "$(grep -c 'echo "  strayos-install"$' "$MOUNT_DIR/init")" -eq 1
test "$(grep -c 'echo "  strayos-install-help"$' "$MOUNT_DIR/init")" -eq 1

grep -q 'Install complete' "$INSTALL_LOG"

sudo mkdir -p "$TEST_MOUNT"
if mountpoint -q "$TEST_MOUNT"; then
  sudo umount "$TEST_MOUNT"
fi
LOOP_DEV="$(sudo losetup --find --show --partscan "$TEST_IMG")"
cleanup_test() {
  if mountpoint -q "$TEST_MOUNT"; then sudo umount "$TEST_MOUNT"; fi
  sudo losetup -d "$LOOP_DEV" || true
}
trap 'cleanup_test; cleanup_main' EXIT

sudo mount "${LOOP_DEV}p1" "$TEST_MOUNT"
grep -q 'PRETTY_NAME="StrayOS"' "$TEST_MOUNT/etc/os-release"
test -f "$TEST_MOUNT/boot/vmlinuz-strayos"
test -f "$TEST_MOUNT/boot/grub/grub.cfg"
grep -q 'menuentry "StrayOS"' "$TEST_MOUNT/boot/grub/grub.cfg"

echo "Final StrayOS installer check: OK"
echo "ISO: $ISO"
echo "IMG: $IMAGE"
echo "Test installed disk: $TEST_IMG"
