#!/usr/bin/env bash
set -euo pipefail

for image in /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img /mnt/f/StrayOS/disks/strayos-5g.img; do
  mount_dir="/tmp/strayos-apt-clean-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi

  sudo mount "$part" "$mount_dir"

  cat <<'EOF' | sudo tee "$mount_dir/etc/apt/sources.list" >/dev/null
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF
  sudo rm -f "$mount_dir/etc/apt/sources.list.d/strayos-firmware.list"
  sudo sync

  cleanup
  trap - RETURN
done

sha256sum /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img > /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img.sha256
sha256sum /mnt/f/StrayOS/disks/strayos-5g.img > /mnt/f/StrayOS/disks/strayos-5g.img.sha256

echo "Cleaned StrayOS apt sources."
