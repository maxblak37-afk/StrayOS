#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
ISO_TREE="${ISO_TREE:-$HOME/strayos-img-iso/iso-tree}"
ISO_PATH="$PROJECT_DIR/iso/StrayOS-base-gnome-debian-apt-amd64.iso"
LOG_DIR="$PROJECT_DIR/build/logs"

mkdir -p "$LOG_DIR"

cat > "$ISO_TREE/boot/grub/grub.cfg" <<'EOF'
serial --unit=0 --speed=115200
terminal_input console serial
terminal_output console serial

set timeout=8
set default=0

menuentry "Boot StrayOS base + GNOME (Debian APT)" {
    linux /strayos/vmlinuz console=tty0 console=ttyS0 nomodeset panic=-1
    initrd /strayos/initramfs.cpio.gz
}

menuentry "Boot StrayOS console debug" {
    linux /strayos/vmlinuz console=ttyS0 console=tty0 nomodeset panic=-1
    initrd /strayos/initramfs.cpio.gz
}

menuentry "Boot StrayOS ISO integrity test" {
    linux /strayos/vmlinuz console=ttyS0 console=tty0 nomodeset panic=-1 strayos.autotest=1
    initrd /strayos/initramfs.cpio.gz
}
EOF

grub-mkrescue -o "$ISO_PATH" "$ISO_TREE" 2>&1 | tee "$LOG_DIR/strayos-img-iso-regenerate.log"
sha256sum "$ISO_PATH" > "$ISO_PATH.sha256"
ls -lh "$ISO_PATH" "$ISO_PATH.sha256"
