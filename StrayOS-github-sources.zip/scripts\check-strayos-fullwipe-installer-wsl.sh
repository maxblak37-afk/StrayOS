#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-fullwipe-check}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

sudo bash -n "$MOUNT_DIR/usr/local/sbin/strayos-install"
sudo sh -n "$MOUNT_DIR/usr/local/sbin/strayos-install-progress"
sudo sh -n "$MOUNT_DIR/usr/local/sbin/strayos-install-gui"

grep -q 'FULL DISK WIPE ENABLED' "$MOUNT_DIR/usr/local/sbin/strayos-install"
grep -q 'dd if=/dev/zero of="$disk"' "$MOUNT_DIR/usr/local/sbin/strayos-install"
grep -q 'Full wiping selected disk' "$MOUNT_DIR/usr/local/sbin/strayos-install-progress"

echo "--- full wipe installer lines ---"
sudo grep -nE 'FULL DISK WIPE|full_wipe_disk|Overwriting|dd if=/dev/zero|Removing old signatures' "$MOUNT_DIR/usr/local/sbin/strayos-install" | sed -n '1,160p'
echo "--- progress lines ---"
sudo grep -nE 'Full wiping|Removing old disk|mkfs.ext4|Copying StrayOS|Installing bootloader' "$MOUNT_DIR/usr/local/sbin/strayos-install-progress" | sed -n '1,120p'
echo "Full-wipe installer check: OK"
