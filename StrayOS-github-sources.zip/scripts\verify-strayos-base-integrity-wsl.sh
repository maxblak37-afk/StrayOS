#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-integrity}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR/proc"; then sudo umount "$MOUNT_DIR/proc"; fi
  if mountpoint -q "$MOUNT_DIR/sys"; then sudo umount "$MOUNT_DIR/sys"; fi
  if mountpoint -q "$MOUNT_DIR/dev/pts"; then sudo umount "$MOUNT_DIR/dev/pts"; fi
  if mountpoint -q "$MOUNT_DIR/dev"; then sudo umount "$MOUNT_DIR/dev"; fi
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup EXIT

sudo mount --bind /dev "$MOUNT_DIR/dev"
sudo mount -t devpts devpts "$MOUNT_DIR/dev/pts"
sudo mount -t proc proc "$MOUNT_DIR/proc"
sudo mount -t sysfs sysfs "$MOUNT_DIR/sys"

echo "--- identity ---"
sudo chroot "$MOUNT_DIR" sh -lc "cat /etc/os-release"

echo "--- apt check ---"
sudo chroot "$MOUNT_DIR" apt-get check

echo "--- dpkg audit ---"
sudo chroot "$MOUNT_DIR" dpkg --audit

echo "--- key package versions ---"
sudo chroot "$MOUNT_DIR" sh -lc 'apt --version; neofetch --version; gnome-shell --version; dpkg-query -W -f="${Package} ${Version}\n" yaru-theme-gtk yaru-theme-icon gnome-shell-extension-dashtodock'

echo "--- disk ---"
df -h "$MOUNT_DIR"
