#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
WORK_DIR="${WORK_DIR:-$HOME/strayos-build}"
KERNEL_VERSION="${KERNEL_VERSION:-7.0.4}"
JOBS="${JOBS:-$(nproc)}"

SRC_DIR="$PROJECT_DIR/sources"
OUT_DIR="$PROJECT_DIR/build/minimal"
LOG_DIR="$PROJECT_DIR/build/logs"
KERNEL_TAR="$SRC_DIR/linux-$KERNEL_VERSION.tar.xz"
KERNEL_BUILD="$WORK_DIR/linux-$KERNEL_VERSION"
INITRAMFS_DIR="$WORK_DIR/initramfs"

mkdir -p "$WORK_DIR" "$OUT_DIR" "$LOG_DIR" "$INITRAMFS_DIR"

if [[ ! -f "$KERNEL_TAR" ]]; then
  echo "Missing kernel source: $KERNEL_TAR" >&2
  exit 1
fi

if [[ ! -d "$KERNEL_BUILD" ]]; then
  tar -C "$WORK_DIR" -xf "$KERNEL_TAR"
fi

rm -rf "$INITRAMFS_DIR"
mkdir -p \
  "$INITRAMFS_DIR/bin" \
  "$INITRAMFS_DIR/dev" \
  "$INITRAMFS_DIR/etc" \
  "$INITRAMFS_DIR/proc" \
  "$INITRAMFS_DIR/sys" \
  "$INITRAMFS_DIR/tmp" \
  "$INITRAMFS_DIR/usr/bin" \
  "$INITRAMFS_DIR/usr/sbin" \
  "$INITRAMFS_DIR/var/lib/dpkg" \
  "$INITRAMFS_DIR/var/lib/apt/lists/partial" \
  "$INITRAMFS_DIR/var/cache/apt/archives/partial"

cp /usr/bin/busybox "$INITRAMFS_DIR/bin/busybox"
for applet in sh mount umount cat echo dmesg uname ls mkdir mknod sleep clear poweroff reboot; do
  ln -sf busybox "$INITRAMFS_DIR/bin/$applet"
done

cat > "$INITRAMFS_DIR/init" <<'INIT'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev 2>/dev/null || {
  mknod /dev/console c 5 1
  mknod /dev/null c 1 3
  mknod /dev/tty c 5 0
}
clear
echo "StrayOS minimal boot"
echo "Kernel: $(uname -r)"
echo
echo "This is the first tiny initramfs shell."
echo "APT/dpkg sources are downloaded, but not built into this image yet."
echo

if grep -q 'strayos.autotest=1' /proc/cmdline; then
  echo "[autotest] /etc/os-release:"
  cat /etc/os-release
  echo
  echo "[autotest] uname:"
  uname -a
  echo
  echo "[autotest] shutting down"
  poweroff -f
fi

exec sh
INIT
chmod +x "$INITRAMFS_DIR/init"

cat > "$INITRAMFS_DIR/etc/os-release" <<'OS_RELEASE'
NAME=StrayOS
ID=strayos
PRETTY_NAME="StrayOS minimal"
VERSION_ID=0.0.1
OS_RELEASE

touch "$INITRAMFS_DIR/var/lib/dpkg/status"

(cd "$INITRAMFS_DIR" && find . -print0 | cpio --null -ov --format=newc | gzip -9) > "$OUT_DIR/strayos-initramfs.cpio.gz"

cd "$KERNEL_BUILD"
make x86_64_defconfig
scripts/config \
  --enable CONFIG_DEVTMPFS \
  --enable CONFIG_DEVTMPFS_MOUNT \
  --enable CONFIG_BLK_DEV_INITRD \
  --disable CONFIG_DEBUG_INFO \
  --disable CONFIG_DEBUG_INFO_BTF \
  --disable CONFIG_MODULE_SIG
make olddefconfig
make -j"$JOBS" bzImage 2>&1 | tee "$LOG_DIR/kernel-build.log"

cp "$KERNEL_BUILD/arch/x86/boot/bzImage" "$OUT_DIR/strayos-linux-$KERNEL_VERSION-bzImage"

cat > "$OUT_DIR/run-qemu.sh" <<'RUN_QEMU'
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
qemu-system-x86_64 \
  -m 512M \
  -kernel "$DIR/strayos-linux-7.0.4-bzImage" \
  -initrd "$DIR/strayos-initramfs.cpio.gz" \
  -append "console=ttyS0 quiet panic=-1" \
  -nographic \
  -no-reboot
RUN_QEMU
chmod +x "$OUT_DIR/run-qemu.sh"

cat > "$OUT_DIR/run-qemu-test.sh" <<'RUN_QEMU_TEST'
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
qemu-system-x86_64 \
  -m 512M \
  -kernel "$DIR/strayos-linux-7.0.4-bzImage" \
  -initrd "$DIR/strayos-initramfs.cpio.gz" \
  -append "console=ttyS0 quiet panic=-1 strayos.autotest=1" \
  -nographic \
  -no-reboot
RUN_QEMU_TEST
chmod +x "$OUT_DIR/run-qemu-test.sh"

cat > "$OUT_DIR/README.md" <<README
# StrayOS Minimal Boot

Built artifacts:

- \`strayos-linux-$KERNEL_VERSION-bzImage\`
- \`strayos-initramfs.cpio.gz\`
- \`run-qemu.sh\`
- \`run-qemu-test.sh\`

Run inside WSL:

\`\`\`sh
cd "$OUT_DIR"
./run-qemu.sh
\`\`\`
README

echo "Built StrayOS minimal artifacts in $OUT_DIR"
