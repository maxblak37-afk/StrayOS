$ErrorActionPreference = "Stop"

wsl sh -lc "cd /mnt/f/StrayOS/build/disk && ./run-qemu-cinnamon.sh"
