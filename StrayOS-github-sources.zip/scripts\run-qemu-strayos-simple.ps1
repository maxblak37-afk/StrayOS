$ErrorActionPreference = "Stop"

wsl sh -lc "cd /mnt/f/StrayOS/build/disk && chmod +x ./run-qemu-simple.sh && ./run-qemu-simple.sh"
