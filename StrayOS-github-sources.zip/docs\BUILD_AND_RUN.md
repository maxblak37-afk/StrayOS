# Build and Run

This minimal StrayOS build currently uses WSL Ubuntu as the build host.

## Build

From PowerShell:

```powershell
wsl sh -lc "/mnt/f/StrayOS/scripts/build-minimal-wsl.sh"
```

## Run Interactively

From PowerShell:

```powershell
F:\StrayOS\scripts\run-qemu.ps1
```

Or from WSL:

```sh
cd /mnt/f/StrayOS/build/minimal
./run-qemu.sh
```

## Run Boot Test

From WSL:

```sh
cd /mnt/f/StrayOS/build/minimal
./run-qemu-test.sh
```

The successful boot test prints:

```text
StrayOS minimal boot
Kernel: 7.0.4
PRETTY_NAME="StrayOS minimal"
```

## Verify Full Kernel Source Archive

From PowerShell:

```powershell
wsl sh -lc "/mnt/f/StrayOS/scripts/verify-full-kernel-wsl.sh"
```

This checks `sources/linux-master-full-source.tar.gz`, builds a kernel from it,
and boots that kernel in QEMU with the StrayOS initramfs.

Latest verified result:

```text
Kernel: 7.1.0-rc2
PRETTY_NAME="StrayOS minimal"
```

## Current Limit

This is not a full Debian/Ubuntu-like distribution yet. It is a first booting
kernel plus BusyBox initramfs. APT and dpkg sources are downloaded, but the
userspace package stack still needs to be built and integrated.
