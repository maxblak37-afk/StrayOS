﻿# Files for GitHub

Put these in the repository:
- README.md
- README.project.md
- docs/
- scripts/
- tools/
- release/
- SOURCE_MANIFEST.md
- .gitignore

Keep these out of the repository because they are generated/heavy:
- F:\StrayOS\iso\*.iso
- F:\StrayOS\disks\*.img
- F:\StrayOS\build\
- F:\StrayOS\rootfs\
- F:\StrayOS\sources\

For GitHub Releases, attach:
- F:\StrayOS\iso\StrayOS-full-amd64.iso

SHA256:
6e4c9dc1bb1627c1925907f297724cdfcce61ceba1eae7d39e319d9fe781eb39
