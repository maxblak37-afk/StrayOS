#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-real-installer}"
PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
KERNEL="$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage"

if [[ ! -f "$KERNEL" ]]; then
  echo "Missing StrayOS kernel: $KERNEL" >&2
  exit 1
fi

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR/proc"; then sudo umount "$MOUNT_DIR/proc"; fi
  if mountpoint -q "$MOUNT_DIR/sys"; then sudo umount "$MOUNT_DIR/sys"; fi
  if mountpoint -q "$MOUNT_DIR/dev/pts"; then sudo umount "$MOUNT_DIR/dev/pts"; fi
  if mountpoint -q "$MOUNT_DIR/dev"; then sudo umount "$MOUNT_DIR/dev"; fi
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup EXIT

sudo mount --bind /dev "$MOUNT_DIR/dev"
sudo mount -t devpts devpts "$MOUNT_DIR/dev/pts"
sudo mount -t proc proc "$MOUNT_DIR/proc"
sudo mount -t sysfs sysfs "$MOUNT_DIR/sys"
sudo cp /etc/resolv.conf "$MOUNT_DIR/etc/resolv.conf"

sudo chroot "$MOUNT_DIR" apt-get update
sudo chroot "$MOUNT_DIR" env DEBIAN_FRONTEND=noninteractive apt-get install -y \
  grub-pc-bin \
  grub-common \
  rsync \
  parted \
  e2fsprogs \
  util-linux \
  dosfstools

sudo mkdir -p "$MOUNT_DIR/boot"
sudo cp "$KERNEL" "$MOUNT_DIR/boot/vmlinuz-strayos"

sudo tee "$MOUNT_DIR/usr/local/sbin/strayos-install" >/dev/null <<'EOF'
#!/bin/bash
set -euo pipefail

TARGET_MOUNT="/mnt/strayos-target"
DRY_RUN=0

if [[ "${1:-}" == "--dry-run" ]]; then
  DRY_RUN=1
fi

say() { printf "\n==> %s\n" "$*"; }
die() { echo "ERROR: $*" >&2; exit 1; }
run() {
  echo "+ $*"
  if [[ "$DRY_RUN" -eq 0 ]]; then
    "$@"
  fi
}

need_root() {
  [[ "$(id -u)" -eq 0 ]] || die "Run as root."
}

require_cmds() {
  local missing=0
  for cmd in lsblk findmnt blkid wipefs parted partprobe mkfs.ext4 rsync grub-install; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      echo "Missing command: $cmd" >&2
      missing=1
    fi
  done
  [[ "$missing" -eq 0 ]] || die "Installer tools are missing."
}

partition_name_for_disk() {
  local disk="$1"
  if [[ "$disk" =~ [0-9]$ ]]; then
    echo "${disk}p1"
  else
    echo "${disk}1"
  fi
}

is_block() {
  [[ -b "$1" ]]
}

is_disk() {
  [[ "$(lsblk -no TYPE "$1" 2>/dev/null | head -1)" == "disk" ]]
}

is_partition() {
  local t
  t="$(lsblk -no TYPE "$1" 2>/dev/null | head -1)"
  [[ "$t" == "part" || "$t" == "lvm" ]]
}

parent_disk_for_partition() {
  local part="$1" pk
  pk="$(lsblk -no PKNAME "$part" 2>/dev/null | head -1 || true)"
  [[ -n "$pk" ]] || return 1
  echo "/dev/$pk"
}

confirm_exact() {
  local expected="$1"
  echo
  echo "This is destructive. To continue, type exactly:"
  echo "  $expected"
  read -r answer
  [[ "$answer" == "$expected" ]] || die "Confirmation did not match. Aborted."
}

ensure_not_live_root() {
  local dev="$1"
  local root_src
  root_src="$(findmnt -n -o SOURCE / || true)"
  if [[ "$root_src" == "$dev" ]]; then
    die "Refusing to install onto the currently mounted live root."
  fi
}

format_whole_disk() {
  local disk="$1"
  is_block "$disk" || die "$disk is not a block device."
  is_disk "$disk" || die "$disk is not a disk."
  [[ "$disk" != /dev/sr* ]] || die "Refusing to install to optical device $disk."
  ensure_not_live_root "$disk"

  confirm_exact "ERASE $disk"

  local part
  part="$(partition_name_for_disk "$disk")"

  run wipefs -a "$disk"
  run parted -s "$disk" mklabel msdos
  run parted -s "$disk" mkpart primary ext4 1MiB 100%
  run parted -s "$disk" set 1 boot on
  run partprobe "$disk"
  sleep 2
  run mkfs.ext4 -F -L STRAYOS_ROOT "$part"

  TARGET_PARTITION="$part"
  BOOT_DISK="$disk"
}

format_selected_volume() {
  local part="$1"
  is_block "$part" || die "$part is not a block device."
  is_partition "$part" || die "$part is not a partition or volume."
  [[ "$part" != /dev/sr* ]] || die "Refusing to install to optical device $part."
  ensure_not_live_root "$part"

  confirm_exact "FORMAT $part"

  run mkfs.ext4 -F -L STRAYOS_ROOT "$part"

  TARGET_PARTITION="$part"
  BOOT_DISK="$(parent_disk_for_partition "$part" || true)"
}

copy_system() {
  local target="$1"
  run mkdir -p "$target"
  run mount "$TARGET_PARTITION" "$target"

  say "Copying StrayOS to $TARGET_PARTITION"
  run rsync -aHAX --numeric-ids \
    --exclude=/dev/* \
    --exclude=/proc/* \
    --exclude=/sys/* \
    --exclude=/run/* \
    --exclude=/tmp/* \
    --exclude=/mnt/* \
    --exclude=/media/* \
    --exclude=/lost+found \
    / "$target"/

  run mkdir -p "$target"/{dev,proc,sys,run,tmp,mnt,media,boot}
  run chmod 1777 "$target/tmp"
  [[ -f "$target/boot/vmlinuz-strayos" ]] || die "Missing /boot/vmlinuz-strayos after copy."
}

write_installed_config() {
  local target="$1" uuid boot_disk="$2" install_grub="$3"
  uuid="$(blkid -s UUID -o value "$TARGET_PARTITION")"
  [[ -n "$uuid" ]] || die "Could not read UUID for $TARGET_PARTITION."

  cat > "$target/etc/fstab" <<EOF_FSTAB
UUID=$uuid / ext4 defaults 0 1
proc /proc proc defaults 0 0
sysfs /sys sysfs defaults 0 0
devpts /dev/pts devpts defaults 0 0
tmpfs /tmp tmpfs mode=1777 0 0
EOF_FSTAB

  cat > "$target/etc/hostname" <<'EOF_HOSTNAME'
strayos
EOF_HOSTNAME

  cat > "$target/etc/hosts" <<'EOF_HOSTS'
127.0.0.1 localhost
127.0.1.1 strayos
EOF_HOSTS

  mkdir -p "$target/boot/grub"
  cat > "$target/boot/grub/grub.cfg" <<EOF_GRUB
set timeout=5
set default=0

menuentry "StrayOS" {
    linux /boot/vmlinuz-strayos root=UUID=$uuid rw init=/init console=tty0 nomodeset panic=-1
}

menuentry "StrayOS debug console" {
    linux /boot/vmlinuz-strayos root=UUID=$uuid rw init=/init console=ttyS0 console=tty0 nomodeset panic=-1
}
EOF_GRUB

  if [[ "$install_grub" == "yes" ]]; then
    [[ -n "$boot_disk" ]] || die "No boot disk selected for GRUB."
    say "Installing GRUB to $boot_disk"
    run grub-install --target=i386-pc --boot-directory="$target/boot" "$boot_disk"
  else
    say "Skipped GRUB install. Boot files are in $target/boot."
  fi
}

finish_install() {
  sync
  umount "$TARGET_MOUNT" || true
  say "Install complete."
  echo "Installed root: $TARGET_PARTITION"
  echo "Boot disk: ${BOOT_DISK:-not installed}"
  echo
  echo "You can now shut down and boot from the installed disk."
}

main() {
  need_root
  require_cmds

  say "StrayOS real installer"
  echo "This installer can erase a whole disk or format one selected partition/volume."
  echo "It installs StrayOS base with Debian apt, neofetch, GNOME Shell, Yaru, and dock."
  echo
  echo "Detected disks and volumes:"
  lsblk -o NAME,SIZE,TYPE,FSTYPE,LABEL,MOUNTPOINTS,MODEL
  echo
  echo "Mode:"
  echo "  1 - Install to whole disk (erase disk, create one ext4 partition)"
  echo "  2 - Install to selected partition/volume (format only that volume)"
  read -rp "Choose mode [1/2]: " mode

  TARGET_PARTITION=""
  BOOT_DISK=""

  case "$mode" in
    1)
      read -rp "Whole disk path, example /dev/sda or /dev/vda: " disk
      format_whole_disk "$disk"
      ;;
    2)
      read -rp "Partition/volume path, example /dev/sda2 or /dev/vda1: " part
      format_selected_volume "$part"
      if [[ -n "$BOOT_DISK" ]]; then
        echo "Parent disk for bootloader appears to be: $BOOT_DISK"
        read -rp "Install GRUB bootloader to $BOOT_DISK? [yes/no]: " install_grub
      else
        read -rp "Boot disk for GRUB, or empty to skip: " BOOT_DISK
        if [[ -n "$BOOT_DISK" ]]; then
          read -rp "Install GRUB bootloader to $BOOT_DISK? [yes/no]: " install_grub
        else
          install_grub="no"
        fi
      fi
      ;;
    *)
      die "Unknown mode."
      ;;
  esac

  install_grub="${install_grub:-yes}"

  if [[ "$install_grub" != "yes" ]]; then
    install_grub="no"
  fi

  if [[ "$install_grub" == "yes" ]]; then
    [[ -n "$BOOT_DISK" ]] || die "Boot disk is empty."
    is_block "$BOOT_DISK" || die "$BOOT_DISK is not a block device."
    is_disk "$BOOT_DISK" || die "$BOOT_DISK is not a disk."
    confirm_exact "INSTALL GRUB $BOOT_DISK"
  fi

  copy_system "$TARGET_MOUNT"
  write_installed_config "$TARGET_MOUNT" "$BOOT_DISK" "$install_grub"
  finish_install
}

main "$@"
EOF

sudo chmod +x "$MOUNT_DIR/usr/local/sbin/strayos-install"

sudo tee "$MOUNT_DIR/usr/local/sbin/strayos-install-help" >/dev/null <<'EOF'
#!/bin/sh
cat <<'HELP'
StrayOS installer commands:

  strayos-install
      Interactive real installer. Can erase a whole disk or format one selected volume.

  strayos-install --dry-run
      Show the flow without executing destructive commands.

Before installing, check disks:

  lsblk -o NAME,SIZE,TYPE,FSTYPE,LABEL,MOUNTPOINTS,MODEL

This installer is destructive only after exact typed confirmations.
HELP
EOF
sudo chmod +x "$MOUNT_DIR/usr/local/sbin/strayos-install-help"

if grep -q 'echo "  strayos-gnome"' "$MOUNT_DIR/init" && ! grep -q 'echo "  strayos-install"$' "$MOUNT_DIR/init"; then
  sudo sed -i '/echo "  strayos-gnome"/a echo "  strayos-install-help"\
echo "  strayos-install"' "$MOUNT_DIR/init"
fi

sudo sync
echo "Configured real installer in StrayOS image."
