$ErrorActionPreference = "Stop"

wsl sh -lc "qemu-system-x86_64 -m 4096M -smp 2 -drive file=/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img,format=raw,if=ide -display sdl -vga std"
