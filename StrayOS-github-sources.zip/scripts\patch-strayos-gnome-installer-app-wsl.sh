#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
images=(
  "$PROJECT_DIR/disks/strayos-5g.img"
  "$PROJECT_DIR/disks/StrayOS-bootable-5g.img"
)

patch_image() {
  local image="$1" mount_dir loop_dev part
  mount_dir="/tmp/strayos-gnome-installer-app-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  sleep 1
  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"

  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  sudo mount "$part" "$mount_dir"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-install-app" >/dev/null
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

if [ "$(id -u)" = "0" ]; then
  exec /usr/local/sbin/strayos-install-gui
fi

if command -v pkexec >/dev/null 2>&1; then
  exec pkexec env DISPLAY="$DISPLAY" XAUTHORITY="$XAUTHORITY" XDG_RUNTIME_DIR="$XDG_RUNTIME_DIR" /usr/local/sbin/strayos-install-gui
fi

if command -v sudo >/dev/null 2>&1; then
  exec xterm -fa Monospace -fs 12 -title "Install StrayOS" -e sudo /usr/local/sbin/strayos-install-gui
fi

zenity --error --width=560 --title="Install StrayOS" --text="Installer needs root permissions. Run: strayos-installer-gui" 2>/dev/null || true
exit 1
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-install-app"

  sudo mkdir -p "$mount_dir/usr/share/applications" "$mount_dir/root/Desktop" "$mount_dir/etc/skel/Desktop"
  cat <<'EOF' | sudo tee "$mount_dir/usr/share/applications/strayos-installer.desktop" >/dev/null
[Desktop Entry]
Type=Application
Name=Install StrayOS
Comment=Install StrayOS to a disk or selected partition
Exec=/usr/local/bin/strayos-install-app
Icon=drive-harddisk
Terminal=false
Categories=System;Settings;
StartupNotify=true
EOF

  cat <<'EOF' | sudo tee "$mount_dir/usr/share/applications/strayos-wifi.desktop" >/dev/null
[Desktop Entry]
Type=Application
Name=StrayOS Wi-Fi
Comment=Connect to Wi-Fi and save the network profile
Exec=/usr/local/bin/strayos-wifi-gui
Icon=network-wireless
Terminal=false
Categories=Network;Settings;
StartupNotify=true
EOF

  cat <<'EOF' | sudo tee "$mount_dir/usr/share/applications/strayos-browser.desktop" >/dev/null
[Desktop Entry]
Type=Application
Name=Firefox ESR
Comment=Browse the web in StrayOS
Exec=/usr/bin/firefox-esr
Icon=firefox-esr
Terminal=false
Categories=Network;WebBrowser;
StartupNotify=true
EOF

  cat <<'EOF' | sudo tee "$mount_dir/usr/share/applications/strayos-about.desktop" >/dev/null
[Desktop Entry]
Type=Application
Name=About StrayOS
Comment=Show StrayOS build information
Exec=xterm -fa Monospace -fs 12 -title "About StrayOS" -e /usr/local/bin/strayos-about
Icon=help-about
Terminal=false
Categories=System;
StartupNotify=true
EOF

  sudo cp "$mount_dir/usr/share/applications/strayos-installer.desktop" "$mount_dir/root/Desktop/Install StrayOS.desktop"
  sudo cp "$mount_dir/usr/share/applications/strayos-installer.desktop" "$mount_dir/etc/skel/Desktop/Install StrayOS.desktop"
  sudo chmod +x "$mount_dir/root/Desktop/Install StrayOS.desktop" "$mount_dir/etc/skel/Desktop/Install StrayOS.desktop"

  if [[ -f "$mount_dir/usr/local/sbin/strayos-install-help" ]] && ! sudo grep -q 'Install StrayOS' "$mount_dir/usr/local/sbin/strayos-install-help"; then
    sudo tee -a "$mount_dir/usr/local/sbin/strayos-install-help" >/dev/null <<'EOF'

GNOME:
  Open "Install StrayOS" from the applications menu to run the installer inside GNOME.
EOF
  fi

  sudo sh -n "$mount_dir/usr/local/bin/strayos-install-app"
  sudo grep -q 'Name=Install StrayOS' "$mount_dir/usr/share/applications/strayos-installer.desktop"
  sudo grep -q 'Exec=/usr/local/bin/strayos-install-app' "$mount_dir/usr/share/applications/strayos-installer.desktop"
  sudo sync
  cleanup
  trap - RETURN
}

for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum "$PROJECT_DIR/disks/StrayOS-bootable-5g.img" > "$PROJECT_DIR/disks/StrayOS-bootable-5g.img.sha256"
sha256sum "$PROJECT_DIR/disks/strayos-5g.img" > "$PROJECT_DIR/disks/strayos-5g.img.sha256"
echo "Patched GNOME application launchers for StrayOS installer."
