#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
images=(
  "$PROJECT_DIR/disks/strayos-5g.img"
  "$PROJECT_DIR/disks/StrayOS-bootable-5g.img"
)

write_main_init() {
  local file="$1"
  cat <<'EOF' | sudo tee "$file" >/dev/null
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TERM=linux
export LANG="$(cat /etc/strayos/locale 2>/dev/null || echo C.UTF-8)"

mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
mount -t tmpfs -o mode=0755,nosuid,nodev tmpfs /run 2>/dev/null || true
mount -t tmpfs -o mode=1777,nosuid,nodev tmpfs /tmp 2>/dev/null || true
mkdir -p /dev/pts /run /tmp /root /run/user/0 /var/lib/strayos /etc/strayos /var/log/lightdm /var/lib/lightdm
mount -t devpts devpts /dev/pts 2>/dev/null || true
chmod 1777 /tmp 2>/dev/null || true
chmod 700 /run/user/0 2>/dev/null || true

if [ -f /var/lib/strayos/booting ]; then
  echo "Previous StrayOS shutdown was not clean; resetting GNOME/Xorg volatile state." >/dev/console 2>&1 || true
  rm -f /tmp/.X0-lock /tmp/.X1-lock /tmp/.X11-unix/X0 /tmp/.X11-unix/X1
  rm -f /root/.Xauthority /root/.ICEauthority /root/.xsession-errors /root/.xsession-errors.old
  rm -rf /root/.cache/gnome-shell /root/.local/share/gnome-shell /root/.local/share/gvfs-metadata
  rm -f /root/.config/monitors.xml
fi
date > /var/lib/strayos/booting 2>/dev/null || true

hostname "$(cat /etc/hostname 2>/dev/null || echo strayos)" 2>/dev/null || true
swapon /swapfile 2>/dev/null || true
sysctl -w vm.swappiness=80 >/dev/null 2>&1 || true

ip link set lo up 2>/dev/null || true
ip link set eth0 up 2>/dev/null || true
dhclient -1 eth0 2>/dev/null || true
strayos-network-autostart >/tmp/strayos-network-autostart.log 2>&1 &

show_banner() {
  clear 2>/dev/null || true
  cat /etc/issue 2>/dev/null || echo "StrayOS"
  echo "Kernel: $(uname -r)"
  echo "Disk: persistent ext4 StrayOS"
  echo
  echo "Login manager: LightDM"
  echo "Default live user: stray / stray"
  echo
  echo "Commands:"
  echo "  strayos-lightdm"
  echo "  strayos-gnome"
  echo "  strayos-light"
  echo "  strayos-browser"
  echo "  strayos-wifi-gui"
  echo "  strayos-installer-gui"
  echo "  strayos-repair-boot"
  echo "  strayos-about"
  echo "  strayos-poweroff"
  echo "  strayos-reboot"
  echo
  echo "Add strayos.no-gui in GRUB to boot console only."
  echo
}

if grep -q 'strayos.autotest=1' /proc/cmdline 2>/dev/null; then
  show_banner
  cat /etc/os-release
  apt --version
  neofetch --version
  dpkg-query -W -f='${binary:Package}\n' lightdm lightdm-gtk-greeter gnome-shell firefox-esr neofetch
  rm -f /var/lib/strayos/booting
  poweroff -f
fi

cd /root || cd /

if ! grep -q 'console=ttyS0' /proc/cmdline 2>/dev/null && ! grep -q 'strayos.no-gui' /proc/cmdline 2>/dev/null; then
  show_banner
  echo "Starting LightDM login manager..." >/dev/console 2>&1 || true
  strayos-lightdm </dev/tty1 >/dev/tty1 2>&1
  echo "LightDM exited. Falling back to StrayOS console." >/dev/console 2>&1 || true
  sleep 2
fi

while true; do
  show_banner

  if grep -q 'console=ttyS0' /proc/cmdline 2>/dev/null; then
    /bin/busybox cttyhack /bin/bash -l || /bin/bash -l </dev/console >/dev/console 2>&1 || /bin/sh </dev/console >/dev/console 2>&1
  else
    /bin/busybox setsid /bin/bash -l </dev/tty1 >/dev/tty1 2>&1 || \
      /bin/bash -l </dev/console >/dev/console 2>&1 || \
      /bin/sh </dev/console >/dev/console 2>&1
  fi

  echo "Shell exited. Restarting StrayOS console..." >/dev/console 2>&1 || true
  sleep 1
done
EOF
  sudo chmod +x "$file"
}

patch_image() {
  local image="$1" mount_dir loop_dev part
  mount_dir="/tmp/strayos-lightdm-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  sleep 1
  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"

  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  sudo mount "$part" "$mount_dir"

  sudo mkdir -p "$mount_dir/etc/strayos" "$mount_dir/etc/lightdm/lightdm.conf.d" "$mount_dir/usr/share/xsessions" "$mount_dir/etc/sudoers.d"
  echo "ru_RU.UTF-8" | sudo tee "$mount_dir/etc/strayos/locale" >/dev/null

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/sbin/strayos-lightdm" >/dev/null
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export LANG="$(cat /etc/strayos/locale 2>/dev/null || echo C.UTF-8)"

strayos-start-udev 2>/dev/null || true
strayos-network-autostart >/tmp/strayos-network-autostart.log 2>&1 &
swapon /swapfile 2>/dev/null || true

mkdir -p /run/dbus /run/lightdm /var/log/lightdm /var/lib/lightdm /tmp/.X11-unix
chmod 1777 /tmp /tmp/.X11-unix 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true
rm -f /tmp/.X0-lock /tmp/.X1-lock /tmp/.X11-unix/X0 /tmp/.X11-unix/X1

if ! command -v lightdm >/dev/null 2>&1; then
  echo "LightDM is not installed."
  exit 1
fi

exec lightdm --debug
EOF
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-lightdm"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-gnome-session" >/dev/null
#!/bin/sh
set +e
export LANG="$(cat /etc/strayos/locale 2>/dev/null || echo C.UTF-8)"
export LC_ALL="$LANG"
export LIBGL_ALWAYS_SOFTWARE=1
export MUTTER_DEBUG_DISABLE_HW_CURSORS=1
export CLUTTER_VBLANK=none
export GSK_RENDERER=cairo
export XDG_SESSION_TYPE=x11
export XDG_CURRENT_DESKTOP=GNOME
export GDMSESSION=gnome

strayos-network-autostart >/tmp/strayos-network-autostart.log 2>&1 &
gsettings set org.gnome.desktop.interface enable-animations false 2>/dev/null || true
gsettings set org.gnome.mutter experimental-features "[]" 2>/dev/null || true
gnome-extensions disable dash-to-dock@micxgx.gmail.com 2>/dev/null || true
gnome-extensions disable ubuntu-dock@ubuntu.com 2>/dev/null || true

exec dbus-run-session -- gnome-session --session=gnome
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-gnome-session"

  cat <<'EOF' | sudo tee "$mount_dir/usr/share/xsessions/strayos-gnome.desktop" >/dev/null
[Desktop Entry]
Name=StrayOS GNOME
Comment=StrayOS GNOME safe Xorg session
Exec=/usr/local/bin/strayos-gnome-session
TryExec=/usr/local/bin/strayos-gnome-session
Type=Application
DesktopNames=GNOME
EOF

  cat <<'EOF' | sudo tee "$mount_dir/etc/lightdm/lightdm.conf.d/50-strayos.conf" >/dev/null
[LightDM]
run-directory=/run/lightdm
log-directory=/var/log/lightdm

[Seat:*]
greeter-session=lightdm-gtk-greeter
user-session=strayos-gnome
allow-guest=false
greeter-hide-users=false
greeter-show-manual-login=true
xserver-command=X -core -noreset
EOF

  cat <<'EOF' | sudo tee "$mount_dir/etc/lightdm/lightdm-gtk-greeter.conf" >/dev/null
[greeter]
theme-name=Adwaita
icon-theme-name=Adwaita
font-name=Sans 11
indicators=~host;~spacer;~language;~session;~power
keyboard=onboard
EOF

  sudo sed -i 's/^# *ru_RU.UTF-8 UTF-8/ru_RU.UTF-8 UTF-8/' "$mount_dir/etc/locale.gen" 2>/dev/null || true
  sudo sed -i 's/^# *en_US.UTF-8 UTF-8/en_US.UTF-8 UTF-8/' "$mount_dir/etc/locale.gen" 2>/dev/null || true
  cat <<'EOF' | sudo tee "$mount_dir/etc/default/locale" >/dev/null
LANG=ru_RU.UTF-8
LC_ALL=ru_RU.UTF-8
EOF
  if [[ -x "$mount_dir/usr/sbin/locale-gen" ]]; then
    sudo chroot "$mount_dir" locale-gen ru_RU.UTF-8 en_US.UTF-8 >/dev/null 2>&1 || true
  fi

  sudo chroot "$mount_dir" sh -lc 'id -u stray >/dev/null 2>&1 || useradd -m -s /bin/bash -G sudo,adm,netdev,audio,video stray' 2>/dev/null || \
    sudo chroot "$mount_dir" sh -lc 'id -u stray >/dev/null 2>&1 || useradd -m -s /bin/bash stray'
  printf 'stray:stray\nroot:stray\n' | sudo chroot "$mount_dir" chpasswd 2>/dev/null || true
  echo 'stray ALL=(ALL) ALL' | sudo tee "$mount_dir/etc/sudoers.d/stray" >/dev/null
  sudo chmod 440 "$mount_dir/etc/sudoers.d/stray"

  if [[ -f "$mount_dir/root/Desktop/Install StrayOS.desktop" ]]; then
    sudo mkdir -p "$mount_dir/home/stray/Desktop" "$mount_dir/etc/skel/Desktop"
    sudo cp "$mount_dir/root/Desktop/Install StrayOS.desktop" "$mount_dir/home/stray/Desktop/Install StrayOS.desktop"
    sudo cp "$mount_dir/root/Desktop/Install StrayOS.desktop" "$mount_dir/etc/skel/Desktop/Install StrayOS.desktop"
    sudo chmod +x "$mount_dir/home/stray/Desktop/Install StrayOS.desktop" "$mount_dir/etc/skel/Desktop/Install StrayOS.desktop"
    sudo chroot "$mount_dir" chown -R stray:stray /home/stray 2>/dev/null || true
  fi

  write_main_init "$mount_dir/init"

  sudo sh -n "$mount_dir/init"
  sudo sh -n "$mount_dir/usr/local/sbin/strayos-lightdm"
  sudo sh -n "$mount_dir/usr/local/bin/strayos-gnome-session"
  sudo grep -q 'user-session=strayos-gnome' "$mount_dir/etc/lightdm/lightdm.conf.d/50-strayos.conf"
  sudo grep -q 'Starting LightDM login manager' "$mount_dir/init"
  sudo grep -q 'Name=StrayOS GNOME' "$mount_dir/usr/share/xsessions/strayos-gnome.desktop"
  sudo chroot "$mount_dir" sh -lc 'dpkg-query -W lightdm lightdm-gtk-greeter accountsservice locales >/dev/null'
  sudo sync
  cleanup
  trap - RETURN
}

for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum "$PROJECT_DIR/disks/StrayOS-bootable-5g.img" > "$PROJECT_DIR/disks/StrayOS-bootable-5g.img.sha256"
sha256sum "$PROJECT_DIR/disks/strayos-5g.img" > "$PROJECT_DIR/disks/strayos-5g.img.sha256"
echo "Patched StrayOS LightDM login, StrayOS GNOME session, live user, and Russian locale."
