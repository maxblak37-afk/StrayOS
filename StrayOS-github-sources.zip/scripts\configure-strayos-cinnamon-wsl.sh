#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-cinnamon}"
PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR/proc"; then sudo umount "$MOUNT_DIR/proc"; fi
  if mountpoint -q "$MOUNT_DIR/sys"; then sudo umount "$MOUNT_DIR/sys"; fi
  if mountpoint -q "$MOUNT_DIR/dev/pts"; then sudo umount "$MOUNT_DIR/dev/pts"; fi
  if mountpoint -q "$MOUNT_DIR/dev"; then sudo umount "$MOUNT_DIR/dev"; fi
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup EXIT

sudo mount --bind /dev "$MOUNT_DIR/dev"
sudo mount -t devpts devpts "$MOUNT_DIR/dev/pts"
sudo mount -t proc proc "$MOUNT_DIR/proc"
sudo mount -t sysfs sysfs "$MOUNT_DIR/sys"

sudo cp /etc/resolv.conf "$MOUNT_DIR/etc/resolv.conf"
sudo chroot "$MOUNT_DIR" apt-get update
sudo chroot "$MOUNT_DIR" apt-get install -y dbus-x11 xterm

sudo mkdir -p "$MOUNT_DIR/root"
sudo tee "$MOUNT_DIR/root/.xinitrc" >/dev/null <<'EOF'
#!/bin/sh
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
export XDG_RUNTIME_DIR=/run/user/0
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"

dbus-daemon --system --fork 2>/dev/null || true

if command -v cinnamon-session >/dev/null 2>&1; then
  exec dbus-launch --exit-with-session cinnamon-session
fi

exec xterm
EOF
sudo chmod +x "$MOUNT_DIR/root/.xinitrc"

sudo tee "$MOUNT_DIR/init" >/dev/null <<'EOF'
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TERM=linux
export LANG=C.UTF-8

mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /run /tmp /root /run/user/0
mount -t devpts devpts /dev/pts 2>/dev/null
chmod 1777 /tmp
chmod 700 /run/user/0
hostname strayos 2>/dev/null

ip link set lo up 2>/dev/null
ip link set eth0 up 2>/dev/null
dhclient -1 eth0 2>/dev/null || true

clear
cat /etc/issue 2>/dev/null
echo "Kernel: $(uname -r)"
echo "Disk: 5 GB persistent ext4 image"
echo

if grep -q 'strayos.gui=1' /proc/cmdline 2>/dev/null; then
  echo "Starting Cinnamon..."
  cd /root
  exec /bin/busybox cttyhack /usr/bin/startx /root/.xinitrc -- :0 vt1
fi

echo "Try: neofetch, apt --version, apt-get update, nano test.txt"
echo "Cinnamon GUI launch uses: strayos.gui=1"
echo "Power off: poweroff -f"
echo

if grep -q 'strayos.autotest=1' /proc/cmdline 2>/dev/null; then
  echo "[autotest] /etc/os-release:"
  cat /etc/os-release
  echo
  echo "[autotest] disk:"
  df -h /
  echo
  echo "[autotest] apt:"
  apt --version
  echo
  echo "[autotest] dpkg packages:"
  dpkg-query -f '${binary:Package}\n' -W | wc -l
  echo
  poweroff -f
fi

cd /root
exec /bin/busybox cttyhack /bin/bash -l
EOF
sudo chmod +x "$MOUNT_DIR/init"
sudo ln -sf busybox "$MOUNT_DIR/bin/poweroff"
sudo ln -sf busybox "$MOUNT_DIR/bin/reboot"

cat > "$PROJECT_DIR/build/disk/run-qemu-cinnamon.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"

qemu-system-x86_64 \
  -m 3072M \
  -kernel "$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage" \
  -append "root=/dev/sda rw init=/init console=tty0 panic=-1 strayos.gui=1" \
  -drive "file=$PROJECT_DIR/disks/strayos-5g.img,format=raw,if=ide,index=0,media=disk" \
  -display sdl \
  -vga qxl
EOF
chmod +x "$PROJECT_DIR/build/disk/run-qemu-cinnamon.sh"

cat > "$PROJECT_DIR/scripts/run-qemu-strayos-cinnamon.ps1" <<'EOF'
$ErrorActionPreference = "Stop"

wsl sh -lc "cd /mnt/f/StrayOS/build/disk && ./run-qemu-cinnamon.sh"
EOF

sudo sync
echo "Configured StrayOS Cinnamon direct startx mode."
