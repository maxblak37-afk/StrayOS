#!/usr/bin/env bash
set -euo pipefail

find /mnt/f/StrayOS/build/full-kernel -maxdepth 4 -type f \
  \( -name .config -o -name 'config-*' \) \
  -print \
  -exec grep -E 'CONFIG_(SQUASHFS|ISO9660|OVERLAY_FS|USB_STORAGE|BLK_DEV_SR)' {} \; 2>/dev/null | head -100
