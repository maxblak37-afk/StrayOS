#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
BOOT_IMG="${BOOT_IMG:-$PROJECT_DIR/disks/StrayOS-bootable-5g.img}"
SOURCE_IMG="${SOURCE_IMG:-$PROJECT_DIR/disks/strayos-5g.img}"
KERNEL_SRC="${KERNEL_SRC:-/root/strayos-build-full/linux-master}"
KERNEL_OUT="$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage"
LOG_DIR="$PROJECT_DIR/build/logs"
TARGET_SIZE="${TARGET_SIZE:-8G}"

mkdir -p "$LOG_DIR"

resize_image() {
  local image="$1" loop_dev="" part=""
  local current
  current="$(stat -c '%s' "$image")"
  if (( current >= 8589934592 )); then
    echo "$image is already at least 8G."
    return
  fi

  echo "Resizing $image to $TARGET_SIZE..."
  qemu-img resize -f raw "$image" "$TARGET_SIZE"

  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup_resize() {
    if [[ -n "${loop_dev:-}" ]]; then sudo losetup -d "$loop_dev" || true; fi
  }
  trap cleanup_resize RETURN

  if [[ -b "${loop_dev}p1" ]]; then
    sudo parted -s "$loop_dev" resizepart 1 100%
    sudo partprobe "$loop_dev" || true
    sleep 2
    part="${loop_dev}p1"
  else
    part="$loop_dev"
  fi

  sudo e2fsck -fy "$part" || true
  sudo resize2fs "$part"
  cleanup_resize
  trap - RETURN
}

configure_kernel_modules() {
  echo "Configuring common hardware drivers as kernel modules..."
  cd "$KERNEL_SRC"
  scripts/config \
    --enable CONFIG_MODULES \
    --enable CONFIG_KMOD \
    --enable CONFIG_FW_LOADER \
    --enable CONFIG_FW_LOADER_USER_HELPER \
    --enable CONFIG_CFG80211_WEXT \
    --enable CONFIG_BT \
    --module CONFIG_BT_HCIBTUSB \
    --module CONFIG_BT_HCIUART \
    --module CONFIG_BT_HCIBCM203X \
    --module CONFIG_BT_HCIBPA10X \
    --module CONFIG_BT_RTL \
    --module CONFIG_BT_INTEL \
    --module CONFIG_BT_BCM \
    --module CONFIG_IWLWIFI \
    --module CONFIG_IWLDVM \
    --module CONFIG_IWLMVM \
    --module CONFIG_ATH9K \
    --module CONFIG_ATH9K_HTC \
    --module CONFIG_ATH10K \
    --module CONFIG_ATH10K_PCI \
    --module CONFIG_ATH10K_USB \
    --module CONFIG_ATH11K \
    --module CONFIG_ATH11K_PCI \
    --module CONFIG_B43 \
    --module CONFIG_B43LEGACY \
    --module CONFIG_BRCMFMAC \
    --module CONFIG_BRCMFMAC_USB \
    --module CONFIG_BRCMFMAC_PCIE \
    --module CONFIG_MT7601U \
    --module CONFIG_MT76x0U \
    --module CONFIG_MT76x0E \
    --module CONFIG_MT76x2U \
    --module CONFIG_MT76x2E \
    --module CONFIG_MT7603E \
    --module CONFIG_MT7615E \
    --module CONFIG_RTW88 \
    --module CONFIG_RTW88_PCI \
    --module CONFIG_RTW88_USB \
    --module CONFIG_RTW89 \
    --module CONFIG_RTW89_PCI \
    --module CONFIG_RTL_CARDS \
    --module CONFIG_RTL8192CE \
    --module CONFIG_RTL8192CU \
    --module CONFIG_RTL8723AE \
    --module CONFIG_RTL8723BE \
    --module CONFIG_RTL8188EE \
    --module CONFIG_RTL8192EE \
    --module CONFIG_RTL8821AE \
    --module CONFIG_ALX \
    --module CONFIG_ATL1C \
    --module CONFIG_IGB \
    --module CONFIG_SKY2 \
    --module CONFIG_TIGON3 \
    --module CONFIG_USB_NET_DRIVERS \
    --module CONFIG_USB_RTL8152 \
    --module CONFIG_USB_USBNET \
    --module CONFIG_USB_NET_AX8817X \
    --module CONFIG_USB_NET_AX88179_178A \
    --module CONFIG_USB_NET_CDCETHER \
    --module CONFIG_USB_NET_RNDIS_HOST

  make olddefconfig
  make -j"$(nproc)" bzImage modules 2>&1 | tee "$LOG_DIR/drivers-kernel-modules-build.log"
  cp "$KERNEL_SRC/arch/x86/boot/bzImage" "$KERNEL_OUT"
}

patch_one() {
  local image="$1" mount_dir="$2" loop_dev="" part="" krel=""

  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup_one() {
    if mountpoint -q "$mount_dir/dev/pts"; then sudo umount "$mount_dir/dev/pts"; fi
    if mountpoint -q "$mount_dir/dev"; then sudo umount "$mount_dir/dev"; fi
    if mountpoint -q "$mount_dir/proc"; then sudo umount "$mount_dir/proc"; fi
    if mountpoint -q "$mount_dir/sys"; then sudo umount "$mount_dir/sys"; fi
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    if [[ -n "${loop_dev:-}" ]]; then sudo losetup -d "$loop_dev" || true; fi
  }
  trap cleanup_one RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi

  sudo mount "$part" "$mount_dir"
  sudo mkdir -p "$mount_dir/boot" "$mount_dir/etc/apt/sources.list.d"
  sudo cp "$KERNEL_OUT" "$mount_dir/boot/vmlinuz-strayos"

  cat <<'EOF' | sudo tee "$mount_dir/etc/apt/sources.list.d/strayos-firmware.list" >/dev/null
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF

  echo "Installing kernel modules into $image..."
  cd "$KERNEL_SRC"
  sudo make modules_install INSTALL_MOD_PATH="$mount_dir" 2>&1 | tee -a "$LOG_DIR/drivers-modules-install.log"
  krel="$(make -s kernelrelease)"
  if command -v depmod >/dev/null 2>&1; then
    sudo depmod -b "$mount_dir" "$krel" || true
  fi

  sudo mount --bind /dev "$mount_dir/dev"
  sudo mount -t devpts devpts "$mount_dir/dev/pts" 2>/dev/null || true
  sudo mount -t proc proc "$mount_dir/proc"
  sudo mount -t sysfs sysfs "$mount_dir/sys"
  sudo cp /etc/resolv.conf "$mount_dir/etc/resolv.conf"

  sudo chroot "$mount_dir" apt-get update

  packages=(
    kmod udev pciutils usbutils
    network-manager wpasupplicant wireless-tools iw rfkill
    bluez bluetooth
    alsa-utils pipewire wireplumber
    firmware-linux firmware-linux-free firmware-linux-nonfree firmware-misc-nonfree
    firmware-iwlwifi firmware-realtek firmware-atheros firmware-brcm80211
    firmware-amd-graphics firmware-sof-signed
    intel-microcode amd64-microcode
  )

  for pkg in "${packages[@]}"; do
    echo "Installing hardware package: $pkg"
    sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "$pkg" || true
  done

  sudo chroot "$mount_dir" apt-get clean || true
  sudo rm -rf "$mount_dir/var/cache/apt/archives/"*.deb "$mount_dir/var/lib/apt/lists/"*

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/sbin/strayos-install-progress" >/dev/null
#!/bin/sh
set -u

INPUT_FILE="${1:-}"
LOG="${2:-/tmp/strayos-install-progress.log}"

[ -n "$INPUT_FILE" ] && [ -f "$INPUT_FILE" ] || {
  echo "# Missing installer input file"
  echo 100
  exit 1
}

rm -f "$LOG"
echo "# Preparing installer"
echo 2

(strayos-install < "$INPUT_FILE" > "$LOG" 2>&1) &
pid="$!"

last=2
while kill -0 "$pid" 2>/dev/null; do
  if grep -q 'mkfs.ext4' "$LOG" 2>/dev/null; then
    stage="Formatting target"
    pct=20
  elif grep -q 'Copying StrayOS' "$LOG" 2>/dev/null; then
    stage="Copying StrayOS files"
    pct=$((last + 2))
    [ "$pct" -gt 78 ] && pct=78
  elif grep -q 'Installing GRUB' "$LOG" 2>/dev/null; then
    stage="Installing bootloader"
    pct=86
  elif grep -q 'Install complete' "$LOG" 2>/dev/null; then
    stage="Finishing"
    pct=98
  else
    stage="Working"
    pct=$((last + 1))
    [ "$pct" -gt 35 ] && pct=35
  fi
  last="$pct"
  echo "# $stage"
  echo "$pct"
  sleep 1
done

wait "$pid"
status="$?"

if [ "$status" -eq 0 ] && grep -q 'Install complete' "$LOG"; then
  echo "# Installation complete"
  echo 100
  exit 0
fi

echo "# Installation failed"
echo 100
exit "${status:-1}"
EOF
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-install-progress"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/sbin/strayos-install-gui" >/dev/null
#!/bin/sh
set -u

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

die() {
  zenity --error --width=560 --title="StrayOS Installer" --text="$1" 2>/dev/null || echo "ERROR: $1" >&2
  exit 1
}

for cmd in zenity lsblk strayos-install strayos-install-progress; do
  command -v "$cmd" >/dev/null 2>&1 || die "Missing command: $cmd"
done

[ "$(id -u)" = "0" ] || die "Run installer as root."

zenity --warning \
  --width=660 \
  --title="StrayOS Installer" \
  --text="Real installation mode.\n\nThis can erase a whole disk or format one selected partition. Check device size and model carefully." \
  2>/dev/null || exit 1

mode="$(zenity --list --radiolist \
  --width=660 --height=260 \
  --title="StrayOS Installer" \
  --text="Stage: choose installation mode" \
  --column="" --column="Mode" --column="Meaning" \
  TRUE "Whole disk" "Erase a disk, create one StrayOS ext4 partition, install GRUB" \
  FALSE "Selected partition" "Format only one selected partition/volume" \
  2>/dev/null)" || exit 1

[ -n "$mode" ] || exit 1

input="/tmp/strayos-install-input.$$"
log="/tmp/strayos-install-progress.log"
rm -f "$input" "$log"

if [ "$mode" = "Whole disk" ]; then
  disk="$(
    lsblk -dn -P -o PATH,SIZE,MODEL,TYPE |
    while IFS= read -r line; do
      eval "$line"
      [ "${TYPE:-}" = "disk" ] || continue
      case "${PATH:-}" in /dev/sr*|/dev/loop*) continue ;; esac
      printf '%s\n%s\n%s\n' "$PATH" "${SIZE:-?}" "${MODEL:-unknown}"
    done |
    zenity --list --width=780 --height=380 \
      --title="StrayOS Installer" \
      --text="Stage: select target disk to erase" \
      --column="Device" --column="Size" --column="Model" \
      2>/dev/null
  )" || exit 1

  [ -n "$disk" ] || exit 1

  confirm="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm erase\n\nTo erase $disk and install StrayOS, type exactly:\n\nERASE $disk" 2>/dev/null)" || exit 1
  [ "$confirm" = "ERASE $disk" ] || die "Confirmation did not match."

  confirm_grub="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm bootloader\n\nTo install GRUB bootloader to $disk, type exactly:\n\nINSTALL GRUB $disk" 2>/dev/null)" || exit 1
  [ "$confirm_grub" = "INSTALL GRUB $disk" ] || die "Bootloader confirmation did not match."

  printf '1\n%s\nERASE %s\nINSTALL GRUB %s\n' "$disk" "$disk" "$disk" > "$input"
else
  part="$(
    lsblk -pn -P -o PATH,SIZE,FSTYPE,LABEL,TYPE,MOUNTPOINTS |
    while IFS= read -r line; do
      eval "$line"
      case "${TYPE:-}" in part|lvm) ;;
        *) continue ;;
      esac
      case "${PATH:-}" in /dev/loop*|/dev/sr*) continue ;; esac
      printf '%s\n%s\n%s\n%s\n%s\n' "$PATH" "${SIZE:-?}" "${FSTYPE:-}" "${LABEL:-}" "${MOUNTPOINTS:-}"
    done |
    zenity --list --width=880 --height=430 \
      --title="StrayOS Installer" \
      --text="Stage: select partition/volume to format" \
      --column="Device" --column="Size" --column="FS" --column="Label" --column="Mounted at" \
      2>/dev/null
  )" || exit 1

  [ -n "$part" ] || exit 1

  confirm="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm format\n\nTo format $part as StrayOS root, type exactly:\n\nFORMAT $part" 2>/dev/null)" || exit 1
  [ "$confirm" = "FORMAT $part" ] || die "Confirmation did not match."

  parent="$(lsblk -no PKNAME "$part" 2>/dev/null | head -1)"
  boot_disk=""
  install_grub="no"
  if [ -n "$parent" ]; then
    boot_disk="/dev/$parent"
    if zenity --question --width=580 --title="StrayOS Installer" \
      --text="Stage: bootloader\n\nInstall GRUB bootloader to parent disk?\n\n$boot_disk" 2>/dev/null; then
      install_grub="yes"
    fi
  fi

  if [ "$install_grub" = "yes" ]; then
    confirm_grub="$(zenity --entry --width=640 --title="StrayOS Installer" \
      --text="Stage: confirm bootloader\n\nTo install GRUB bootloader to $boot_disk, type exactly:\n\nINSTALL GRUB $boot_disk" 2>/dev/null)" || exit 1
    [ "$confirm_grub" = "INSTALL GRUB $boot_disk" ] || die "Bootloader confirmation did not match."
    printf '2\n%s\nFORMAT %s\nyes\nINSTALL GRUB %s\n' "$part" "$part" "$boot_disk" > "$input"
  else
    printf '2\n%s\nFORMAT %s\nno\n' "$part" "$part" > "$input"
  fi
fi

if strayos-install-progress "$input" "$log" | zenity --progress \
  --width=620 \
  --title="StrayOS Installer" \
  --text="Stage: starting" \
  --percentage=0 \
  --auto-close; then
  zenity --info --width=560 --title="StrayOS Installer" --text="Installation complete.\n\nYou can reboot and boot from the installed disk." 2>/dev/null || true
  rm -f "$input"
  exit 0
fi

tail_msg="$(tail -60 "$log" 2>/dev/null)"
zenity --error --width=760 --height=420 --title="StrayOS Installer failed" --text="Installation failed.\n\nLast log lines:\n\n$tail_msg" 2>/dev/null || true
rm -f "$input"
exit 1
EOF
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-install-gui"

  sudo sync
  cleanup_one
  trap - RETURN
}

resize_image "$BOOT_IMG"
resize_image "$SOURCE_IMG"
configure_kernel_modules
patch_one "$BOOT_IMG" /tmp/strayos-drivers-boot
patch_one "$SOURCE_IMG" /tmp/strayos-drivers-source

sha256sum "$BOOT_IMG" > "$BOOT_IMG.sha256"
sha256sum "$SOURCE_IMG" > "$SOURCE_IMG.sha256"

ls -lh "$BOOT_IMG" "$BOOT_IMG.sha256" "$SOURCE_IMG" "$SOURCE_IMG.sha256"
echo "Patched drivers, firmware, modules, and progress installer."
