#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-gnome-check}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR/proc"; then sudo umount "$MOUNT_DIR/proc"; fi
  if mountpoint -q "$MOUNT_DIR/sys"; then sudo umount "$MOUNT_DIR/sys"; fi
  if mountpoint -q "$MOUNT_DIR/dev/pts"; then sudo umount "$MOUNT_DIR/dev/pts"; fi
  if mountpoint -q "$MOUNT_DIR/dev"; then sudo umount "$MOUNT_DIR/dev"; fi
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup EXIT

sudo mount --bind /dev "$MOUNT_DIR/dev"
sudo mount -t devpts devpts "$MOUNT_DIR/dev/pts"
sudo mount -t proc proc "$MOUNT_DIR/proc"
sudo mount -t sysfs sysfs "$MOUNT_DIR/sys"
sudo cp /etc/resolv.conf "$MOUNT_DIR/etc/resolv.conf"

echo "--- identity ---"
sudo chroot "$MOUNT_DIR" sh -lc "cat /etc/os-release; echo; apt --version; neofetch --version 2>/dev/null || true"

echo "--- disk ---"
df -h "$MOUNT_DIR"

echo "--- package candidates ---"
sudo chroot "$MOUNT_DIR" apt-get update >/dev/null
for package in \
  gnome-shell \
  gnome-session \
  gnome-terminal \
  nautilus \
  dbus-x11 \
  xorg \
  xinit \
  gdm3 \
  yaru-theme-gtk \
  yaru-theme-icon \
  yaru-theme-sound \
  gnome-shell-extension-dashtodock \
  gnome-shell-extension-appindicator
do
  echo "### $package"
  sudo chroot "$MOUNT_DIR" apt-cache policy "$package" | sed -n '1,8p'
done
