#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
IMAGE="${IMAGE:-$PROJECT_DIR/disks/strayos-5g.img}"
KERNEL="${KERNEL:-$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage}"
WORK_DIR="${WORK_DIR:-$HOME/strayos-img-iso}"
MOUNT_DIR="$WORK_DIR/mnt"
ISO_TREE="$WORK_DIR/iso-tree"
OUT_DIR="$PROJECT_DIR/iso"
LOG_DIR="$PROJECT_DIR/build/logs"
ISO_PATH="$OUT_DIR/StrayOS-base-gnome-debian-apt-amd64.iso"

mkdir -p "$WORK_DIR" "$MOUNT_DIR" "$ISO_TREE" "$OUT_DIR" "$LOG_DIR"

if [[ ! -f "$IMAGE" ]]; then
  echo "Missing StrayOS image: $IMAGE" >&2
  exit 1
fi

if [[ ! -f "$KERNEL" ]]; then
  echo "Missing kernel: $KERNEL" >&2
  exit 1
fi

if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop,ro "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then
    sudo umount "$MOUNT_DIR"
  fi
}
trap cleanup EXIT

rm -rf "$ISO_TREE"
mkdir -p "$ISO_TREE/boot/grub" "$ISO_TREE/strayos"

cp "$KERNEL" "$ISO_TREE/strayos/vmlinuz"

sudo sh -c "cd '$MOUNT_DIR' && find . \
  -path './dev/*' -prune -o \
  -path './proc/*' -prune -o \
  -path './sys/*' -prune -o \
  -path './run/*' -prune -o \
  -path './tmp/*' -prune -o \
  -path './var/cache/apt/archives/*.deb' -prune -o \
  -print0 | cpio --null -o --format=newc | gzip -9 > '$ISO_TREE/strayos/initramfs.cpio.gz'" \
  2>&1 | tee "$LOG_DIR/strayos-img-iso-cpio.log"

cat > "$ISO_TREE/boot/grub/grub.cfg" <<'EOF'
serial --unit=0 --speed=115200
terminal_input console serial
terminal_output console serial

set timeout=8
set default=0

menuentry "Boot StrayOS base + GNOME (Debian APT)" {
    linux /strayos/vmlinuz console=tty0 console=ttyS0 nomodeset panic=0
    initrd /strayos/initramfs.cpio.gz
}

menuentry "Boot StrayOS console debug" {
    linux /strayos/vmlinuz console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel
    initrd /strayos/initramfs.cpio.gz
}

menuentry "Boot StrayOS ISO integrity test" {
    linux /strayos/vmlinuz console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel strayos.autotest=1
    initrd /strayos/initramfs.cpio.gz
}
EOF

cat > "$ISO_TREE/README.txt" <<'EOF'
StrayOS base + Xorg + GNOME Shell + Yaru + dock

This ISO was built from F:\StrayOS\disks\strayos-5g.img.
It keeps the StrayOS identity, Debian apt, and neofetch.

GNOME does not autostart. Boot to console and run:

  strayos-gnome
EOF

grub-mkrescue -o "$ISO_PATH" "$ISO_TREE" 2>&1 | tee "$LOG_DIR/strayos-img-iso-grub.log"
sha256sum "$ISO_PATH" > "$ISO_PATH.sha256"

cleanup
trap - EXIT

ls -lh "$ISO_PATH" "$ISO_PATH.sha256" "$ISO_TREE/strayos/initramfs.cpio.gz"
echo "Built StrayOS ISO from image: $ISO_PATH"
