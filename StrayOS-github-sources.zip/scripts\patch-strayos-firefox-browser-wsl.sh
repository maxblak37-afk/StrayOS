#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
images=(
  "$PROJECT_DIR/disks/strayos-5g.img"
  "$PROJECT_DIR/disks/StrayOS-bootable-5g.img"
)

mount_image() {
  local image="$1" mount_dir="$2"
  sudo mkdir -p "$mount_dir"
  local loop_dev part
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  sleep 1
  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"
  sudo mount "$part" "$mount_dir"
  echo "$loop_dev"
}

bind_chroot() {
  local mount_dir="$1"
  sudo mount --bind /dev "$mount_dir/dev"
  sudo mount -t proc proc "$mount_dir/proc"
  sudo mount -t sysfs sysfs "$mount_dir/sys"
  sudo mount -t tmpfs tmpfs "$mount_dir/run"
  sudo cp /etc/resolv.conf "$mount_dir/etc/resolv.conf"
  printf '#!/bin/sh\nexit 101\n' | sudo tee "$mount_dir/usr/sbin/policy-rc.d" >/dev/null
  sudo chmod +x "$mount_dir/usr/sbin/policy-rc.d"
}

unbind_chroot() {
  local mount_dir="$1"
  sudo rm -f "$mount_dir/usr/sbin/policy-rc.d" 2>/dev/null || true
  sudo umount "$mount_dir/run" 2>/dev/null || true
  sudo umount "$mount_dir/sys" 2>/dev/null || true
  sudo umount "$mount_dir/proc" 2>/dev/null || true
  sudo umount "$mount_dir/dev" 2>/dev/null || true
}

install_browser() {
  local mount_dir="$1"
  bind_chroot "$mount_dir"
  sudo chroot "$mount_dir" sh -lc '
    set -e
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    apt-get install -y --no-install-recommends firefox-esr ca-certificates fonts-liberation
    apt-get clean
    rm -rf /var/lib/apt/lists/*
  '
  unbind_chroot "$mount_dir"
}

patch_launchers() {
  local mount_dir="$1"
  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-browser-session" >/dev/null
#!/bin/sh
set +e
export LIBGL_ALWAYS_SOFTWARE=1
export MOZ_DISABLE_RDD_SANDBOX=1
export MOZ_DISABLE_CONTENT_SANDBOX=1
export XDG_SESSION_TYPE=x11
export XDG_RUNTIME_DIR=/run/user/0

mkdir -p /run/user/0 /tmp
chmod 700 /run/user/0 2>/dev/null || true
openbox >/tmp/strayos-browser-openbox.log 2>&1 &
sleep 1
firefox-esr >/tmp/strayos-firefox.log 2>&1 &
xterm -fa Monospace -fs 12 -geometry 100x28+40+40 -title "StrayOS Browser" -e /bin/bash -lc 'echo "Firefox ESR started."; echo "Close this terminal to leave the browser session."; echo; exec /bin/bash -l'
EOF

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-browser" >/dev/null
#!/bin/sh
set +e
export LIBGL_ALWAYS_SOFTWARE=1
export MOZ_DISABLE_RDD_SANDBOX=1
export MOZ_DISABLE_CONTENT_SANDBOX=1
export XDG_SESSION_TYPE=x11
export XDG_RUNTIME_DIR=/run/user/0

if ! command -v firefox-esr >/dev/null 2>&1; then
  echo "Firefox ESR is not installed."
  exit 1
fi

strayos-start-udev 2>/dev/null || true
strayos-network-autostart >/tmp/strayos-network-autostart.log 2>&1 &
mkdir -p /run/user/0 /tmp/.X11-unix
chmod 700 /run/user/0 2>/dev/null || true
chmod 1777 /tmp /tmp/.X11-unix 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true

if [ -n "${DISPLAY:-}" ]; then
  exec firefox-esr
fi

rm -f /tmp/.X0-lock /tmp/.X11-unix/X0
echo "Starting Firefox ESR in a lightweight StrayOS X session..."
exec dbus-run-session -- startx /usr/local/bin/strayos-browser-session -- :0 vt2 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-browser" "$mount_dir/usr/local/bin/strayos-browser-session"

  if ! sudo grep -q 'echo "  strayos-browser"' "$mount_dir/init"; then
    sudo sed -i '/echo "  strayos-light"/a echo "  strayos-browser"' "$mount_dir/init" 2>/dev/null || true
  fi
  sudo sh -n "$mount_dir/usr/local/bin/strayos-browser"
  sudo sh -n "$mount_dir/usr/local/bin/strayos-browser-session"
}

for image in "${images[@]}"; do
  mount_dir="/tmp/strayos-firefox-$(basename "$image" .img)"
  loop_dev=""
  cleanup() {
    if [[ -n "$mount_dir" ]]; then
      unbind_chroot "$mount_dir" || true
      if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    fi
    if [[ -n "$loop_dev" ]]; then sudo losetup -d "$loop_dev" || true; fi
  }
  trap cleanup RETURN

  echo "Patching browser in $image"
  loop_dev="$(mount_image "$image" "$mount_dir")"
  install_browser "$mount_dir"
  patch_launchers "$mount_dir"
  sudo chroot "$mount_dir" sh -lc 'firefox-esr --version || true; command -v firefox-esr; command -v strayos-browser'
  sudo sync
  cleanup
  trap - RETURN
done

sha256sum "$PROJECT_DIR/disks/StrayOS-bootable-5g.img" > "$PROJECT_DIR/disks/StrayOS-bootable-5g.img.sha256"
sha256sum "$PROJECT_DIR/disks/strayos-5g.img" > "$PROJECT_DIR/disks/strayos-5g.img.sha256"
echo "Patched Firefox ESR browser into StrayOS images."
