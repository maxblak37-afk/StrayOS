#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-clean-init}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then
    sudo umount "$MOUNT_DIR"
  fi
}
trap cleanup EXIT

sudo awk '
  /echo "  strayos-install-help"/ { if (seen_help++) next }
  /echo "  strayos-install"/ { if (seen_install++) next }
  { print }
' "$MOUNT_DIR/init" | sudo tee "$MOUNT_DIR/init.clean" >/dev/null

sudo mv "$MOUNT_DIR/init.clean" "$MOUNT_DIR/init"
sudo chmod +x "$MOUNT_DIR/init"
sudo sync

echo "Current installer lines in /init:"
sudo grep -n 'strayos-install' "$MOUNT_DIR/init" || true
