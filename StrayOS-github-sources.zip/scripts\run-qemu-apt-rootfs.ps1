$ErrorActionPreference = "Stop"

wsl sh -lc "cd /mnt/f/StrayOS/build/apt-rootfs && ./run-qemu.sh"
