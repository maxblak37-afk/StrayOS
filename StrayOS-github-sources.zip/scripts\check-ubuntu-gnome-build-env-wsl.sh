#!/usr/bin/env bash
set -euo pipefail

echo "--- packages ---"
for package in \
  ubuntu-desktop-minimal \
  ubuntu-session \
  gnome-shell-extension-ubuntu-dock \
  yaru-theme-gtk \
  yaru-theme-icon \
  gnome-session-flashback \
  casper \
  linux-image-generic
do
  echo "### $package"
  apt-cache policy "$package" | sed -n '1,6p'
done

echo "--- tools ---"
for command in debootstrap mksquashfs xorriso grub-mkrescue qemu-system-x86_64; do
  printf "%-18s " "$command"
  command -v "$command" || true
done

echo "--- disk ---"
df -h / /mnt/f
