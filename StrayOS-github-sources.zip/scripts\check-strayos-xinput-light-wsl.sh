#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-xinput-light-check}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

test -x "$MOUNT_DIR/usr/local/sbin/strayos-start-udev"
test -x "$MOUNT_DIR/usr/local/bin/strayos-light"
test -x "$MOUNT_DIR/usr/local/bin/strayos-light-session"
test -x "$MOUNT_DIR/usr/local/bin/strayos-xterm-test"
test -x "$MOUNT_DIR/usr/local/bin/strayos-diag"
test -f "$MOUNT_DIR/etc/X11/xorg.conf.d/20-strayos-input.conf"
test -x "$MOUNT_DIR/usr/bin/openbox"
test -x "$MOUNT_DIR/usr/bin/xterm"

grep -q 'Driver "evdev"' "$MOUNT_DIR/etc/X11/xorg.conf.d/20-strayos-input.conf"
grep -q 'openbox' "$MOUNT_DIR/usr/local/bin/strayos-light-session"
grep -q 'strayos-start-udev' "$MOUNT_DIR/usr/local/bin/strayos-light"

echo "Xorg input/light session check: OK"
