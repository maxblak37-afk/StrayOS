#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-gnome-look}"
PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR/proc"; then sudo umount "$MOUNT_DIR/proc"; fi
  if mountpoint -q "$MOUNT_DIR/sys"; then sudo umount "$MOUNT_DIR/sys"; fi
  if mountpoint -q "$MOUNT_DIR/dev/pts"; then sudo umount "$MOUNT_DIR/dev/pts"; fi
  if mountpoint -q "$MOUNT_DIR/dev"; then sudo umount "$MOUNT_DIR/dev"; fi
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup EXIT

sudo mount --bind /dev "$MOUNT_DIR/dev"
sudo mount -t devpts devpts "$MOUNT_DIR/dev/pts"
sudo mount -t proc proc "$MOUNT_DIR/proc"
sudo mount -t sysfs sysfs "$MOUNT_DIR/sys"
sudo cp /etc/resolv.conf "$MOUNT_DIR/etc/resolv.conf"

sudo chroot "$MOUNT_DIR" apt-get update
sudo chroot "$MOUNT_DIR" env DEBIAN_FRONTEND=noninteractive apt-get install -y \
  gnome-shell \
  gnome-session \
  gnome-terminal \
  nautilus \
  dbus-x11 \
  xorg \
  xinit \
  xserver-xorg-video-fbdev \
  xserver-xorg-video-vesa \
  xserver-xorg-video-qxl \
  xserver-xorg-video-all \
  yaru-theme-gtk \
  yaru-theme-icon \
  yaru-theme-sound \
  gnome-shell-extension-dashtodock \
  gnome-shell-extension-appindicator \
  gnome-tweaks \
  neofetch

sudo tee "$MOUNT_DIR/etc/os-release" >/dev/null <<'EOF'
NAME=StrayOS
ID=strayos
PRETTY_NAME="StrayOS"
VERSION_ID=0.0.3
ID_LIKE=debian
EOF

sudo tee "$MOUNT_DIR/etc/lsb-release" >/dev/null <<'EOF'
DISTRIB_ID=StrayOS
DISTRIB_RELEASE=0.0.3
DISTRIB_CODENAME=bookworm
DISTRIB_DESCRIPTION="StrayOS"
EOF

sudo tee "$MOUNT_DIR/etc/issue" >/dev/null <<'EOF'
StrayOS 0.0.3 \n \l

EOF

sudo tee "$MOUNT_DIR/etc/hostname" >/dev/null <<'EOF'
strayos
EOF

sudo tee "$MOUNT_DIR/etc/hosts" >/dev/null <<'EOF'
127.0.0.1 localhost
127.0.1.1 strayos
EOF

sudo mkdir -p "$MOUNT_DIR/etc/dconf/profile" "$MOUNT_DIR/etc/dconf/db/local.d" "$MOUNT_DIR/etc/X11/xorg.conf.d" "$MOUNT_DIR/root"

sudo tee "$MOUNT_DIR/etc/dconf/profile/user" >/dev/null <<'EOF'
user-db:user
system-db:local
EOF

sudo tee "$MOUNT_DIR/etc/dconf/db/local.d/00-strayos-gnome" >/dev/null <<'EOF'
[org/gnome/desktop/interface]
gtk-theme='Yaru'
icon-theme='Yaru'
cursor-theme='Yaru'
color-scheme='prefer-dark'

[org/gnome/shell]
enabled-extensions=['dash-to-dock@micxgx.gmail.com','appindicatorsupport@rgcjonas.gmail.com']
favorite-apps=['org.gnome.Nautilus.desktop','org.gnome.Terminal.desktop','org.gnome.tweaks.desktop']

[org/gnome/shell/extensions/dash-to-dock]
dock-position='LEFT'
extend-height=true
dock-fixed=true
show-trash=false
show-mounts=false
intellihide=false
dash-max-icon-size=48

[org/gnome/desktop/wm/preferences]
button-layout='appmenu:minimize,maximize,close'
EOF

sudo chroot "$MOUNT_DIR" dconf update || true

sudo tee "$MOUNT_DIR/etc/X11/Xwrapper.config" >/dev/null <<'EOF'
allowed_users=anybody
needs_root_rights=yes
EOF

sudo tee "$MOUNT_DIR/root/.xinitrc" >/dev/null <<'EOF'
#!/bin/sh
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
export XDG_SESSION_TYPE=x11
export GDK_BACKEND=x11
export CLUTTER_BACKEND=x11
export LIBGL_ALWAYS_SOFTWARE=1
export XDG_RUNTIME_DIR=/run/user/0

mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"
dbus-daemon --system --fork 2>/dev/null || true

exec dbus-run-session -- gnome-session --session=gnome
EOF
sudo chmod +x "$MOUNT_DIR/root/.xinitrc"

sudo tee "$MOUNT_DIR/usr/local/bin/strayos-gnome" >/dev/null <<'EOF'
#!/bin/sh
export LIBGL_ALWAYS_SOFTWARE=1
exec startx /root/.xinitrc -- :0 vt1
EOF
sudo chmod +x "$MOUNT_DIR/usr/local/bin/strayos-gnome"

sudo tee "$MOUNT_DIR/init" >/dev/null <<'EOF'
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TERM=linux
export LANG=C.UTF-8

mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /run /tmp /root /run/user/0
mount -t devpts devpts /dev/pts 2>/dev/null
chmod 1777 /tmp
chmod 700 /run/user/0
hostname strayos 2>/dev/null

ip link set lo up 2>/dev/null
ip link set eth0 up 2>/dev/null
dhclient -1 eth0 2>/dev/null || true

clear
cat /etc/issue 2>/dev/null
echo "Kernel: $(uname -r)"
echo "Disk: 5 GB persistent ext4 image"
echo
echo "StrayOS base is still Debian APT:"
apt --version 2>/dev/null
echo
echo "Try:"
echo "  neofetch"
echo "  apt-get check"
echo "  strayos-gnome"
echo
echo "GNOME is manual, not autostarted."
echo "Power off: poweroff -f"
echo

if grep -q 'strayos.autotest=1' /proc/cmdline 2>/dev/null; then
  echo "[autotest] identity:"
  cat /etc/os-release
  echo
  echo "[autotest] apt:"
  apt --version
  echo
  echo "[autotest] neofetch:"
  neofetch --version
  echo
  echo "[autotest] packages:"
  dpkg-query -W -f='${binary:Package}\n' gnome-shell gnome-session yaru-theme-gtk yaru-theme-icon gnome-shell-extension-dashtodock neofetch
  echo
  poweroff -f
fi

cd /root
exec /bin/busybox cttyhack /bin/bash -l
EOF
sudo chmod +x "$MOUNT_DIR/init"
sudo ln -sf busybox "$MOUNT_DIR/bin/poweroff"
sudo ln -sf busybox "$MOUNT_DIR/bin/reboot"

cat > "$PROJECT_DIR/build/disk/run-qemu-strayos-gnome-look.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"

qemu-system-x86_64 \
  -m 4096M \
  -smp 4 \
  -kernel "$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage" \
  -append "root=/dev/sda rw init=/init console=tty0 nomodeset panic=-1" \
  -drive "file=$PROJECT_DIR/disks/strayos-5g.img,format=raw,if=ide,index=0,media=disk" \
  -netdev user,id=net0 \
  -device e1000,netdev=net0 \
  -display sdl \
  -vga std
EOF
chmod +x "$PROJECT_DIR/build/disk/run-qemu-strayos-gnome-look.sh"

cat > "$PROJECT_DIR/build/disk/run-qemu-strayos-gnome-look-test.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"

qemu-system-x86_64 \
  -m 4096M \
  -smp 4 \
  -kernel "$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage" \
  -append "root=/dev/sda rw init=/init console=ttyS0 nomodeset panic=-1 strayos.autotest=1" \
  -drive "file=$PROJECT_DIR/disks/strayos-5g.img,format=raw,if=ide,index=0,media=disk" \
  -netdev user,id=net0 \
  -device e1000,netdev=net0 \
  -serial stdio \
  -display none
EOF
chmod +x "$PROJECT_DIR/build/disk/run-qemu-strayos-gnome-look-test.sh"

cat > "$PROJECT_DIR/scripts/run-qemu-strayos-gnome-look.ps1" <<'EOF'
$ErrorActionPreference = "Stop"

wsl sh -lc "cd /mnt/f/StrayOS/build/disk && ./run-qemu-strayos-gnome-look.sh"
EOF

sudo sync
echo "Configured StrayOS base + Xorg + GNOME Shell + dock + Yaru without changing Debian APT base."
