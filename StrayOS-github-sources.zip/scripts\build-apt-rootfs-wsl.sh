#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
WORK_DIR="${WORK_DIR:-$HOME/strayos-apt-rootfs}"
ROOTFS="$WORK_DIR/rootfs"
OUT_DIR="$PROJECT_DIR/build/apt-rootfs"
LOG_DIR="$PROJECT_DIR/build/logs"
DEBIAN_SUITE="${DEBIAN_SUITE:-bookworm}"
DEBIAN_MIRROR="${DEBIAN_MIRROR:-http://deb.debian.org/debian}"

mkdir -p "$WORK_DIR" "$OUT_DIR" "$LOG_DIR"

if [[ ! -d "$ROOTFS/bin" ]]; then
  sudo rm -rf "$ROOTFS"
  sudo debootstrap \
    --arch=amd64 \
    --variant=minbase \
    --include=apt,bash,ca-certificates,iproute2,iputils-ping,nano,less,procps,zsh,neofetch,netbase,isc-dhcp-client \
    "$DEBIAN_SUITE" \
    "$ROOTFS" \
    "$DEBIAN_MIRROR" 2>&1 | tee "$LOG_DIR/debootstrap-apt-rootfs.log"
fi

sudo install -m 0755 /usr/bin/busybox "$ROOTFS/bin/busybox"

sudo tee "$ROOTFS/etc/hostname" >/dev/null <<'EOF'
strayos
EOF

sudo tee "$ROOTFS/etc/hosts" >/dev/null <<'EOF'
127.0.0.1 localhost
127.0.1.1 strayos
EOF

sudo tee "$ROOTFS/etc/resolv.conf" >/dev/null <<'EOF'
nameserver 10.0.2.3
nameserver 1.1.1.1
EOF

sudo tee "$ROOTFS/etc/os-release" >/dev/null <<'EOF'
NAME=StrayOS
ID=strayos
PRETTY_NAME="StrayOS Debian-APT rootfs"
VERSION_ID=0.0.2
ID_LIKE=debian
EOF

sudo tee "$ROOTFS/etc/apt/sources.list" >/dev/null <<EOF
deb $DEBIAN_MIRROR $DEBIAN_SUITE main
deb $DEBIAN_MIRROR $DEBIAN_SUITE-updates main
deb http://security.debian.org/debian-security $DEBIAN_SUITE-security main
EOF

sudo tee "$ROOTFS/init" >/dev/null <<'EOF'
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /run /tmp
mount -t devpts devpts /dev/pts 2>/dev/null
chmod 1777 /tmp
hostname strayos 2>/dev/null

echo
echo "StrayOS with Debian APT rootfs"
echo "Kernel: $(uname -r)"
echo

if command -v dhclient >/dev/null 2>&1; then
  ip link set lo up 2>/dev/null
  ip link set eth0 up 2>/dev/null
  dhclient -1 eth0 2>/dev/null || true
fi

echo "Available checks:"
echo "  apt --version"
echo "  dpkg --version"
echo "  bash --version"
echo "  zsh --version"
echo "  neofetch"
echo

cd /root
exec /bin/bash -l
EOF
sudo chmod +x "$ROOTFS/init"
sudo ln -sf busybox "$ROOTFS/bin/poweroff"
sudo ln -sf busybox "$ROOTFS/bin/reboot"

sudo mkdir -p "$ROOTFS/root" "$ROOTFS/var/lib/apt/lists/partial" "$ROOTFS/var/cache/apt/archives/partial"

sudo chroot "$ROOTFS" /bin/bash -lc "apt --version && dpkg --version | head -1 && bash --version | head -1 && zsh --version" \
  2>&1 | tee "$LOG_DIR/apt-rootfs-tool-versions.log"

sudo find "$ROOTFS" -xdev -type f -name '*.pyc' -delete
sudo find "$ROOTFS/var/cache/apt/archives" -type f -name '*.deb' -delete

sudo sh -c "cd '$ROOTFS' && find . -print0 | cpio --null -o --format=newc | gzip -9 > '$OUT_DIR/strayos-apt-rootfs.cpio.gz'"

cat > "$OUT_DIR/run-qemu.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"
qemu-system-x86_64 \
  -m 2048M \
  -kernel "$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage" \
  -initrd "$DIR/strayos-apt-rootfs.cpio.gz" \
  -append "console=ttyS0 quiet panic=-1" \
  -netdev user,id=net0 \
  -device e1000,netdev=net0 \
  -nographic \
  -no-reboot
EOF
chmod +x "$OUT_DIR/run-qemu.sh"

cat > "$OUT_DIR/run-qemu-test.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"
timeout 90 qemu-system-x86_64 \
  -m 2048M \
  -kernel "$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage" \
  -initrd "$DIR/strayos-apt-rootfs.cpio.gz" \
  -append "console=ttyS0 quiet panic=-1" \
  -netdev user,id=net0 \
  -device e1000,netdev=net0 \
  -nographic \
  -no-reboot
EOF
chmod +x "$OUT_DIR/run-qemu-test.sh"

cat > "$OUT_DIR/README.md" <<EOF
# StrayOS APT Rootfs

This image adds a Debian $DEBIAN_SUITE userspace with:

- apt
- dpkg
- bash
- zsh
- nano
- iproute2
- ping
- neofetch

Run from WSL:

\`\`\`sh
cd "$OUT_DIR"
./run-qemu.sh
\`\`\`
EOF

ls -lh "$OUT_DIR/strayos-apt-rootfs.cpio.gz"
echo "Built StrayOS APT rootfs in $OUT_DIR"
