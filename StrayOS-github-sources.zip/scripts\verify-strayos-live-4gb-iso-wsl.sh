#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
ISO="${ISO:-$PROJECT_DIR/iso/StrayOS-live-4gb-amd64.iso}"
TREE="${TREE:-$PROJECT_DIR/build/live-4gb-iso/iso-tree}"
LOG="${LOG:-$PROJECT_DIR/build/logs/strayos-live-4gb-iso-qemu.log}"

sha256sum -c "$ISO.sha256"

rm -f "$LOG"
set +e
timeout 180 qemu-system-x86_64 \
  -m 4096M \
  -smp 2 \
  -kernel "$TREE/strayos/vmlinuz" \
  -initrd "$TREE/strayos/initramfs.cpio.gz" \
  -append "init=/init console=ttyS0 nomodeset panic=0" \
  -drive "file=$ISO,format=raw,media=cdrom,readonly=on" \
  -serial stdio \
  -display none \
  >"$LOG" 2>&1
STATUS=$?
set -e

if grep -q 'Found StrayOS media' "$LOG" && grep -q 'root@strayos' "$LOG"; then
  echo "StrayOS live 4GB ISO booted in QEMU: OK"
  exit 0
fi

echo "Live ISO boot verification failed. QEMU status: $STATUS" >&2
tail -160 "$LOG" >&2 || true
exit 1
