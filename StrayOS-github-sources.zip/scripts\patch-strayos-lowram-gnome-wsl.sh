#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
BOOT_IMG="${BOOT_IMG:-$PROJECT_DIR/disks/StrayOS-bootable-5g.img}"
SOURCE_IMG="${SOURCE_IMG:-$PROJECT_DIR/disks/strayos-5g.img}"

patch_one() {
  local image="$1" mount_dir="$2" loop_dev part avail_mb swap_mb

  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup_one() {
    if mountpoint -q "$mount_dir/dev"; then sudo umount "$mount_dir/dev"; fi
    if mountpoint -q "$mount_dir/proc"; then sudo umount "$mount_dir/proc"; fi
    if mountpoint -q "$mount_dir/sys"; then sudo umount "$mount_dir/sys"; fi
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup_one RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi

  sudo mount "$part" "$mount_dir"

  avail_mb="$(df -Pm "$mount_dir" | awk 'NR==2 {print $4}')"
  swap_mb=768
  if (( avail_mb > 1400 )); then
    swap_mb=1024
  elif (( avail_mb < 950 )); then
    swap_mb=512
  fi

  if [[ ! -f "$mount_dir/swapfile" ]]; then
    echo "Creating ${swap_mb}M swapfile in $image"
    sudo dd if=/dev/zero of="$mount_dir/swapfile" bs=1M count="$swap_mb" status=progress
    sudo chmod 600 "$mount_dir/swapfile"
    sudo mkswap "$mount_dir/swapfile"
  fi

  if ! grep -q '^/swapfile ' "$mount_dir/etc/fstab" 2>/dev/null; then
    echo '/swapfile none swap sw 0 0' | sudo tee -a "$mount_dir/etc/fstab" >/dev/null
  fi

  sudo mkdir -p "$mount_dir/usr/local/bin" "$mount_dir/root/.config/dconf"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-xterm-test" >/dev/null
#!/bin/sh
export XDG_SESSION_TYPE=x11
mkdir -p /run/dbus /run/user/0 /tmp
chmod 700 /run/user/0 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true
echo "Starting lightweight Xorg test. If this opens xterm, video works."
exec startx /usr/bin/xterm -- :0 vt1 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-xterm-test"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-gnome-safe" >/dev/null
#!/bin/sh
export LIBGL_ALWAYS_SOFTWARE=1
export MUTTER_DEBUG_DISABLE_HW_CURSORS=1
export CLUTTER_VBLANK=none
export GSK_RENDERER=cairo
export XDG_SESSION_TYPE=x11
export XDG_CURRENT_DESKTOP=GNOME
export GDMSESSION=gnome

mkdir -p /run/dbus /run/user/0 /tmp
chmod 700 /run/user/0 2>/dev/null || true
swapon /swapfile 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true

gsettings set org.gnome.desktop.interface enable-animations false 2>/dev/null || true
gsettings set org.gnome.mutter experimental-features "[]" 2>/dev/null || true
gnome-extensions disable dash-to-dock@micxgx.gmail.com 2>/dev/null || true
gnome-extensions disable ubuntu-dock@ubuntu.com 2>/dev/null || true

echo "Starting StrayOS GNOME safe mode..."
echo "This uses software rendering and swap. It can be slow on 4GB RAM."
exec dbus-run-session -- startx /root/.xinitrc -- :0 vt1 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-gnome-safe"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-gnome" >/dev/null
#!/bin/sh
export LIBGL_ALWAYS_SOFTWARE=1
export MUTTER_DEBUG_DISABLE_HW_CURSORS=1
export XDG_SESSION_TYPE=x11
export XDG_CURRENT_DESKTOP=GNOME
export GDMSESSION=gnome

mkdir -p /run/dbus /run/user/0 /tmp
chmod 700 /run/user/0 2>/dev/null || true
swapon /swapfile 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true

gsettings set org.gnome.desktop.interface enable-animations false 2>/dev/null || true

echo "Starting StrayOS GNOME through Xorg..."
echo "If it freezes on 4GB RAM, reboot and run: strayos-gnome-safe"
exec dbus-run-session -- startx /root/.xinitrc -- :0 vt1 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-gnome"

  if ! grep -q 'swapon /swapfile' "$mount_dir/init"; then
    sudo awk '
      /hostname strayos/ {
        print
        print "swapon /swapfile 2>/dev/null || true"
        print "sysctl -w vm.swappiness=80 >/dev/null 2>&1 || true"
        next
      }
      { print }
    ' "$mount_dir/init" | sudo tee "$mount_dir/init.lowram" >/dev/null
    sudo mv "$mount_dir/init.lowram" "$mount_dir/init"
    sudo chmod +x "$mount_dir/init"
  fi

  if grep -q 'echo "  strayos-install"' "$mount_dir/init"; then
    if ! grep -q 'echo "  strayos-xterm-test"' "$mount_dir/init"; then
      sudo sed -i '/echo "  strayos-gnome"/a echo "  strayos-gnome-safe"\
echo "  strayos-xterm-test"' "$mount_dir/init"
    fi
  fi

  if [[ -x "$mount_dir/usr/bin/apt-get" ]]; then
    sudo mount --bind /dev "$mount_dir/dev"
    sudo mount -t proc proc "$mount_dir/proc"
    sudo mount -t sysfs sysfs "$mount_dir/sys"
    sudo cp /etc/resolv.conf "$mount_dir/etc/resolv.conf"
    sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get update
    sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get install -y xterm mesa-utils
  fi

  sudo sync
  cleanup_one
  trap - RETURN
}

patch_one "$BOOT_IMG" /tmp/strayos-lowram-boot
patch_one "$SOURCE_IMG" /tmp/strayos-lowram-source

sha256sum "$BOOT_IMG" > "$BOOT_IMG.sha256"
echo "Patched low-RAM GNOME helpers and swap."
echo "Updated: $BOOT_IMG"
