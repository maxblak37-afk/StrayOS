$ErrorActionPreference = 'Stop'

$diskNumber = 2
$expectedBus = 'USB'
$newLabel = 'STRAYOS_DISK'
$newLetter = 'E'

Write-Host "StrayOS disk formatter" -ForegroundColor Cyan
Write-Host "Target: Disk $diskNumber" -ForegroundColor Yellow

$disk = Get-Disk -Number $diskNumber
$disk | Format-List Number,FriendlyName,SerialNumber,BusType,PartitionStyle,Size,IsBoot,IsSystem,IsReadOnly,OperationalStatus

if ($disk.IsBoot -or $disk.IsSystem) {
    throw "Refusing to format: Disk $diskNumber is marked as boot/system."
}

if ($disk.BusType -ne $expectedBus) {
    throw "Refusing to format: Disk $diskNumber BusType is '$($disk.BusType)', expected '$expectedBus'."
}

Write-Host ""
Write-Host "THIS WILL ERASE ALL PARTITIONS ON DISK $diskNumber." -ForegroundColor Red
Write-Host "Type exactly: FORMAT DISK $diskNumber" -ForegroundColor Yellow
$answer = Read-Host "Confirm"
if ($answer -ne "FORMAT DISK $diskNumber") {
    throw "Confirmation did not match. Aborted."
}

Set-Disk -Number $diskNumber -IsOffline $false
Set-Disk -Number $diskNumber -IsReadOnly $false

Get-Partition -DiskNumber $diskNumber -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.DriveLetter) {
        Remove-PartitionAccessPath -DiskNumber $diskNumber -PartitionNumber $_.PartitionNumber -AccessPath "$($_.DriveLetter):\" -ErrorAction SilentlyContinue
    }
}

Clear-Disk -Number $diskNumber -RemoveData -RemoveOEM -Confirm:$false
Initialize-Disk -Number $diskNumber -PartitionStyle MBR
$partition = New-Partition -DiskNumber $diskNumber -UseMaximumSize -DriveLetter $newLetter
Format-Volume -Partition $partition -FileSystem NTFS -NewFileSystemLabel $newLabel -Confirm:$false -Force | Out-Null

Write-Host ""
Write-Host "Done. Disk $diskNumber is formatted as $newLetter`: NTFS ($newLabel)." -ForegroundColor Green
Get-Disk -Number $diskNumber | Format-List Number,FriendlyName,BusType,PartitionStyle,Size,IsBoot,IsSystem
Get-Volume -DriveLetter $newLetter | Format-List DriveLetter,FileSystemLabel,FileSystem,Size,SizeRemaining

Read-Host "Press Enter to close"
