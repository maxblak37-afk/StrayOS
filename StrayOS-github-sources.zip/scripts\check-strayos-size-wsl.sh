#!/usr/bin/env bash
set -euo pipefail

MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-size-check}"
IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then
    sudo umount "$MOUNT_DIR"
  fi
}
trap cleanup EXIT

df -h "$MOUNT_DIR"
sudo du -sh "$MOUNT_DIR"
sudo du -sh "$MOUNT_DIR/usr" "$MOUNT_DIR/var" "$MOUNT_DIR/boot" 2>/dev/null || true
