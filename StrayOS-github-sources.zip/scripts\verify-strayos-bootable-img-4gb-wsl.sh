#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
LOG="${LOG:-/mnt/f/StrayOS/build/logs/strayos-bootable-img-4gb.log}"

mkdir -p "$(dirname "$LOG")"
rm -f "$LOG"

set +e
timeout 180 qemu-system-x86_64 \
  -m 4096M \
  -smp 2 \
  -drive "file=$IMG,format=raw,if=ide" \
  -serial stdio \
  -display none \
  >"$LOG" 2>&1
STATUS=$?
set -e

if grep -q 'root@strayos' "$LOG" && grep -q 'StrayOS base is still Debian APT' "$LOG"; then
  echo "Bootable StrayOS IMG booted with 4GB RAM: OK"
  exit 0
fi

echo "Boot test did not reach shell. QEMU status: $STATUS" >&2
tail -120 "$LOG" >&2 || true
exit 1
