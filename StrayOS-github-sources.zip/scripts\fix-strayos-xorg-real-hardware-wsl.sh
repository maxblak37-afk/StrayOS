#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
KERNEL_SRC="${KERNEL_SRC:-/root/strayos-build-full/linux-master}"
SOURCE_IMG="${SOURCE_IMG:-$PROJECT_DIR/disks/strayos-5g.img}"
BOOT_IMG="${BOOT_IMG:-$PROJECT_DIR/disks/StrayOS-bootable-5g.img}"
KERNEL_OUT="$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage"
LOG_DIR="$PROJECT_DIR/build/logs"

mkdir -p "$LOG_DIR"

if [[ ! -d "$KERNEL_SRC" ]]; then
  echo "Missing kernel source: $KERNEL_SRC" >&2
  exit 1
fi

echo "Configuring StrayOS kernel graphics fallback..."
cd "$KERNEL_SRC"
scripts/config \
  --enable CONFIG_DEVTMPFS \
  --enable CONFIG_DEVTMPFS_MOUNT \
  --enable CONFIG_INPUT_EVDEV \
  --enable CONFIG_DRM \
  --enable CONFIG_DRM_KMS_HELPER \
  --enable CONFIG_DRM_FBDEV_EMULATION \
  --enable CONFIG_DRM_SIMPLEDRM \
  --enable CONFIG_DRM_VESADRM \
  --enable CONFIG_SYSFB \
  --enable CONFIG_SYSFB_SIMPLEFB \
  --enable CONFIG_FB \
  --enable CONFIG_FB_EFI \
  --enable CONFIG_FB_VESA \
  --enable CONFIG_FRAMEBUFFER_CONSOLE \
  --enable CONFIG_DRM_I915 \
  --enable CONFIG_DRM_VIRTIO_GPU \
  --enable CONFIG_DRM_BOCHS \
  --enable CONFIG_DRM_QXL \
  --enable CONFIG_DRM_VMWGFX \
  --enable CONFIG_DRM_AMDGPU \
  --enable CONFIG_DRM_RADEON \
  --enable CONFIG_DRM_NOUVEAU \
  --enable CONFIG_DRM_AST
make olddefconfig
make -j"$(nproc)" bzImage 2>&1 | tee "$LOG_DIR/fix-xorg-real-hardware-kernel.log"
cp "$KERNEL_SRC/arch/x86/boot/bzImage" "$KERNEL_OUT"

patch_root() {
  local image="$1" mount_dir="$2" loop_dev part
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup_one() {
    if mountpoint -q "$mount_dir/dev"; then sudo umount "$mount_dir/dev"; fi
    if mountpoint -q "$mount_dir/proc"; then sudo umount "$mount_dir/proc"; fi
    if mountpoint -q "$mount_dir/sys"; then sudo umount "$mount_dir/sys"; fi
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup_one RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi
  sudo mount "$part" "$mount_dir"

  sudo mkdir -p "$mount_dir/boot" "$mount_dir/etc/X11/xorg.conf.d"
  sudo cp "$KERNEL_OUT" "$mount_dir/boot/vmlinuz-strayos"

  sudo rm -f "$mount_dir/etc/X11/xorg.conf.d/10-strayos-fbdev.conf"
  cat <<'EOF' | sudo tee "$mount_dir/etc/X11/xorg.conf.d/10-strayos-auto.conf" >/dev/null
Section "Device"
    Identifier "StrayOS Auto GPU"
    Driver "modesetting"
    Option "AccelMethod" "none"
EndSection
EOF

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-gnome" >/dev/null
#!/bin/sh
export LIBGL_ALWAYS_SOFTWARE=1
export MUTTER_DEBUG_DISABLE_HW_CURSORS=1
export XDG_SESSION_TYPE=x11
export XDG_CURRENT_DESKTOP=GNOME
export GDMSESSION=gnome

mkdir -p /run/dbus /run/user/0 /tmp
chmod 700 /run/user/0 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true

echo "Starting StrayOS GNOME through Xorg..."
echo "If it fails, check: /var/log/Xorg.0.log"
exec dbus-run-session -- startx /root/.xinitrc -- :0 vt1 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-gnome"

  if [[ -f "$mount_dir/root/.xinitrc" ]]; then
    sudo sed -n '1,120p' "$mount_dir/root/.xinitrc" >/dev/null
  else
    cat <<'EOF' | sudo tee "$mount_dir/root/.xinitrc" >/dev/null
#!/bin/sh
export XDG_SESSION_TYPE=x11
export XDG_CURRENT_DESKTOP=GNOME
export GDMSESSION=gnome
exec gnome-session
EOF
    sudo chmod +x "$mount_dir/root/.xinitrc"
  fi

  if [[ -x "$mount_dir/usr/bin/apt-get" ]]; then
    sudo mount --bind /dev "$mount_dir/dev"
    sudo mount -t proc proc "$mount_dir/proc"
    sudo mount -t sysfs sysfs "$mount_dir/sys"
    sudo cp /etc/resolv.conf "$mount_dir/etc/resolv.conf"
    sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get update
    sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get install -y \
      xserver-xorg-video-fbdev \
      xserver-xorg-video-vesa \
      xserver-xorg-video-all \
      xserver-xorg-input-libinput \
      dbus-x11
  fi

  sudo sync
  cleanup_one
  trap - RETURN
}

echo "Patching base StrayOS image..."
patch_root "$SOURCE_IMG" /tmp/strayos-xorg-source

echo "Patching bootable StrayOS image..."
patch_root "$BOOT_IMG" /tmp/strayos-xorg-boot

sha256sum "$BOOT_IMG" > "$BOOT_IMG.sha256"

echo "Fixed Xorg real-hardware graphics support."
echo "Updated kernel: $KERNEL_OUT"
echo "Updated image:  $BOOT_IMG"
