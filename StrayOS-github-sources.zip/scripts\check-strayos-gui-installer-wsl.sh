#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-gui-installer-check}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

echo "--- grub ---"
sudo sed -n '1,80p' "$MOUNT_DIR/boot/grub/grub.cfg"

test -x "$MOUNT_DIR/usr/local/sbin/strayos-install-gui"
test -x "$MOUNT_DIR/usr/local/bin/strayos-installer-gui"
test -x "$MOUNT_DIR/usr/local/bin/strayos-installer-gui-session"
test -x "$MOUNT_DIR/usr/bin/zenity"
test -x "$MOUNT_DIR/usr/bin/openbox"
test -x "$MOUNT_DIR/usr/bin/xterm"

grep -q 'nomodeset panic=0' "$MOUNT_DIR/boot/grub/grub.cfg"
grep -q 'StrayOS hardware graphics (experimental)' "$MOUNT_DIR/boot/grub/grub.cfg"
grep -q 'zenity --list' "$MOUNT_DIR/usr/local/sbin/strayos-install-gui"
grep -q 'strayos-installer-gui' "$MOUNT_DIR/init"

echo "--- commands ---"
sudo chroot "$MOUNT_DIR" sh -lc '
for c in strayos-installer-gui strayos-install-gui zenity openbox xterm; do
  printf "%-24s " "$c"
  command -v "$c"
done
'

echo "GUI installer check: OK"
