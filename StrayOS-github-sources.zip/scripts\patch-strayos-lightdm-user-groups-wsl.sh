#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
images=(
  "$PROJECT_DIR/disks/strayos-5g.img"
  "$PROJECT_DIR/disks/StrayOS-bootable-5g.img"
)

patch_image() {
  local image="$1" mount_dir loop_dev part
  mount_dir="/tmp/strayos-lightdm-groups-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  sleep 1
  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  sudo mount "$part" "$mount_dir"
  sudo chroot "$mount_dir" sh -lc '
    set +e
    for g in sudo adm netdev audio video plugdev users; do
      getent group "$g" >/dev/null 2>&1 || groupadd "$g" 2>/dev/null
    done
    id -u stray >/dev/null 2>&1 || useradd -m -s /bin/bash stray
    usermod -aG sudo,adm,netdev,audio,video,plugdev,users stray 2>/dev/null || true
    command -v sudo >/dev/null 2>&1 || true
  '
  echo 'stray ALL=(ALL) ALL' | sudo tee "$mount_dir/etc/sudoers.d/stray" >/dev/null
  sudo chmod 440 "$mount_dir/etc/sudoers.d/stray"
  sudo chroot "$mount_dir" sh -lc 'id stray'
  sudo sync
  cleanup
  trap - RETURN
}

for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum "$PROJECT_DIR/disks/StrayOS-bootable-5g.img" > "$PROJECT_DIR/disks/StrayOS-bootable-5g.img.sha256"
sha256sum "$PROJECT_DIR/disks/strayos-5g.img" > "$PROJECT_DIR/disks/strayos-5g.img.sha256"
echo "Patched StrayOS LightDM user groups and sudo rule."
