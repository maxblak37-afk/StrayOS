#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-inspect}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

sudo mount -o loop "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then
    sudo umount "$MOUNT_DIR"
  fi
}
trap cleanup EXIT

echo "--- df ---"
df -h "$MOUNT_DIR"

echo "--- packages ---"
for package in \
  cinnamon \
  cinnamon-core \
  lightdm \
  xorg \
  xinit \
  dbus \
  dbus-x11 \
  xserver-xorg \
  xserver-xorg-video-vesa \
  xserver-xorg-video-fbdev \
  xserver-xorg-video-qxl \
  xserver-xorg-video-all
do
  printf "%-32s " "$package"
  sudo chroot "$MOUNT_DIR" dpkg-query -W -f='${Status} ${Version}\n' "$package" 2>/dev/null || echo "not-installed"
done
