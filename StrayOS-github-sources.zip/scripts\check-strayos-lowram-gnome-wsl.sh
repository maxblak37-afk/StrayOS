#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-lowram-check}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

df -h "$MOUNT_DIR"
sudo ls -lh "$MOUNT_DIR/swapfile"
grep -q '^/swapfile none swap' "$MOUNT_DIR/etc/fstab"
grep -q 'swapon /swapfile' "$MOUNT_DIR/init"
test -x "$MOUNT_DIR/usr/local/bin/strayos-gnome"
test -x "$MOUNT_DIR/usr/local/bin/strayos-gnome-safe"
test -x "$MOUNT_DIR/usr/local/bin/strayos-xterm-test"
grep -q 'enable-animations false' "$MOUNT_DIR/usr/local/bin/strayos-gnome-safe"
grep -q 'Starting lightweight Xorg test' "$MOUNT_DIR/usr/local/bin/strayos-xterm-test"

echo "Low-RAM GNOME patch check: OK"
