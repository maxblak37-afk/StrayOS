#!/usr/bin/env python3
import gzip
import hashlib
import os
import pathlib
import re
import shutil
import struct
import subprocess
import sys
import time


ROOT = pathlib.Path(r"F:\StrayOS")
ISO_TREE = ROOT / "build" / "live-4gb-iso" / "iso-tree"
INITRAMFS = ISO_TREE / "strayos" / "initramfs.cpio.gz"
OLD_ISO = ROOT / "iso" / "StrayOS-full-amd64.iso"
NEW_ISO = ROOT / "iso" / "StrayOS-full-amd64-v0.3-tools.iso"
BOOT_IMG = ISO_TREE / "boot" / "grub" / "i386-pc" / "eltorito.img"


UPDATE_SERVER = "78.17.6.198"
UPDATE_LINKS = [
    f"http://{UPDATE_SERVER}/strayos/updates/manifest.json",
    f"http://{UPDATE_SERVER}/strayos/updates/latest.txt",
    f"http://{UPDATE_SERVER}/strayos/updates/StrayOS-full-amd64.iso.sha256",
    f"http://{UPDATE_SERVER}/strayos/apt/",
    f"http://{UPDATE_SERVER}/strayos/releases/",
]


def pad4(data: bytes) -> bytes:
    return data + (b"\0" * ((4 - len(data) % 4) % 4))


def read_cpio_newc(blob: bytes):
    entries = []
    pos = 0
    while pos < len(blob):
        if blob[pos:pos + 6] not in (b"070701", b"070702"):
            raise RuntimeError(f"Bad cpio magic at offset {pos}")
        header = blob[pos:pos + 110]
        vals = [int(header[i:i + 8], 16) for i in range(6, 110, 8)]
        namesize = vals[11]
        filesize = vals[6]
        pos += 110
        raw_name = blob[pos:pos + namesize - 1]
        name = raw_name.decode("utf-8", "replace")
        pos += namesize
        pos = (pos + 3) & ~3
        data = blob[pos:pos + filesize]
        pos += filesize
        pos = (pos + 3) & ~3
        entries.append({"name": name, "vals": vals, "data": data})
        if name == "TRAILER!!!":
            break
    return entries


def write_entry(name: str, mode: int, data: bytes = b"", mtime: int | None = None,
                uid: int = 0, gid: int = 0, nlink: int = 1, ino: int = 1) -> bytes:
    if mtime is None:
        mtime = int(time.time())
    name_b = name.encode("utf-8") + b"\0"
    vals = [
        ino, mode, uid, gid, nlink, mtime, len(data),
        0, 0, 0, 0, len(name_b), 0,
    ]
    header = b"070701" + b"".join(f"{v:08x}".encode("ascii") for v in vals)
    return pad4(header + name_b) + pad4(data)


def write_cpio(entries):
    out = bytearray()
    for entry in entries:
        vals = entry["vals"][:]
        data = entry["data"]
        vals[6] = len(data)
        name_b = entry["name"].encode("utf-8") + b"\0"
        vals[11] = len(name_b)
        header = b"070701" + b"".join(f"{v:08x}".encode("ascii") for v in vals)
        out += pad4(header + name_b)
        out += pad4(data)
    return bytes(out)


def script_system_info() -> str:
    return r'''#!/usr/bin/env python3
import os, platform, socket, subprocess, textwrap

UPDATE_SERVER = "78.17.6.198"
FEATURES = [
    ("Рабочий стол", "LightDM + StrayOS GNOME session"),
    ("Пакеты", "Debian APT, dpkg и StrayOS Package Manager"),
    ("Обновления", "Обновление системы через сервер 78.17.6.198"),
    ("Браузер", "Firefox ESR встроен в образ"),
    ("Установка", "Графический установщик StrayOS"),
    ("Сеть", "Wi-Fi GUI, автоподключение и сохранение профиля"),
    ("Восстановление", "Проверка файловой системы перед загрузкой"),
]
COMMANDS = [
    "strayos-gnome", "strayos-lightdm", "strayos-browser",
    "strayos-wifi-gui", "strayos-installer-gui",
    "strayos-package-manager", "strayos-updater", "strayos-repair-boot",
]

def sh(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return ""

def collect():
    pretty = sh("grep '^PRETTY_NAME=' /etc/os-release | cut -d= -f2- | tr -d '\"'") or "StrayOS 0.3"
    version = sh("grep '^VERSION_ID=' /etc/os-release | cut -d= -f2- | tr -d '\"'") or "0.3"
    apt = sh("apt --version | head -n1") or "APT не найден"
    dpkg_count = sh("dpkg-query -f '${binary:Package}\\n' -W 2>/dev/null | wc -l") or "?"
    ip = sh("hostname -I | awk '{print $1}'") or "нет сети"
    session = os.environ.get("XDG_CURRENT_DESKTOP") or os.environ.get("DESKTOP_SESSION") or "консоль"
    return [
        ("Система", pretty),
        ("Версия StrayOS", version),
        ("Ядро", platform.release()),
        ("Пользователь", sh("id -un") or os.environ.get("USER", "unknown")),
        ("Сессия", session),
        ("Язык", os.environ.get("LANG", "")),
        ("IP", ip),
        ("APT", apt),
        ("Пакетов dpkg", dpkg_count),
        ("Сервер обновлений", UPDATE_SERVER),
    ]

def plain():
    lines = ["StrayOS System Info", ""]
    lines += [f"{k}: {v}" for k, v in collect()]
    lines += ["", "Фичи:"]
    lines += [f"- {k}: {v}" for k, v in FEATURES]
    lines += ["", "Команды:", ", ".join(COMMANDS)]
    return "\n".join(lines)

def main():
    if not os.environ.get("DISPLAY"):
        print(plain())
        return
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk
    except Exception:
        print(plain())
        return

    win = Gtk.Window(title="О системе StrayOS")
    win.set_default_size(760, 520)
    win.connect("destroy", Gtk.main_quit)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=14)
    win.add(box)
    title = Gtk.Label()
    title.set_markup("<big><b>StrayOS 0.3</b></big>\nStrayOS base + Debian APT + GNOME")
    title.set_xalign(0)
    box.pack_start(title, False, False, 0)
    grid = Gtk.Grid(column_spacing=16, row_spacing=6)
    box.pack_start(grid, False, False, 0)
    for row, (k, v) in enumerate(collect()):
        a = Gtk.Label(label=k + ":")
        a.set_xalign(0)
        b = Gtk.Label(label=v)
        b.set_xalign(0)
        b.set_selectable(True)
        grid.attach(a, 0, row, 1, 1)
        grid.attach(b, 1, row, 1, 1)
    text = Gtk.TextView()
    text.set_editable(False)
    text.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
    text.get_buffer().set_text(
        "Новые возможности:\n" +
        "\n".join(f"• {k}: {v}" for k, v in FEATURES) +
        "\n\nКоманды:\n" + "\n".join(COMMANDS)
    )
    sc = Gtk.ScrolledWindow()
    sc.add(text)
    box.pack_start(sc, True, True, 0)
    win.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
'''


def script_updater() -> str:
    links = "\n".join(UPDATE_LINKS)
    return rf'''#!/usr/bin/env python3
import os, shlex, shutil, subprocess, sys, threading, urllib.request

SERVER = "{UPDATE_SERVER}"
LINKS = {UPDATE_LINKS!r}

def relaunch_as_root():
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return True
    cmd = " ".join(shlex.quote(x) for x in [sys.executable] + sys.argv)
    if shutil.which("pkexec"):
        os.execvp("pkexec", ["pkexec", sys.executable] + sys.argv)
    for term in ("xterm", "x-terminal-emulator", "gnome-terminal"):
        if shutil.which(term):
            if term == "gnome-terminal":
                subprocess.Popen([term, "--", "sh", "-lc", "sudo -E " + cmd + "; echo; read -r -p 'Нажми Enter...' _"])
            else:
                subprocess.Popen([term, "-e", "sh", "-lc", "sudo -E " + cmd + "; echo; read -r -p 'Нажми Enter...' _"])
            sys.exit(0)
    return False

def run_cmd(cmd, cb):
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
                            env=dict(os.environ, DEBIAN_FRONTEND="noninteractive"))
    for line in proc.stdout:
        cb(line)
    code = proc.wait()
    cb(f"\nГотово, код выхода: {{code}}\n")

def check_links(cb):
    for url in LINKS:
        try:
            req = urllib.request.Request(url, method="GET", headers={{"User-Agent": "StrayOS-Updater/0.3"}})
            with urllib.request.urlopen(req, timeout=6) as r:
                chunk = r.read(160).decode("utf-8", "replace").strip()
                cb(f"[OK] {{url}} -> HTTP {{r.status}}\n{{chunk}}\n\n")
        except Exception as e:
            cb(f"[нет ответа] {{url}} -> {{e}}\n")

def main():
    if not os.environ.get("DISPLAY"):
        print("Обновление системы (ip:78.17.6.198)")
        print("{links}")
        return
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk, GLib
    except Exception as e:
        print(e)
        return

    win = Gtk.Window(title="Обновление системы (ip:78.17.6.198)")
    win.set_default_size(820, 560)
    win.connect("destroy", Gtk.main_quit)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=12)
    win.add(box)
    head = Gtk.Label(label="Обновление системы\nСервер: 78.17.6.198")
    head.set_xalign(0)
    box.pack_start(head, False, False, 0)
    text = Gtk.TextView()
    text.set_editable(False)
    text.set_monospace(True)
    buf = text.get_buffer()
    sc = Gtk.ScrolledWindow()
    sc.add(text)
    box.pack_start(sc, True, True, 0)
    bar = Gtk.ProgressBar()
    box.pack_start(bar, False, False, 0)
    row = Gtk.Box(spacing=8)
    box.pack_start(row, False, False, 0)

    def append(s):
        def inner():
            end = buf.get_end_iter()
            buf.insert(end, s)
            mark = buf.create_mark(None, buf.get_end_iter(), False)
            text.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
            bar.pulse()
            return False
        GLib.idle_add(inner)

    def start(label, fn):
        buf.set_text(label + "\n\n")
        def work():
            fn(append)
            GLib.idle_add(bar.set_fraction, 0.0)
        threading.Thread(target=work, daemon=True).start()

    def button(label, fn):
        b = Gtk.Button(label=label)
        b.connect("clicked", lambda *_: start(label, fn))
        row.pack_start(b, False, False, 0)

    button("Проверить сервер StrayOS", check_links)
    button("APT update", lambda cb: relaunch_as_root() and run_cmd(["apt-get", "update"], cb))
    button("APT upgrade", lambda cb: relaunch_as_root() and run_cmd(["apt-get", "upgrade", "-y"], cb))
    button("Показать ссылки", lambda cb: cb("\n".join(LINKS) + "\n"))
    buf.set_text("Готово.\n\nСсылки обновлений:\n" + "\n".join(LINKS))
    win.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
'''


def script_package_manager() -> str:
    return r'''#!/usr/bin/env python3
import os, re, shlex, shutil, subprocess, sys, threading

POPULAR = ["firefox-esr", "chromium", "vlc", "gimp", "inkscape", "krita", "blender",
           "libreoffice", "thunderbird", "filezilla", "qbittorrent", "audacity",
           "obs-studio", "neofetch", "fastfetch", "htop", "curl", "git", "nano"]

def relaunch_as_root():
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return True
    cmd = " ".join(shlex.quote(x) for x in [sys.executable] + sys.argv)
    if shutil.which("pkexec"):
        os.execvp("pkexec", ["pkexec", sys.executable] + sys.argv)
    for term in ("xterm", "x-terminal-emulator", "gnome-terminal"):
        if shutil.which(term):
            args = [term, "-e", "sh", "-lc", "sudo -E " + cmd + "; echo; read -r -p 'Нажми Enter...' _"]
            if term == "gnome-terminal":
                args = [term, "--", "sh", "-lc", "sudo -E " + cmd + "; echo; read -r -p 'Нажми Enter...' _"]
            subprocess.Popen(args)
            sys.exit(0)
    return False

def run_lines(cmd):
    return subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT)

def main():
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk, GLib
    except Exception as e:
        print("StrayOS Package Manager needs GTK:", e)
        return

    win = Gtk.Window(title="StrayOS Package Manager")
    win.set_default_size(900, 620)
    win.connect("destroy", Gtk.main_quit)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=12)
    win.add(box)
    top = Gtk.Box(spacing=8)
    box.pack_start(top, False, False, 0)
    search = Gtk.Entry()
    search.set_placeholder_text("Поиск приложений APT: chromium, vlc, gimp...")
    top.pack_start(search, True, True, 0)
    btn_search = Gtk.Button(label="Искать")
    btn_update = Gtk.Button(label="Обновить список")
    btn_install = Gtk.Button(label="Установить выбранное")
    top.pack_start(btn_search, False, False, 0)
    top.pack_start(btn_update, False, False, 0)
    top.pack_start(btn_install, False, False, 0)

    store = Gtk.ListStore(str, str)
    view = Gtk.TreeView(model=store)
    for idx, title in enumerate(("Пакет", "Описание")):
        col = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=idx)
        col.set_resizable(True)
        view.append_column(col)
    sc = Gtk.ScrolledWindow()
    sc.add(view)
    box.pack_start(sc, True, True, 0)
    status = Gtk.Label(label="Введите запрос или нажмите поиск для популярных пакетов.")
    status.set_xalign(0)
    box.pack_start(status, False, False, 0)
    bar = Gtk.ProgressBar()
    box.pack_start(bar, False, False, 0)
    log = Gtk.TextView()
    log.set_editable(False)
    log.set_monospace(True)
    log_sc = Gtk.ScrolledWindow()
    log_sc.set_min_content_height(140)
    log_sc.add(log)
    box.pack_start(log_sc, False, True, 0)
    logbuf = log.get_buffer()

    def set_status(s):
        GLib.idle_add(status.set_text, s)

    def append(s):
        def inner():
            end = logbuf.get_end_iter()
            logbuf.insert(end, s)
            mark = logbuf.create_mark(None, logbuf.get_end_iter(), False)
            log.scroll_to_mark(mark, 0, True, 0, 1)
            bar.pulse()
            return False
        GLib.idle_add(inner)

    def fill(rows):
        def inner():
            store.clear()
            for pkg, desc in rows[:700]:
                store.append([pkg, desc])
            status.set_text(f"Найдено: {len(rows)}. Показано: {min(len(rows), 700)}.")
            return False
        GLib.idle_add(inner)

    def do_search(*_):
        q = search.get_text().strip()
        set_status("Ищу пакеты...")
        def work():
            rows = []
            try:
                if q:
                    out = run_lines(["apt-cache", "search", "--names-only", q])
                    for line in out.splitlines():
                        if " - " in line:
                            pkg, desc = line.split(" - ", 1)
                            rows.append((pkg.strip(), desc.strip()))
                else:
                    for pkg in POPULAR:
                        try:
                            out = run_lines(["apt-cache", "show", pkg])
                            m = re.search(r"^Description(?:-en)?: (.+)$", out, re.M)
                            rows.append((pkg, m.group(1) if m else "Популярное приложение"))
                        except Exception:
                            rows.append((pkg, "Популярное приложение"))
                fill(rows)
            except Exception as e:
                set_status("Ошибка поиска: " + str(e))
        threading.Thread(target=work, daemon=True).start()

    def run_apt(cmd):
        logbuf.set_text("$ " + " ".join(cmd) + "\n")
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
                                env=dict(os.environ, DEBIAN_FRONTEND="noninteractive"))
        total = ""
        for line in proc.stdout:
            append(line)
            m = re.search(r"Need to get ([0-9.,]+ [kMGTP]?B)", line)
            if m:
                total = m.group(1)
                set_status("Нужно скачать: " + total)
            m = re.search(r"Fetched ([0-9.,]+ [kMGTP]?B)", line)
            if m:
                set_status("Скачано: " + m.group(1) + ((" / " + total) if total else ""))
        code = proc.wait()
        set_status("Готово" if code == 0 else f"Ошибка установки, код {code}")
        append(f"\nГотово, код выхода: {code}\n")

    def apt_update(*_):
        if not relaunch_as_root():
            set_status("Нужны права администратора.")
            return
        threading.Thread(target=lambda: run_apt(["apt-get", "update"]), daemon=True).start()

    def install(*_):
        sel = view.get_selection()
        model, it = sel.get_selected()
        if not it:
            set_status("Сначала выбери пакет.")
            return
        pkg = model[it][0]
        if not relaunch_as_root():
            set_status("Нужны права администратора.")
            return
        set_status("Установка: " + pkg)
        threading.Thread(target=lambda: run_apt(["apt-get", "install", "-y", pkg]), daemon=True).start()

    btn_search.connect("clicked", do_search)
    search.connect("activate", do_search)
    btn_update.connect("clicked", apt_update)
    btn_install.connect("clicked", install)
    do_search()
    win.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
'''


def overlay_files():
    desktop_info = """[Desktop Entry]
Type=Application
Name=About StrayOS
Name[ru]=О системе StrayOS
Comment=Show StrayOS system information
Exec=strayos-system-info
Icon=computer
Terminal=false
Categories=System;
"""
    desktop_update = """[Desktop Entry]
Type=Application
Name=System Update
Name[ru]=Обновление системы
Comment=Check StrayOS and APT updates
Exec=strayos-updater
Icon=system-software-update
Terminal=false
Categories=System;
"""
    desktop_pm = """[Desktop Entry]
Type=Application
Name=StrayOS Package Manager
Name[ru]=Менеджер пакетов StrayOS
Comment=Search and install APT applications
Exec=strayos-package-manager
Icon=system-software-install
Terminal=false
Categories=System;PackageManager;
"""
    os_release = """NAME=StrayOS
ID=strayos
PRETTY_NAME="StrayOS 0.3"
VERSION_ID="0.3"
VERSION="0.3 GNOME/APT"
HOME_URL="http://78.17.6.198/strayos/"
SUPPORT_URL="http://78.17.6.198/strayos/support/"
BUG_REPORT_URL="http://78.17.6.198/strayos/issues/"
"""
    lsb_release = """DISTRIB_ID=StrayOS
DISTRIB_RELEASE=0.3
DISTRIB_CODENAME=gnome
DISTRIB_DESCRIPTION="StrayOS 0.3"
"""
    links = "\n".join(UPDATE_LINKS) + "\n"
    files = {
        "strayos-overlay/usr/local/bin/strayos-system-info": (0o100755, script_system_info().encode("utf-8")),
        "strayos-overlay/usr/local/bin/strayos-updater": (0o100755, script_updater().encode("utf-8")),
        "strayos-overlay/usr/local/bin/strayos-update": (0o100755, b"#!/bin/sh\nexec strayos-updater \"$@\"\n"),
        "strayos-overlay/usr/local/bin/strayos-package-manager": (0o100755, script_package_manager().encode("utf-8")),
        "strayos-overlay/usr/local/bin/strayos-about": (0o100755, b"#!/bin/sh\nexec strayos-system-info \"$@\"\n"),
        "strayos-overlay/usr/share/applications/strayos-system-info.desktop": (0o100644, desktop_info.encode("utf-8")),
        "strayos-overlay/usr/share/applications/strayos-updater.desktop": (0o100644, desktop_update.encode("utf-8")),
        "strayos-overlay/usr/share/applications/strayos-package-manager.desktop": (0o100644, desktop_pm.encode("utf-8")),
        "strayos-overlay/home/stray/Desktop/strayos-system-info.desktop": (0o100755, desktop_info.encode("utf-8")),
        "strayos-overlay/home/stray/Desktop/strayos-updater.desktop": (0o100755, desktop_update.encode("utf-8")),
        "strayos-overlay/home/stray/Desktop/strayos-package-manager.desktop": (0o100755, desktop_pm.encode("utf-8")),
        "strayos-overlay/etc/os-release": (0o100644, os_release.encode("utf-8")),
        "strayos-overlay/etc/lsb-release": (0o100644, lsb_release.encode("utf-8")),
        "strayos-overlay/usr/local/share/strayos/update-links.txt": (0o100644, links.encode("utf-8")),
    }
    dirs = set()
    for name in files:
        parts = name.split("/")[:-1]
        for i in range(1, len(parts) + 1):
            dirs.add("/".join(parts[:i]))
    return dirs, files


def inject_init(init_text: str) -> str:
    init_text = re.sub(
        r"\n# StrayOS v0\.[23] live feature overlay\n"
        r"if \[ -d /strayos-overlay \]; then\n"
        r".*?"
        r"fi\n\n",
        "\n",
        init_text,
        flags=re.S,
    )
    marker = "# StrayOS v0.3 live feature overlay"
    if marker in init_text:
        return init_text
    needle = "mkdir -p /newroot/proc /newroot/sys /newroot/dev /newroot/run /newroot/tmp /newroot/media/strayos\n"
    block = f"""
{marker}
if [ -d /strayos-overlay ]; then
  echo "Applying StrayOS v0.3 feature overlay..."
  /bin/busybox cp -a /strayos-overlay/. /newroot/ 2>/dev/null || echo "WARNING: feature overlay copy failed"
  /bin/busybox chmod 755 /newroot/usr/local/bin/strayos-system-info /newroot/usr/local/bin/strayos-updater /newroot/usr/local/bin/strayos-update /newroot/usr/local/bin/strayos-package-manager /newroot/usr/local/bin/strayos-about 2>/dev/null || true
  /bin/busybox chmod 755 /newroot/home/stray/Desktop/strayos-system-info.desktop /newroot/home/stray/Desktop/strayos-updater.desktop /newroot/home/stray/Desktop/strayos-package-manager.desktop 2>/dev/null || true
fi

"""
    if needle not in init_text:
        raise RuntimeError("Cannot find init injection point")
    return init_text.replace(needle, block + needle)


def patch_initramfs():
    raw = gzip.open(INITRAMFS, "rb").read()
    entries = read_cpio_newc(raw)
    out = []
    replaced = False
    for entry in entries:
        if entry["name"] == "TRAILER!!!":
            continue
        if entry["name"] == "init":
            entry = dict(entry)
            entry["data"] = inject_init(entry["data"].decode("utf-8")).encode("utf-8")
            replaced = True
        out.append(entry)
    if not replaced:
        raise RuntimeError("No init file in initramfs")

    existing = {e["name"] for e in out}
    dirs, files = overlay_files()
    ino = 50000
    for d in sorted(dirs, key=lambda x: (x.count("/"), x)):
        if d not in existing:
            out.append({"name": d, "vals": [ino, 0o40755, 0, 0, 2, int(time.time()), 0, 0, 0, 0, 0, len(d) + 1, 0], "data": b""})
            ino += 1
    for name, (mode, data) in files.items():
        out = [e for e in out if e["name"] != name]
        out.append({"name": name, "vals": [ino, mode, 0, 0, 1, int(time.time()), len(data), 0, 0, 0, 0, len(name) + 1, 0], "data": data})
        ino += 1
    out.append({"name": "TRAILER!!!", "vals": [ino, 0, 0, 0, 1, int(time.time()), 0, 0, 0, 0, 0, len("TRAILER!!!") + 1, 0], "data": b""})

    backup = INITRAMFS.with_suffix(INITRAMFS.suffix + ".bak")
    if not backup.exists():
        shutil.copy2(INITRAMFS, backup)
    new_raw = write_cpio(out)
    with INITRAMFS.open("wb") as fh:
        gz = gzip.GzipFile(filename="", mode="wb", fileobj=fh, compresslevel=9, mtime=0)
        gz.write(new_raw)
        gz.close()
    print(f"Patched initramfs: {INITRAMFS}")
    print(f"Old uncompressed: {len(raw):,} bytes")
    print(f"New uncompressed: {len(new_raw):,} bytes")
    print(f"New compressed:   {INITRAMFS.stat().st_size:,} bytes")


def _rr_name(dr: bytes) -> str | None:
    namelen = dr[32]
    pos = 33 + namelen
    if pos % 2:
        pos += 1
    parts = []
    while pos + 4 <= len(dr):
        sig = dr[pos:pos + 2]
        length = dr[pos + 2]
        if length < 4 or pos + length > len(dr):
            break
        body = dr[pos + 4:pos + length]
        if sig == b"NM" and body:
            parts.append(body[1:].decode("utf-8", "replace"))
        pos += length
    return "".join(parts) if parts else None


def _parse_iso_dir_record(dr: bytes):
    lba = struct.unpack_from("<I", dr, 2)[0]
    size = struct.unpack_from("<I", dr, 10)[0]
    flags = dr[25]
    namelen = dr[32]
    raw = dr[33:33 + namelen]
    if raw == b"\0":
        name = "."
    elif raw == b"\1":
        name = ".."
    else:
        name = raw.decode("ascii", "replace").split(";")[0]
    return _rr_name(dr) or name, lba, size, flags


def extract_boot_grub_from_old_iso():
    extracted = 0
    with OLD_ISO.open("rb") as f:
        f.seek(16 * 2048)
        pvd = f.read(2048)
        root_len = pvd[156]
        root = pvd[156:156 + root_len]
        _, root_lba, root_size, _ = _parse_iso_dir_record(root)

        def walk(path: str, lba: int, size: int, seen: set[tuple[int, int]]):
            nonlocal extracted
            if (lba, size) in seen:
                return
            seen.add((lba, size))
            f.seek(lba * 2048)
            data = f.read(size)
            pos = 0
            while pos < len(data):
                length = data[pos]
                if length == 0:
                    pos = ((pos // 2048) + 1) * 2048
                    continue
                dr = data[pos:pos + length]
                name, elba, esize, flags = _parse_iso_dir_record(dr)
                if name not in (".", ".."):
                    full = (path + "/" + name).replace("//", "/")
                    if full.startswith("/boot/grub/"):
                        target = ISO_TREE / full.lstrip("/")
                        if flags & 2:
                            target.mkdir(parents=True, exist_ok=True)
                        else:
                            target.parent.mkdir(parents=True, exist_ok=True)
                            f.seek(elba * 2048)
                            target.write_bytes(f.read(esize))
                            extracted += 1
                    if flags & 2:
                        walk(full, elba, esize, seen)
                pos += length

        walk("", root_lba, root_size, set())
    if not BOOT_IMG.exists():
        raise RuntimeError(f"Cannot extract GRUB boot image: {BOOT_IMG}")
    print(f"Extracted GRUB boot tree from old ISO: {extracted} files")


def patch_grub_cfg():
    cfg = ISO_TREE / "boot" / "grub" / "grub.cfg"
    text = cfg.read_text(encoding="utf-8")
    text = text.replace("console=tty0 nomodeset", "console=tty0 console=ttyS0,115200 nomodeset")
    cfg.write_text(text, encoding="utf-8", newline="\n")
    print(f"Patched GRUB config: {cfg}")


def build_iso():
    extract_boot_grub_from_old_iso()
    patch_grub_cfg()
    if NEW_ISO.exists():
        NEW_ISO.unlink()
    cmd = [
        "oscdimg",
        "-m",
        "-o",
        "-n",
        "-d",
        f"-bootdata:1#p0,e,b{BOOT_IMG}",
        str(ISO_TREE),
        str(NEW_ISO),
    ]
    print("Building ISO with oscdimg...")
    subprocess.run(cmd, check=True)
    fix_grub_eltorito_lba(NEW_ISO)
    digest = hashlib.sha256(NEW_ISO.read_bytes()).hexdigest()
    (NEW_ISO.with_suffix(NEW_ISO.suffix + ".sha256")).write_text(f"{digest}  {NEW_ISO.name}\n", encoding="ascii")
    print(f"Built: {NEW_ISO}")
    print(f"SHA256: {digest}")


def fix_grub_eltorito_lba(iso_path: pathlib.Path):
    with iso_path.open("r+b") as f:
        catalog_lba = None
        for sector in range(16, 64):
            f.seek(sector * 2048)
            sec = f.read(2048)
            if sec[0] == 0 and sec[1:6] == b"CD001" and sec[7:30] == b"EL TORITO SPECIFICATION":
                catalog_lba = struct.unpack_from("<I", sec, 71)[0]
                break
        if catalog_lba is None:
            raise RuntimeError("Cannot find El Torito catalog in new ISO")
        entry_pos = catalog_lba * 2048 + 32
        f.seek(entry_pos)
        entry = bytearray(f.read(32))
        if entry[0] != 0x88:
            raise RuntimeError("New ISO has no bootable El Torito entry")
        boot_lba = struct.unpack_from("<I", entry, 8)[0]
        struct.pack_into("<H", entry, 6, 4)
        f.seek(entry_pos)
        f.write(entry)
        f.seek(boot_lba * 2048 + 12)
        f.write(struct.pack("<I", boot_lba))
    print(f"Patched GRUB El Torito LBA: catalog={catalog_lba}, boot_lba={boot_lba}, load_sectors=4")


def main():
    if not INITRAMFS.exists():
        raise SystemExit(f"Missing initramfs: {INITRAMFS}")
    patch_initramfs()
    build_iso()


if __name__ == "__main__":
    main()
