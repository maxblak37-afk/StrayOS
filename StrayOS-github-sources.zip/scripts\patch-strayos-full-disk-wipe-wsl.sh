#!/usr/bin/env bash
set -euo pipefail

patch_installer() {
  local image="$1" mount_dir="$2" loop_dev="" part=""

  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    if [[ -n "${loop_dev:-}" ]]; then sudo losetup -d "$loop_dev" || true; fi
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then part="$loop_dev"; fi
  sudo mount "$part" "$mount_dir"

  local installer="$mount_dir/usr/local/sbin/strayos-install"
  test -f "$installer"

  sudo cp "$installer" "$installer.bak-fullwipe"

  sudo awk '
    BEGIN { in_func=0 }

    /^format_whole_disk\(\) \{/ {
      in_func=1
      print "format_whole_disk() {"
      print "  local disk=\"$1\""
      print "  is_block \"$disk\" || die \"$disk is not a block device.\""
      print "  is_disk \"$disk\" || die \"$disk is not a disk.\""
      print "  [[ \"$disk\" != /dev/sr* ]] || die \"Refusing to install to optical device $disk.\""
      print "  [[ \"$disk\" != /dev/loop* ]] || die \"Refusing to install to loop device $disk.\""
      print "  ensure_not_live_root \"$disk\""
      print ""
      print "  echo"
      print "  echo \"FULL DISK WIPE ENABLED.\""
      print "  echo \"This removes partition tables, filesystem signatures, LUKS/BitLocker headers,\""
      print "  echo \"and overwrites the whole selected disk with zeroes before installing StrayOS.\""
      print "  echo \"On large disks this can take a long time.\""
      print "  confirm_exact \"ERASE $disk\""
      print ""
      print "  full_wipe_disk \"$disk\""
      print ""
      print "  local part"
      print "  part=\"$(partition_name_for_disk \"$disk\")\""
      print ""
      print "  run parted -s \"$disk\" mklabel msdos"
      print "  run parted -s \"$disk\" mkpart primary ext4 1MiB 100%"
      print "  run parted -s \"$disk\" set 1 boot on"
      print "  run partprobe \"$disk\""
      print "  sleep 2"
      print "  run mkfs.ext4 -F -L STRAYOS_ROOT \"$part\""
      print ""
      print "  TARGET_PARTITION=\"$part\""
      print "  BOOT_DISK=\"$disk\""
      print "}"
      next
    }

    in_func && /^}/ {
      in_func=0
      next
    }

    in_func { next }

    /^format_selected_volume\(\) \{/ && !inserted {
      print "list_child_partitions() {"
      print "  local disk=\"$1\""
      print "  lsblk -ln -o PATH \"$disk\" 2>/dev/null | tail -n +2"
      print "}"
      print ""
      print "full_wipe_disk() {"
      print "  local disk=\"$1\" size sectors sector_size seek_pos"
      print ""
      print "  say \"Unmounting old partitions on $disk\""
      print "  for child in $(list_child_partitions \"$disk\"); do"
      print "    swapoff \"$child\" 2>/dev/null || true"
      print "    umount -R \"$child\" 2>/dev/null || true"
      print "  done"
      print ""
      print "  say \"Removing old signatures and partition tables\""
      print "  for child in $(list_child_partitions \"$disk\"); do"
      print "    run wipefs -a \"$child\" || true"
      print "  done"
      print "  run wipefs -a \"$disk\" || true"
      print ""
      print "  if command -v sgdisk >/dev/null 2>&1; then"
      print "    run sgdisk --zap-all \"$disk\" || true"
      print "  fi"
      print ""
      print "  say \"Overwriting the whole disk with zeroes\""
      print "  if command -v dd >/dev/null 2>&1; then"
      print "    run dd if=/dev/zero of=\"$disk\" bs=16M status=progress conv=fsync"
      print "  else"
      print "    die \"dd is missing; cannot full-wipe disk.\""
      print "  fi"
      print ""
      print "  sync"
      print "  run blockdev --rereadpt \"$disk\" 2>/dev/null || true"
      print "  run partprobe \"$disk\" 2>/dev/null || true"
      print "  sleep 2"
      print "}"
      print ""
      inserted=1
    }

    { print }
  ' "$installer" | sudo tee "$installer.fullwipe" >/dev/null

  sudo mv "$installer.fullwipe" "$installer"
  sudo chmod +x "$installer"

  local progress="$mount_dir/usr/local/sbin/strayos-install-progress"
  if [[ -f "$progress" ]]; then
    sudo cp "$progress" "$progress.bak-fullwipe"
    sudo sed -i \
      -e "/grep -q 'mkfs.ext4'/i\\  if grep -q 'Overwriting the whole disk with zeroes' \"\$LOG\" 2>/dev/null; then\\n    stage=\"Full wiping selected disk\"\\n    pct=10\\n  elif grep -q 'Removing old signatures' \"\$LOG\" 2>/dev/null; then\\n    stage=\"Removing old disk signatures\"\\n    pct=6" \
      -e "0,/if grep -q 'mkfs.ext4'/s//  elif grep -q 'mkfs.ext4'/" \
      "$progress"
  fi

  sudo sync
  cleanup
  trap - RETURN
}

patch_installer /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img /tmp/strayos-fullwipe-boot
patch_installer /mnt/f/StrayOS/disks/strayos-5g.img /tmp/strayos-fullwipe-base

sha256sum /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img > /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img.sha256
sha256sum /mnt/f/StrayOS/disks/strayos-5g.img > /mnt/f/StrayOS/disks/strayos-5g.img.sha256

echo "Patched StrayOS installer: whole-disk mode now performs a full zero wipe."
