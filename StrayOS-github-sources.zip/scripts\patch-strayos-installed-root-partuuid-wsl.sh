#!/usr/bin/env bash
set -euo pipefail

images=(
  /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img
  /mnt/f/StrayOS/disks/strayos-5g.img
)

patch_image() {
  local image="$1" mount_dir loop_dev part
  mount_dir="/tmp/strayos-partuuid-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"
  sudo mount "$part" "$mount_dir"

  local installer="$mount_dir/usr/local/sbin/strayos-install"
  local repair="$mount_dir/usr/local/sbin/strayos-repair-boot"

  sudo perl -0pi -e '
    s/local target="\$1" uuid boot_disk="\$2" install_grub="\$3"/local target="\$1" uuid partuuid boot_disk="\$2" install_grub="\$3"/;
    s/uuid="\$\(blkid -s UUID -o value "\$TARGET_PARTITION"\)"\n  \[\[ -n "\$uuid" \]\] \|\| die "Could not read UUID for \$TARGET_PARTITION\."/uuid="$(blkid -s UUID -o value "$TARGET_PARTITION")"\n  partuuid="$(blkid -s PARTUUID -o value "$TARGET_PARTITION" 2>\/dev\/null || true)"\n  [[ -n "$uuid" ]] || die "Could not read UUID for $TARGET_PARTITION."\n  [[ -n "$partuuid" ]] || die "Could not read PARTUUID for $TARGET_PARTITION. Install to a real partition, not a raw whole device."/;
    s/root=UUID=\$uuid/root=PARTUUID=\$partuuid/g;
    s/echo "Installed root: \$TARGET_PARTITION"/echo "Installed root: $TARGET_PARTITION"\n  echo "Installed root PARTUUID: $partuuid"/;
  ' "$installer"

  if [[ -f "$repair" ]]; then
    sudo perl -0pi -e '
      s/\[\[ -n "\$uuid" \]\] \|\| die "Could not read UUID for \$root_part\."/\[\[ -n "$uuid" \]\] \|\| die "Could not read UUID for $root_part."\n  [[ -n "$partuuid" ]] || die "Could not read PARTUUID for $root_part. Pick the installed StrayOS partition, for example \/dev\/sda1."/;
      s/root=UUID=\$uuid/root=PARTUUID=\$partuuid/g;
    ' "$repair"
  fi

  sudo bash -n "$installer"
  [[ ! -f "$repair" ]] || sudo bash -n "$repair"
  sudo grep -q 'root=PARTUUID=$partuuid' "$installer"
  [[ ! -f "$repair" ]] || sudo grep -q 'root=PARTUUID=$partuuid' "$repair"

  sudo sync
  cleanup
  trap - RETURN
}

for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img > /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img.sha256
sha256sum /mnt/f/StrayOS/disks/strayos-5g.img > /mnt/f/StrayOS/disks/strayos-5g.img.sha256

echo "Patched installed StrayOS boot root to PARTUUID."
