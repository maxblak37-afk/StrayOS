#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-grub-repair-check}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

test -x "$MOUNT_DIR/usr/local/sbin/strayos-repair-boot"
grep -q 'REPAIR GRUB' "$MOUNT_DIR/usr/local/sbin/strayos-repair-boot"
grep -q -- '--recheck "$boot_disk"' "$MOUNT_DIR/usr/local/sbin/strayos-install"
grep -q 'search --no-floppy --fs-uuid' "$MOUNT_DIR/usr/local/sbin/strayos-install"
grep -q 'strayos-repair-boot' "$MOUNT_DIR/init"

echo "--- repair command ---"
sudo grep -nE 'strayos-repair-boot|REPAIR GRUB|grub-install|search --no-floppy' "$MOUNT_DIR/usr/local/sbin/strayos-repair-boot" | sed -n '1,120p'
echo "--- installer hardened lines ---"
sudo grep -nE 'grub-install|search --no-floppy|rootwait' "$MOUNT_DIR/usr/local/sbin/strayos-install" | sed -n '1,160p'
echo "GRUB repair check: OK"
