#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
BUILD_DIR="$PROJECT_DIR/build/recovery-initramfs"
INITRAMFS_DIR="$BUILD_DIR/initramfs"
INITRAMFS_OUT="$BUILD_DIR/initramfs-strayos.cpio.gz"

images=(
  "$PROJECT_DIR/disks/StrayOS-bootable-5g.img"
  "$PROJECT_DIR/disks/strayos-5g.img"
)

copy_lib() {
  local lib="$1" dest="$2"
  [[ -f "$lib" ]] || return 0
  mkdir -p "$dest$(dirname "$lib")"
  cp -L "$lib" "$dest$lib"
}

build_recovery_initramfs() {
  rm -rf "$INITRAMFS_DIR"
  mkdir -p "$INITRAMFS_DIR"/{bin,sbin,dev,proc,sys,newroot,run,tmp,lib/x86_64-linux-gnu,lib64}

  cp /usr/bin/busybox "$INITRAMFS_DIR/bin/busybox"
  for applet in sh mount umount mkdir mknod sleep cat echo ls dmesg switch_root grep cut sed awk basename dirname find; do
    ln -sf busybox "$INITRAMFS_DIR/bin/$applet"
  done

  cp /usr/sbin/e2fsck "$INITRAMFS_DIR/sbin/e2fsck"
  while read -r lib; do
    copy_lib "$lib" "$INITRAMFS_DIR"
  done < <(ldd /usr/sbin/e2fsck | awk '
    /=> \// { print $3 }
    /^\// { print $1 }
  ')
  copy_lib /lib64/ld-linux-x86-64.so.2 "$INITRAMFS_DIR"

  cat > "$INITRAMFS_DIR/init" <<'EOF'
#!/bin/sh
set +e
export PATH=/bin:/sbin:/usr/bin:/usr/sbin

mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || {
  mknod /dev/console c 5 1
  mknod /dev/null c 1 3
  mknod /dev/tty c 5 0
}
mkdir -p /newroot /run /tmp

root_arg=""
for arg in $(cat /proc/cmdline); do
  case "$arg" in
    root=*) root_arg="${arg#root=}" ;;
  esac
done

find_partuuid() {
  wanted="$1"
  for uevent in /sys/class/block/*/uevent; do
    [ -f "$uevent" ] || continue
    devname="$(sed -n 's/^DEVNAME=//p' "$uevent" | head -1)"
    partuuid="$(sed -n 's/^PARTUUID=//p' "$uevent" | head -1)"
    [ -n "$devname" ] || continue
    [ "$partuuid" = "$wanted" ] || continue
    echo "/dev/$devname"
    return 0
  done
  return 1
}

root_dev=""
i=0
while [ "$i" -lt 45 ]; do
  case "$root_arg" in
    PARTUUID=*)
      root_dev="$(find_partuuid "${root_arg#PARTUUID=}")"
      ;;
    /dev/*)
      [ -b "$root_arg" ] && root_dev="$root_arg"
      ;;
  esac

  [ -n "$root_dev" ] && [ -b "$root_dev" ] && break
  sleep 1
  i=$((i + 1))
done

if [ -z "$root_dev" ] || [ ! -b "$root_dev" ]; then
  echo "StrayOS recovery: cannot find root device from '$root_arg'"
  echo "Available block devices:"
  ls -l /dev/sd* /dev/nvme* /dev/vd* 2>/dev/null
  exec /bin/sh
fi

echo "StrayOS recovery: checking $root_dev before boot..."
/sbin/e2fsck -p "$root_dev"
status="$?"
if [ "$status" -gt 1 ]; then
  echo "StrayOS recovery: automatic check needs stronger repair, running e2fsck -y"
  /sbin/e2fsck -f -y "$root_dev"
fi

echo "StrayOS recovery: mounting root..."
mount -t ext4 -o rw "$root_dev" /newroot
if [ "$?" -ne 0 ]; then
  echo "StrayOS recovery: root mount failed"
  exec /bin/sh
fi

mkdir -p /newroot/proc /newroot/sys /newroot/dev /newroot/run /newroot/tmp
mount --move /proc /newroot/proc
mount --move /sys /newroot/sys
mount --move /dev /newroot/dev
exec switch_root /newroot /init

echo "StrayOS recovery: switch_root failed"
exec /bin/sh
EOF
  chmod +x "$INITRAMFS_DIR/init"

  mkdir -p "$BUILD_DIR"
  (cd "$INITRAMFS_DIR" && find . -print0 | cpio --null -o --format=newc | gzip -9) > "$INITRAMFS_OUT"
}

patch_init() {
  local file="$1" tmp
  tmp="$(mktemp)"
  awk '
    BEGIN { inserted=0 }
    /mount -t devtmpfs devtmpfs \/dev/ && inserted == 0 {
      print
      print "mount -t tmpfs -o mode=0755,nosuid,nodev tmpfs /run 2>/dev/null || true"
      print "mount -t tmpfs -o mode=1777,nosuid,nodev tmpfs /tmp 2>/dev/null || true"
      print "mkdir -p /var/lib/strayos"
      print "if [ -f /var/lib/strayos/booting ]; then"
      print "  echo \"Previous StrayOS shutdown was not clean; resetting GNOME/Xorg volatile state.\" >/dev/console 2>&1 || true"
      print "  rm -f /tmp/.X0-lock /tmp/.X1-lock /tmp/.X11-unix/X0 /tmp/.X11-unix/X1"
      print "  rm -f /root/.Xauthority /root/.ICEauthority /root/.xsession-errors /root/.xsession-errors.old"
      print "  rm -rf /root/.cache/gnome-shell /root/.local/share/gnome-shell /root/.local/share/gvfs-metadata"
      print "  rm -f /root/.config/monitors.xml"
      print "fi"
      print "date > /var/lib/strayos/booting 2>/dev/null || true"
      inserted=1
      next
    }
    /dhclient -1 eth0/ {
      print
      print "strayos-network-autostart >/tmp/strayos-network-autostart.log 2>&1 &"
      next
    }
    /Power off:/ {
      print "  echo \"Power off: strayos-poweroff\""
      print "  echo \"Reboot: strayos-reboot\""
      next
    }
    { print }
  ' "$file" > "$tmp"
  sudo cp "$tmp" "$file"
  rm -f "$tmp"
}

write_main_init() {
  local file="$1"
  cat <<'EOF' | sudo tee "$file" >/dev/null
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TERM=linux
export LANG=C.UTF-8

mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
mount -t tmpfs -o mode=0755,nosuid,nodev tmpfs /run 2>/dev/null || true
mount -t tmpfs -o mode=1777,nosuid,nodev tmpfs /tmp 2>/dev/null || true
mkdir -p /dev/pts /run /tmp /root /run/user/0 /var/lib/strayos
mount -t devpts devpts /dev/pts 2>/dev/null || true
chmod 1777 /tmp 2>/dev/null || true
chmod 700 /run/user/0 2>/dev/null || true

if [ -f /var/lib/strayos/booting ]; then
  echo "Previous StrayOS shutdown was not clean; resetting GNOME/Xorg volatile state." >/dev/console 2>&1 || true
  rm -f /tmp/.X0-lock /tmp/.X1-lock /tmp/.X11-unix/X0 /tmp/.X11-unix/X1
  rm -f /root/.Xauthority /root/.ICEauthority /root/.xsession-errors /root/.xsession-errors.old
  rm -rf /root/.cache/gnome-shell /root/.local/share/gnome-shell /root/.local/share/gvfs-metadata
  rm -f /root/.config/monitors.xml
fi
date > /var/lib/strayos/booting 2>/dev/null || true

hostname strayos 2>/dev/null || true
swapon /swapfile 2>/dev/null || true
sysctl -w vm.swappiness=80 >/dev/null 2>&1 || true

ip link set lo up 2>/dev/null || true
ip link set eth0 up 2>/dev/null || true
dhclient -1 eth0 2>/dev/null || true
strayos-network-autostart >/tmp/strayos-network-autostart.log 2>&1 &

show_banner() {
  clear 2>/dev/null || true
  cat /etc/issue 2>/dev/null || echo "StrayOS"
  echo "Kernel: $(uname -r)"
  echo "Disk: persistent ext4 StrayOS"
  echo
  echo "StrayOS base is still Debian APT:"
  apt --version 2>/dev/null || true
  echo
  echo "Try:"
  echo "  neofetch"
  echo "  apt-get check"
  echo "  strayos-gnome"
  echo "  strayos-gnome-safe"
  echo "  strayos-gnome-reset"
  echo "  strayos-xterm-test"
  echo "  strayos-light"
  echo "  strayos-diag"
  echo "  strayos-wifi"
  echo "  strayos-wifi-gui"
  echo "  strayos-install-help"
  echo "  strayos-install"
  echo "  strayos-installer-gui"
  echo "  strayos-repair-boot"
  echo "  strayos-poweroff"
  echo "  strayos-reboot"
  echo
  echo "GNOME is manual, not autostarted."
  echo "Power off: strayos-poweroff"
  echo "Reboot: strayos-reboot"
  echo
}

if grep -q 'strayos.autotest=1' /proc/cmdline 2>/dev/null; then
  show_banner
  echo "[autotest] identity:"
  cat /etc/os-release
  echo
  echo "[autotest] apt:"
  apt --version
  echo
  echo "[autotest] neofetch:"
  neofetch --version
  echo
  echo "[autotest] packages:"
  dpkg-query -W -f='${binary:Package}\n' gnome-shell gnome-session yaru-theme-gtk yaru-theme-icon gnome-shell-extension-dashtodock neofetch
  echo
  rm -f /var/lib/strayos/booting
  poweroff -f
fi

cd /root || cd /

while true; do
  show_banner

  if grep -q 'console=ttyS0' /proc/cmdline 2>/dev/null; then
    /bin/busybox cttyhack /bin/bash -l || /bin/bash -l </dev/console >/dev/console 2>&1 || /bin/sh </dev/console >/dev/console 2>&1
  else
    /bin/busybox setsid /bin/bash -l </dev/tty1 >/dev/tty1 2>&1 || \
      /bin/bash -l </dev/console >/dev/console 2>&1 || \
      /bin/sh </dev/console >/dev/console 2>&1
  fi

  echo "Shell exited. Restarting StrayOS console..." >/dev/console 2>&1 || true
  sleep 1
done
EOF
}

write_gui_installer() {
  local file="$1"
  cat <<'EOF' | sudo tee "$file" >/dev/null
#!/bin/sh
set -u

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

die() {
  zenity --error --width=560 --title="StrayOS Installer" --text="$1" 2>/dev/null || echo "ERROR: $1" >&2
  exit 1
}

for cmd in zenity lsblk strayos-install strayos-install-progress; do
  command -v "$cmd" >/dev/null 2>&1 || die "Missing command: $cmd"
done

[ "$(id -u)" = "0" ] || die "Run installer as root."

zenity --warning \
  --width=660 \
  --title="StrayOS Installer" \
  --text="Real installation mode.\n\nThis can erase a whole disk or format one selected partition. Check device size and model carefully." \
  2>/dev/null || exit 1

if zenity --question --width=580 --title="StrayOS Installer" \
  --text="Stage: Wi-Fi\n\nConnect to Wi-Fi now?\n\nThe saved Wi-Fi profile will be copied into installed StrayOS and auto-started on boot." \
  2>/dev/null; then
  strayos-wifi-gui || true
fi

mode="$(zenity --list --radiolist \
  --width=660 --height=260 \
  --title="StrayOS Installer" \
  --text="Stage: choose installation mode" \
  --column="" --column="Mode" --column="Meaning" \
  TRUE "Whole disk" "Erase a disk, create one StrayOS ext4 partition, install GRUB" \
  FALSE "Selected partition" "Format only one selected partition/volume" \
  2>/dev/null)" || exit 1

[ -n "$mode" ] || exit 1

input="/tmp/strayos-install-input.$$"
log="/tmp/strayos-install-progress.log"
rm -f "$input" "$log"

if [ "$mode" = "Whole disk" ]; then
  disk="$(
    lsblk -dn -P -o PATH,SIZE,MODEL,TYPE |
    while IFS= read -r line; do
      eval "$line"
      [ "${TYPE:-}" = "disk" ] || continue
      case "${PATH:-}" in /dev/sr*|/dev/loop*) continue ;; esac
      printf '%s\n%s\n%s\n' "$PATH" "${SIZE:-?}" "${MODEL:-unknown}"
    done |
    zenity --list --width=780 --height=380 \
      --title="StrayOS Installer" \
      --text="Stage: select target disk to erase" \
      --column="Device" --column="Size" --column="Model" \
      2>/dev/null
  )" || exit 1

  [ -n "$disk" ] || exit 1

  confirm="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm erase\n\nTo erase $disk and install StrayOS, type exactly:\n\nERASE $disk" 2>/dev/null)" || exit 1
  [ "$confirm" = "ERASE $disk" ] || die "Confirmation did not match."

  confirm_grub="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm bootloader\n\nTo install GRUB bootloader to $disk, type exactly:\n\nINSTALL GRUB $disk" 2>/dev/null)" || exit 1
  [ "$confirm_grub" = "INSTALL GRUB $disk" ] || die "Bootloader confirmation did not match."

  printf '1\n%s\nERASE %s\nINSTALL GRUB %s\n' "$disk" "$disk" "$disk" > "$input"
else
  part="$(
    lsblk -pn -P -o PATH,SIZE,FSTYPE,LABEL,TYPE,MOUNTPOINTS |
    while IFS= read -r line; do
      eval "$line"
      case "${TYPE:-}" in part|lvm) ;;
        *) continue ;;
      esac
      case "${PATH:-}" in /dev/loop*|/dev/sr*) continue ;; esac
      printf '%s\n%s\n%s\n%s\n%s\n' "$PATH" "${SIZE:-?}" "${FSTYPE:-}" "${LABEL:-}" "${MOUNTPOINTS:-}"
    done |
    zenity --list --width=880 --height=430 \
      --title="StrayOS Installer" \
      --text="Stage: select partition/volume to format" \
      --column="Device" --column="Size" --column="FS" --column="Label" --column="Mounted at" \
      2>/dev/null
  )" || exit 1

  [ -n "$part" ] || exit 1

  confirm="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm format\n\nTo format $part as StrayOS root, type exactly:\n\nFORMAT $part" 2>/dev/null)" || exit 1
  [ "$confirm" = "FORMAT $part" ] || die "Confirmation did not match."

  parent="$(lsblk -no PKNAME "$part" 2>/dev/null | head -1)"
  boot_disk=""
  install_grub="no"
  if [ -n "$parent" ]; then
    boot_disk="/dev/$parent"
    if zenity --question --width=580 --title="StrayOS Installer" \
      --text="Stage: bootloader\n\nInstall GRUB bootloader to parent disk?\n\n$boot_disk" 2>/dev/null; then
      install_grub="yes"
    fi
  fi

  if [ "$install_grub" = "yes" ]; then
    confirm_grub="$(zenity --entry --width=640 --title="StrayOS Installer" \
      --text="Stage: confirm bootloader\n\nTo install GRUB bootloader to $boot_disk, type exactly:\n\nINSTALL GRUB $boot_disk" 2>/dev/null)" || exit 1
    [ "$confirm_grub" = "INSTALL GRUB $boot_disk" ] || die "Bootloader confirmation did not match."
    printf '2\n%s\nFORMAT %s\nyes\nINSTALL GRUB %s\n' "$part" "$part" "$boot_disk" > "$input"
  else
    printf '2\n%s\nFORMAT %s\nno\n' "$part" "$part" > "$input"
  fi
fi

if strayos-install-progress "$input" "$log" | zenity --progress \
  --width=620 \
  --title="StrayOS Installer" \
  --text="Stage: starting" \
  --percentage=0 \
  --auto-close; then
  zenity --info --width=560 --title="StrayOS Installer" --text="Installation complete.\n\nYou can reboot and boot from the installed disk." 2>/dev/null || true
  rm -f "$input"
  exit 0
fi

tail_msg="$(tail -60 "$log" 2>/dev/null)"
zenity --error --width=760 --height=420 --title="StrayOS Installer failed" --text="Installation failed.\n\nLast log lines:\n\n$tail_msg" 2>/dev/null || true
rm -f "$input"
exit 1
EOF
}

patch_image() {
  local image="$1" mount_dir loop_dev part partuuid uuid
  mount_dir="/tmp/strayos-resilient-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"
  sudo mount "$part" "$mount_dir"

  sudo cp "$INITRAMFS_OUT" "$mount_dir/boot/initramfs-strayos.cpio.gz"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/sbin/strayos-network-autostart" >/dev/null
#!/bin/sh
set +e

strayos-start-udev 2>/dev/null || true
for mod in iwlwifi iwldvm iwlmvm ath9k ath9k_htc ath10k_pci brcmfmac b43 rt2800usb mt7601u rtw88_core rtw88_pci rtw88_usb rtw89_core rtw89_pci btusb; do
  modprobe "$mod" 2>/dev/null || true
done
rfkill unblock all 2>/dev/null || true

mkdir -p /run/NetworkManager /etc/NetworkManager/system-connections
if command -v NetworkManager >/dev/null 2>&1 && ! pgrep NetworkManager >/dev/null 2>&1; then
  NetworkManager --no-daemon >/tmp/strayos-networkmanager.log 2>&1 &
  sleep 4
fi

nmcli networking on 2>/dev/null || true
nmcli radio wifi on 2>/dev/null || true
nmcli device set wlan0 managed yes 2>/dev/null || true
nmcli device wifi rescan 2>/dev/null || true

nmcli -t -f NAME,TYPE connection show 2>/dev/null |
while IFS=: read -r name type; do
  [ "$type" = "802-11-wireless" ] || continue
  nmcli connection up "$name" >/dev/null 2>&1 && exit 0
done

nmcli device connect eth0 >/dev/null 2>&1 || true
EOF
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-network-autostart"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-wifi-gui" >/dev/null
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

msg() { zenity --info --width=520 --title="StrayOS Wi-Fi" --text="$1" 2>/dev/null || true; }
err() { zenity --error --width=560 --title="StrayOS Wi-Fi" --text="$1" 2>/dev/null || true; }

strayos-network-autostart >/tmp/strayos-wifi-gui-start.log 2>&1 &
sleep 5

if ! command -v nmcli >/dev/null 2>&1; then
  err "NetworkManager/nmcli is missing."
  exit 1
fi

nmcli radio wifi on 2>/dev/null || true
nmcli device wifi rescan 2>/dev/null || true

networks="$(
  nmcli -t -f SSID,SIGNAL,SECURITY device wifi list 2>/dev/null |
  awk -F: 'length($1)>0 { print $1 "\n" $2 "%\n" $3 }'
)"

ssid=""
if [ -n "$networks" ]; then
  ssid="$(printf '%s\n' "$networks" | zenity --list --width=720 --height=420 \
    --title="StrayOS Wi-Fi" \
    --text="Choose Wi-Fi network for live/install/installed StrayOS" \
    --column="SSID" --column="Signal" --column="Security" 2>/dev/null)"
fi

if [ -z "$ssid" ]; then
  ssid="$(zenity --entry --width=520 --title="StrayOS Wi-Fi" --text="Enter Wi-Fi SSID manually:" 2>/dev/null)" || exit 0
fi
[ -n "$ssid" ] || exit 0

password="$(zenity --password --width=420 --title="Password for $ssid" 2>/dev/null)"

if [ -n "$password" ]; then
  nmcli device wifi connect "$ssid" password "$password" >/tmp/strayos-wifi-connect.log 2>&1
else
  nmcli device wifi connect "$ssid" >/tmp/strayos-wifi-connect.log 2>&1
fi

if [ "$?" -eq 0 ]; then
  msg "Connected to Wi-Fi: $ssid\n\nThis saved profile will be copied into the installed StrayOS."
  exit 0
fi

err "Could not connect to $ssid.\n\n$(tail -20 /tmp/strayos-wifi-connect.log 2>/dev/null)"
exit 1
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-wifi-gui"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-poweroff" >/dev/null
#!/bin/sh
set +e
rm -f /var/lib/strayos/booting
sync
poweroff -f
EOF
  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-reboot" >/dev/null
#!/bin/sh
set +e
rm -f /var/lib/strayos/booting
sync
reboot -f
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-poweroff" "$mount_dir/usr/local/bin/strayos-reboot"

  write_main_init "$mount_dir/init"
  sudo sh -n "$mount_dir/init"

  # Make the current bootable image use the recovery initramfs too.
  partuuid="$(sudo blkid -s PARTUUID -o value "$part" 2>/dev/null || true)"
  if [[ -n "$partuuid" && -f "$mount_dir/boot/grub/grub.cfg" ]]; then
    sudo perl -0pi -e 's/(linux \/boot\/vmlinuz-strayos [^\n]+\n)(?!\s*initrd)/$1    initrd \/boot\/initramfs-strayos.cpio.gz\n/g' "$mount_dir/boot/grub/grub.cfg"
  fi

  # New installs: require and install initramfs, boot via PARTUUID + initrd.
  if ! sudo grep -q 'Missing /boot/initramfs-strayos.cpio.gz after copy' "$mount_dir/usr/local/sbin/strayos-install"; then
    sudo sed -i '/Missing \/boot\/vmlinuz-strayos after copy/a \\  [[ -f "$target/boot/initramfs-strayos.cpio.gz" ]] || die "Missing /boot/initramfs-strayos.cpio.gz after copy."' "$mount_dir/usr/local/sbin/strayos-install"
  fi
  sudo perl -0pi -e 's/(linux \/boot\/vmlinuz-strayos root=PARTUUID=\$partuuid[^\n]+\n)(?!\s*initrd)/$1    initrd \/boot\/initramfs-strayos.cpio.gz\n/g' "$mount_dir/usr/local/sbin/strayos-install"
  sudo sed -i 's/echo "Installed root: "$/echo "Installed root: $TARGET_PARTITION"/' "$mount_dir/usr/local/sbin/strayos-install" || true
  sudo sed -i 's/echo "Installed root PARTUUID: "$/echo "Installed root PARTUUID: $partuuid"/' "$mount_dir/usr/local/sbin/strayos-install" || true
  sudo bash -n "$mount_dir/usr/local/sbin/strayos-install"

  if [[ -f "$mount_dir/usr/local/sbin/strayos-repair-boot" ]]; then
    sudo perl -0pi -e 's/(linux \/boot\/vmlinuz-strayos root=PARTUUID=\$partuuid[^\n]+\n)(?!\s*initrd)/$1    initrd \/boot\/initramfs-strayos.cpio.gz\n/g' "$mount_dir/usr/local/sbin/strayos-repair-boot"
    sudo bash -n "$mount_dir/usr/local/sbin/strayos-repair-boot"
  fi

  # Wi-Fi chooser in the graphical installer before disk selection, so profiles are copied by rsync.
  write_gui_installer "$mount_dir/usr/local/sbin/strayos-install-gui"
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-install-gui"
  sudo sh -n "$mount_dir/usr/local/sbin/strayos-install-gui"

  sudo sh -n "$mount_dir/usr/local/sbin/strayos-network-autostart"
  sudo sh -n "$mount_dir/usr/local/bin/strayos-wifi-gui"
  sudo sh -n "$mount_dir/usr/local/bin/strayos-poweroff"
  sudo sh -n "$mount_dir/usr/local/bin/strayos-reboot"
  sudo sync
  cleanup
  trap - RETURN
}

build_recovery_initramfs
for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum "$PROJECT_DIR/disks/StrayOS-bootable-5g.img" > "$PROJECT_DIR/disks/StrayOS-bootable-5g.img.sha256"
sha256sum "$PROJECT_DIR/disks/strayos-5g.img" > "$PROJECT_DIR/disks/strayos-5g.img.sha256"

echo "Patched StrayOS resilience, recovery initramfs, Wi-Fi autostart, and Wi-Fi installer chooser."
