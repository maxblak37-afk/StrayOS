# APT Compatibility

StrayOS will use a Debian-style package stack:

- `dpkg` for installing and tracking `.deb` packages locally
- `apt` for dependency resolution, repository metadata, downloads, and upgrades

This means StrayOS needs more than the `apt` command. A working APT system also
needs:

- `dpkg`
- Debian package metadata under `/var/lib/dpkg`
- APT config under `/etc/apt`
- package lists under `/var/lib/apt/lists`
- package archives under `/var/cache/apt/archives`
- a compatible repository

## Current Source Set

- Linux kernel: `linux-7.0.4`
- APT source: `apt_3.3.0`
- dpkg source: `dpkg_1.23.7`

These are source archives, not yet built packages. The next step is to build a
minimal Linux system first, then build `dpkg`, then build `apt`.

## Repository Choice

There are two possible directions:

- Debian-compatible StrayOS: use Debian repositories directly where ABI and
  package dependencies match.
- Independent StrayOS: use APT/dpkg tools but publish our own StrayOS `.deb`
  repository.

For a real from-scratch distro, the second option is cleaner. The first option is
faster but makes StrayOS effectively Debian-derived.
