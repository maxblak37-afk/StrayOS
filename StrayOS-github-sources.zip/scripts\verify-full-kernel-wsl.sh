#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
WORK_DIR="${WORK_DIR:-$HOME/strayos-build-full}"
JOBS="${JOBS:-$(nproc)}"

ARCHIVE="$PROJECT_DIR/sources/linux-master-full-source.tar.gz"
SOURCE_DIR="$WORK_DIR/linux-master"
OUT_DIR="$PROJECT_DIR/build/full-kernel"
LOG_DIR="$PROJECT_DIR/build/logs"
INITRAMFS="$PROJECT_DIR/build/minimal/strayos-initramfs.cpio.gz"

mkdir -p "$WORK_DIR" "$OUT_DIR" "$LOG_DIR"

if [[ ! -f "$ARCHIVE" ]]; then
  echo "Missing archive: $ARCHIVE" >&2
  exit 1
fi

if [[ ! -f "$INITRAMFS" ]]; then
  echo "Missing initramfs: $INITRAMFS" >&2
  echo "Build the minimal StrayOS image first." >&2
  exit 1
fi

rm -rf "$SOURCE_DIR"
tar -C "$WORK_DIR" -xzf "$ARCHIVE"

cd "$SOURCE_DIR"
KERNEL_VERSION="$(make -s kernelversion)"
echo "$KERNEL_VERSION" > "$OUT_DIR/kernel-version.txt"

make x86_64_defconfig
scripts/config \
  --enable CONFIG_DEVTMPFS \
  --enable CONFIG_DEVTMPFS_MOUNT \
  --enable CONFIG_BLK_DEV_INITRD \
  --disable CONFIG_DEBUG_INFO \
  --disable CONFIG_DEBUG_INFO_BTF \
  --disable CONFIG_MODULE_SIG
make olddefconfig
make -j"$JOBS" bzImage 2>&1 | tee "$LOG_DIR/full-kernel-build.log"

cp "$SOURCE_DIR/arch/x86/boot/bzImage" "$OUT_DIR/strayos-full-source-bzImage"

cat > "$OUT_DIR/run-qemu.sh" <<'RUN_QEMU'
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"
qemu-system-x86_64 \
  -m 512M \
  -kernel "$DIR/strayos-full-source-bzImage" \
  -initrd "$PROJECT_DIR/build/minimal/strayos-initramfs.cpio.gz" \
  -append "console=ttyS0 quiet panic=-1" \
  -nographic \
  -no-reboot
RUN_QEMU
chmod +x "$OUT_DIR/run-qemu.sh"

cat > "$OUT_DIR/run-qemu-test.sh" <<'RUN_QEMU_TEST'
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"
qemu-system-x86_64 \
  -m 512M \
  -kernel "$DIR/strayos-full-source-bzImage" \
  -initrd "$PROJECT_DIR/build/minimal/strayos-initramfs.cpio.gz" \
  -append "console=ttyS0 quiet panic=-1 strayos.autotest=1" \
  -nographic \
  -no-reboot
RUN_QEMU_TEST
chmod +x "$OUT_DIR/run-qemu-test.sh"

cd "$OUT_DIR"
timeout 60 ./run-qemu-test.sh 2>&1 | tee "$LOG_DIR/full-kernel-qemu-boot.log"

echo "Built and boot-tested full-source kernel $KERNEL_VERSION"
