#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-final-xorg-check}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

echo "--- grub ---"
sudo sed -n '1,80p' "$MOUNT_DIR/boot/grub/grub.cfg"

echo "--- xorg conf.d ---"
sudo find "$MOUNT_DIR/etc/X11/xorg.conf.d" -maxdepth 1 -type f -print

echo "--- strayos-gnome ---"
sudo sed -n '1,100p' "$MOUNT_DIR/usr/local/bin/strayos-gnome"

test ! -f "$MOUNT_DIR/etc/X11/xorg.conf.d/10-strayos-fbdev.conf"
test ! -f "$MOUNT_DIR/etc/X11/xorg.conf.d/10-strayos-auto.conf"
grep -q 'StrayOS safe graphics' "$MOUNT_DIR/boot/grub/grub.cfg"
grep -q 'dbus-run-session' "$MOUNT_DIR/usr/local/bin/strayos-gnome"

echo "Graphics fix check: OK"
