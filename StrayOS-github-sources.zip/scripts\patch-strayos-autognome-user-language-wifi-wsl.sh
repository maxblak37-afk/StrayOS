#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
images=(
  "$PROJECT_DIR/disks/strayos-5g.img"
  "$PROJECT_DIR/disks/StrayOS-bootable-5g.img"
)

write_gnome_launcher() {
  local mount_dir="$1"
  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-gnome" >/dev/null
#!/bin/sh
set +e

export LIBGL_ALWAYS_SOFTWARE=1
export MUTTER_DEBUG_DISABLE_HW_CURSORS=1
export CLUTTER_VBLANK=none
export GSK_RENDERER=cairo
export XDG_SESSION_TYPE=x11
export XDG_CURRENT_DESKTOP=GNOME
export GDMSESSION=gnome
export XDG_RUNTIME_DIR=/run/user/0

swapon /swapfile 2>/dev/null || true
strayos-start-udev 2>/dev/null || true
strayos-network-autostart >/tmp/strayos-network-autostart.log 2>&1 &

mkdir -p /run/dbus /run/user/0 /tmp /tmp/.X11-unix
chmod 700 /run/user/0 2>/dev/null || true
chmod 1777 /tmp /tmp/.X11-unix 2>/dev/null || true
rm -f /tmp/.X0-lock /tmp/.X1-lock /tmp/.X11-unix/X0 /tmp/.X11-unix/X1
rm -f /root/.Xauthority /root/.ICEauthority
dbus-daemon --system --fork 2>/dev/null || true

gsettings set org.gnome.desktop.interface enable-animations false 2>/dev/null || true
gsettings set org.gnome.mutter experimental-features "[]" 2>/dev/null || true
gnome-extensions disable dash-to-dock@micxgx.gmail.com 2>/dev/null || true
gnome-extensions disable ubuntu-dock@ubuntu.com 2>/dev/null || true

echo "Starting StrayOS GNOME safe Xorg session..."
echo "If GNOME exits, StrayOS will return to console."
exec dbus-run-session -- startx /root/.xinitrc -- :0 vt1 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-gnome"
  sudo rm -f "$mount_dir/usr/local/bin/strayos-gnome-safe"
}

write_main_init() {
  local file="$1"
  cat <<'EOF' | sudo tee "$file" >/dev/null
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TERM=linux
export LANG="$(cat /etc/strayos/locale 2>/dev/null || echo C.UTF-8)"

mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
mount -t tmpfs -o mode=0755,nosuid,nodev tmpfs /run 2>/dev/null || true
mount -t tmpfs -o mode=1777,nosuid,nodev tmpfs /tmp 2>/dev/null || true
mkdir -p /dev/pts /run /tmp /root /run/user/0 /var/lib/strayos /etc/strayos
mount -t devpts devpts /dev/pts 2>/dev/null || true
chmod 1777 /tmp 2>/dev/null || true
chmod 700 /run/user/0 2>/dev/null || true

if [ -f /var/lib/strayos/booting ]; then
  echo "Previous StrayOS shutdown was not clean; resetting GNOME/Xorg volatile state." >/dev/console 2>&1 || true
  rm -f /tmp/.X0-lock /tmp/.X1-lock /tmp/.X11-unix/X0 /tmp/.X11-unix/X1
  rm -f /root/.Xauthority /root/.ICEauthority /root/.xsession-errors /root/.xsession-errors.old
  rm -rf /root/.cache/gnome-shell /root/.local/share/gnome-shell /root/.local/share/gvfs-metadata
  rm -f /root/.config/monitors.xml
fi
date > /var/lib/strayos/booting 2>/dev/null || true

hostname "$(cat /etc/hostname 2>/dev/null || echo strayos)" 2>/dev/null || true
swapon /swapfile 2>/dev/null || true
sysctl -w vm.swappiness=80 >/dev/null 2>&1 || true

ip link set lo up 2>/dev/null || true
ip link set eth0 up 2>/dev/null || true
dhclient -1 eth0 2>/dev/null || true
strayos-network-autostart >/tmp/strayos-network-autostart.log 2>&1 &

show_banner() {
  clear 2>/dev/null || true
  cat /etc/issue 2>/dev/null || echo "StrayOS"
  echo "Kernel: $(uname -r)"
  echo "Disk: persistent ext4 StrayOS"
  echo
  echo "StrayOS base is still Debian APT:"
  apt --version 2>/dev/null || true
  echo
  echo "Commands:"
  echo "  strayos-gnome"
  echo "  strayos-gnome-reset"
  echo "  strayos-light"
  echo "  strayos-browser"
  echo "  strayos-wifi"
  echo "  strayos-wifi-gui"
  echo "  strayos-installer-gui"
  echo "  strayos-repair-boot"
  echo "  strayos-about"
  echo "  strayos-poweroff"
  echo "  strayos-reboot"
  echo
  echo "GNOME autostarts by default. Add strayos.no-gui in GRUB to boot console only."
  echo
}

if grep -q 'strayos.autotest=1' /proc/cmdline 2>/dev/null; then
  show_banner
  cat /etc/os-release
  apt --version
  neofetch --version
  dpkg-query -W -f='${binary:Package}\n' gnome-shell firefox-esr neofetch
  rm -f /var/lib/strayos/booting
  poweroff -f
fi

cd /root || cd /

if ! grep -q 'console=ttyS0' /proc/cmdline 2>/dev/null && ! grep -q 'strayos.no-gui' /proc/cmdline 2>/dev/null; then
  show_banner
  echo "Autostarting GNOME..." >/dev/console 2>&1 || true
  strayos-gnome </dev/tty1 >/dev/tty1 2>&1
  echo "GNOME exited. Falling back to StrayOS console." >/dev/console 2>&1 || true
  sleep 2
fi

while true; do
  show_banner

  if grep -q 'console=ttyS0' /proc/cmdline 2>/dev/null; then
    /bin/busybox cttyhack /bin/bash -l || /bin/bash -l </dev/console >/dev/console 2>&1 || /bin/sh </dev/console >/dev/console 2>&1
  else
    /bin/busybox setsid /bin/bash -l </dev/tty1 >/dev/tty1 2>&1 || \
      /bin/bash -l </dev/console >/dev/console 2>&1 || \
      /bin/sh </dev/console >/dev/console 2>&1
  fi

  echo "Shell exited. Restarting StrayOS console..." >/dev/console 2>&1 || true
  sleep 1
done
EOF
  sudo chmod +x "$file"
}

write_about() {
  local mount_dir="$1"
  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-about" >/dev/null
#!/bin/sh
cat <<INFO
StrayOS

Base: Debian APT rootfs
Desktop: GNOME Shell safe Xorg profile
Browser: Firefox ESR
Network: NetworkManager with saved Wi-Fi profiles
Recovery: boot-time ext4 check through StrayOS recovery initramfs

Useful commands:
  strayos-gnome
  strayos-browser
  strayos-wifi-gui
  strayos-poweroff
INFO
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-about"
}

write_gui_installer() {
  local file="$1"
  cat <<'EOF' | sudo tee "$file" >/dev/null
#!/bin/sh
set -u

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

die() {
  zenity --error --width=560 --title="StrayOS Installer" --text="$1" 2>/dev/null || echo "ERROR: $1" >&2
  exit 1
}

shell_quote() {
  printf "%s" "$1" | sed "s/'/'\\\\''/g; 1s/^/'/; \$s/\$/'/"
}

for cmd in zenity lsblk strayos-install strayos-install-progress; do
  command -v "$cmd" >/dev/null 2>&1 || die "Missing command: $cmd"
done

[ "$(id -u)" = "0" ] || die "Run installer as root."

zenity --warning \
  --width=660 \
  --title="StrayOS Installer" \
  --text="Real installation mode.\n\nThis can erase a whole disk or format one selected partition. Check device size and model carefully." \
  2>/dev/null || exit 1

if zenity --question --width=580 --title="StrayOS Installer" \
  --text="Stage: Wi-Fi\n\nConnect to Wi-Fi now?\n\nSaved Wi-Fi profile will be copied into installed StrayOS." \
  2>/dev/null; then
  strayos-wifi-gui || true
fi

username="$(zenity --entry --width=520 --title="StrayOS Installer" --text="Stage: user\n\nUser name:" --entry-text="stray" 2>/dev/null)" || exit 1
username="$(printf "%s" "$username" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9_-')"
[ -n "$username" ] || username="stray"
case "$username" in
  [a-z_]* ) ;;
  * ) username="stray" ;;
esac

password="$(zenity --password --width=420 --title="Password for $username" 2>/dev/null)" || exit 1
[ -n "$password" ] || die "Password cannot be empty."
password2="$(zenity --password --width=420 --title="Repeat password for $username" 2>/dev/null)" || exit 1
[ "$password" = "$password2" ] || die "Passwords do not match."

language_choice="$(zenity --list --radiolist --width=620 --height=300 \
  --title="StrayOS Installer" \
  --text="Stage: language" \
  --column="" --column="Language" --column="Locale" \
  TRUE "Russian" "ru_RU.UTF-8" \
  FALSE "English" "en_US.UTF-8" \
  FALSE "Default" "C.UTF-8" \
  2>/dev/null)" || exit 1
case "$language_choice" in
  Russian) locale="ru_RU.UTF-8" ;;
  English) locale="en_US.UTF-8" ;;
  *) locale="C.UTF-8" ;;
esac

hostname_value="$(zenity --entry --width=520 --title="StrayOS Installer" --text="Stage: computer name" --entry-text="strayos" 2>/dev/null)" || exit 1
hostname_value="$(printf "%s" "$hostname_value" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9-')"
[ -n "$hostname_value" ] || hostname_value="strayos"

settings="/tmp/strayos-install-settings.$$"
{
  printf 'STRAYOS_USERNAME=%s\n' "$(shell_quote "$username")"
  printf 'STRAYOS_PASSWORD=%s\n' "$(shell_quote "$password")"
  printf 'STRAYOS_LOCALE=%s\n' "$(shell_quote "$locale")"
  printf 'STRAYOS_HOSTNAME=%s\n' "$(shell_quote "$hostname_value")"
  printf 'STRAYOS_AUTOGNOME=yes\n'
} > "$settings"
export STRAYOS_INSTALL_SETTINGS="$settings"

mode="$(zenity --list --radiolist \
  --width=660 --height=260 \
  --title="StrayOS Installer" \
  --text="Stage: choose installation mode" \
  --column="" --column="Mode" --column="Meaning" \
  TRUE "Whole disk" "Erase a disk, create one StrayOS ext4 partition, install GRUB" \
  FALSE "Selected partition" "Format only one selected partition/volume" \
  2>/dev/null)" || exit 1

[ -n "$mode" ] || exit 1

input="/tmp/strayos-install-input.$$"
log="/tmp/strayos-install-progress.log"
rm -f "$input" "$log"

if [ "$mode" = "Whole disk" ]; then
  disk="$(
    lsblk -dn -P -o PATH,SIZE,MODEL,TYPE |
    while IFS= read -r line; do
      eval "$line"
      [ "${TYPE:-}" = "disk" ] || continue
      case "${PATH:-}" in /dev/sr*|/dev/loop*) continue ;; esac
      printf '%s\n%s\n%s\n' "$PATH" "${SIZE:-?}" "${MODEL:-unknown}"
    done |
    zenity --list --width=780 --height=380 \
      --title="StrayOS Installer" \
      --text="Stage: select target disk to erase" \
      --column="Device" --column="Size" --column="Model" \
      2>/dev/null
  )" || exit 1

  [ -n "$disk" ] || exit 1

  confirm="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm erase\n\nTo erase $disk and install StrayOS, type exactly:\n\nERASE $disk" 2>/dev/null)" || exit 1
  [ "$confirm" = "ERASE $disk" ] || die "Confirmation did not match."

  confirm_grub="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm bootloader\n\nTo install GRUB bootloader to $disk, type exactly:\n\nINSTALL GRUB $disk" 2>/dev/null)" || exit 1
  [ "$confirm_grub" = "INSTALL GRUB $disk" ] || die "Bootloader confirmation did not match."

  printf '1\n%s\nERASE %s\nINSTALL GRUB %s\n' "$disk" "$disk" "$disk" > "$input"
else
  part="$(
    lsblk -pn -P -o PATH,SIZE,FSTYPE,LABEL,TYPE,MOUNTPOINTS |
    while IFS= read -r line; do
      eval "$line"
      case "${TYPE:-}" in part|lvm) ;;
        *) continue ;;
      esac
      case "${PATH:-}" in /dev/loop*|/dev/sr*) continue ;; esac
      printf '%s\n%s\n%s\n%s\n%s\n' "$PATH" "${SIZE:-?}" "${FSTYPE:-}" "${LABEL:-}" "${MOUNTPOINTS:-}"
    done |
    zenity --list --width=880 --height=430 \
      --title="StrayOS Installer" \
      --text="Stage: select partition/volume to format" \
      --column="Device" --column="Size" --column="FS" --column="Label" --column="Mounted at" \
      2>/dev/null
  )" || exit 1

  [ -n "$part" ] || exit 1

  confirm="$(zenity --entry --width=640 --title="StrayOS Installer" \
    --text="Stage: confirm format\n\nTo format $part as StrayOS root, type exactly:\n\nFORMAT $part" 2>/dev/null)" || exit 1
  [ "$confirm" = "FORMAT $part" ] || die "Confirmation did not match."

  parent="$(lsblk -no PKNAME "$part" 2>/dev/null | head -1)"
  boot_disk=""
  install_grub="no"
  if [ -n "$parent" ]; then
    boot_disk="/dev/$parent"
    if zenity --question --width=580 --title="StrayOS Installer" \
      --text="Stage: bootloader\n\nInstall GRUB bootloader to parent disk?\n\n$boot_disk" 2>/dev/null; then
      install_grub="yes"
    fi
  fi

  if [ "$install_grub" = "yes" ]; then
    confirm_grub="$(zenity --entry --width=640 --title="StrayOS Installer" \
      --text="Stage: confirm bootloader\n\nTo install GRUB bootloader to $boot_disk, type exactly:\n\nINSTALL GRUB $boot_disk" 2>/dev/null)" || exit 1
    [ "$confirm_grub" = "INSTALL GRUB $boot_disk" ] || die "Bootloader confirmation did not match."
    printf '2\n%s\nFORMAT %s\nyes\nINSTALL GRUB %s\n' "$part" "$part" "$boot_disk" > "$input"
  else
    printf '2\n%s\nFORMAT %s\nno\n' "$part" "$part" > "$input"
  fi
fi

if strayos-install-progress "$input" "$log" | zenity --progress \
  --width=620 \
  --title="StrayOS Installer" \
  --text="Stage: starting" \
  --percentage=0 \
  --auto-close; then
  zenity --info --width=560 --title="StrayOS Installer" --text="Installation complete.\n\nUser: $username\nLanguage: $locale\nGNOME autostart: enabled\n\nYou can reboot and boot from the installed disk." 2>/dev/null || true
  rm -f "$input" "$settings"
  exit 0
fi

tail_msg="$(tail -60 "$log" 2>/dev/null)"
zenity --error --width=760 --height=420 --title="StrayOS Installer failed" --text="Installation failed.\n\nLast log lines:\n\n$tail_msg" 2>/dev/null || true
rm -f "$input" "$settings"
exit 1
EOF
  sudo chmod +x "$file"
}

patch_installer() {
  local file="$1" tmp
  tmp="$(mktemp)"
  awk '
    /^write_installed_config\(\) \{/ {
      print "apply_install_settings() {"
      print "  local target=\"$1\" settings username password locale hostname_value"
      print "  settings=\"${STRAYOS_INSTALL_SETTINGS:-/tmp/strayos-install-settings}\""
      print "  [[ -f \"$settings\" ]] || return 0"
      print "  # shellcheck disable=SC1090"
      print "  source \"$settings\""
      print "  username=\"${STRAYOS_USERNAME:-stray}\""
      print "  password=\"${STRAYOS_PASSWORD:-strayos}\""
      print "  locale=\"${STRAYOS_LOCALE:-C.UTF-8}\""
      print "  hostname_value=\"${STRAYOS_HOSTNAME:-strayos}\""
      print "  username=\"$(printf \"%s\" \"$username\" | tr \"A-Z\" \"a-z\" | tr -cd \"a-z0-9_-\")\""
      print "  [[ -n \"$username\" ]] || username=\"stray\""
      print "  mkdir -p \"$target/etc/strayos\""
      print "  echo \"$username\" > \"$target/etc/strayos/default-user\""
      print "  echo \"$locale\" > \"$target/etc/strayos/locale\""
      print "  echo \"$hostname_value\" > \"$target/etc/hostname\""
      print "  cat > \"$target/etc/default/locale\" <<EOF_LOCALE"
      print "LANG=$locale"
      print "LC_ALL=$locale"
      print "EOF_LOCALE"
      print "  cat > \"$target/etc/hosts\" <<EOF_HOSTS"
      print "127.0.0.1 localhost"
      print "127.0.1.1 $hostname_value"
      print "EOF_HOSTS"
      print "  if [[ -f \"$target/etc/locale.gen\" && \"$locale\" != \"C.UTF-8\" ]]; then"
      print "    sed -i \"s/^# *$locale UTF-8/$locale UTF-8/\" \"$target/etc/locale.gen\" || true"
      print "    chroot \"$target\" locale-gen \"$locale\" >/dev/null 2>&1 || true"
      print "  fi"
      print "  chroot \"$target\" sh -lc \"id -u $username >/dev/null 2>&1 || useradd -m -s /bin/bash -G sudo,adm,netdev,audio,video $username\" 2>/dev/null || \\"
      print "    chroot \"$target\" sh -lc \"id -u $username >/dev/null 2>&1 || useradd -m -s /bin/bash $username\""
      print "  printf \"%s:%s\\n\" \"$username\" \"$password\" | chroot \"$target\" chpasswd 2>/dev/null || true"
      print "  printf \"root:%s\\n\" \"$password\" | chroot \"$target\" chpasswd 2>/dev/null || true"
      print "  mkdir -p \"$target/home/$username\""
      print "  if [[ -f \"$target/root/.xinitrc\" ]]; then cp \"$target/root/.xinitrc\" \"$target/home/$username/.xinitrc\"; fi"
      print "  chroot \"$target\" chown -R \"$username:$username\" \"/home/$username\" 2>/dev/null || true"
      print "}"
      print ""
    }
    /^finish_install\(\) \{/ {
      print "finish_install() {"
      print "  sync"
      print "  umount \"$TARGET_MOUNT\" || true"
      print "  say \"Install complete.\""
      print "  echo \"Installed root: $TARGET_PARTITION\""
      print "  echo \"Boot disk: ${BOOT_DISK:-not installed}\""
      print "  echo"
      print "  echo \"You can now shut down and boot from the installed disk.\""
      print "}"
      skip=1
      next
    }
    /^main\(\) \{/ { skip=0 }
    /write_installed_config "\$TARGET_MOUNT" "\$BOOT_DISK" "\$install_grub"/ {
      print
      print "  apply_install_settings \"$TARGET_MOUNT\""
      next
    }
    !skip { print }
  ' "$file" > "$tmp"
  sudo cp "$tmp" "$file"
  rm -f "$tmp"
  dedupe_installer "$file"
  sudo bash -n "$file"
}

dedupe_installer() {
  local file="$1" tmp
  tmp="$(mktemp)"
  awk '
    /^apply_install_settings\(\) \{/ {
      apply_count++
      if (apply_count == 1) {
        print
        skip_apply=0
        next
      }
      skip_apply=1
      next
    }
    skip_apply && /^}$/ {
      skip_apply=0
      next
    }
    skip_apply { next }
    /apply_install_settings "\$TARGET_MOUNT"/ {
      call_count++
      if (call_count == 1) print
      next
    }
    { print }
  ' "$file" > "$tmp"
  sudo cp "$tmp" "$file"
  rm -f "$tmp"
}

patch_wifi_gui() {
  local file="$1"
  cat <<'EOF' | sudo tee "$file" >/dev/null
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

msg() { zenity --info --width=520 --title="StrayOS Wi-Fi" --text="$1" 2>/dev/null || true; }
err() { zenity --error --width=560 --title="StrayOS Wi-Fi" --text="$1" 2>/dev/null || true; }

strayos-network-autostart >/tmp/strayos-wifi-gui-start.log 2>&1 &
sleep 5

if ! command -v nmcli >/dev/null 2>&1; then
  err "NetworkManager/nmcli is missing."
  exit 1
fi

nmcli networking on 2>/dev/null || true
nmcli radio wifi on 2>/dev/null || true
nmcli device wifi rescan 2>/dev/null || true

networks="$(
  nmcli -t -f SSID,SIGNAL,SECURITY device wifi list 2>/dev/null |
  awk -F: 'length($1)>0 { print $1 "\n" $2 "%\n" $3 }'
)"

ssid=""
if [ -n "$networks" ]; then
  ssid="$(printf '%s\n' "$networks" | zenity --list --width=720 --height=420 \
    --title="StrayOS Wi-Fi" \
    --text="Choose Wi-Fi network. The password will be remembered for installed StrayOS." \
    --column="SSID" --column="Signal" --column="Security" 2>/dev/null)"
fi

if [ -z "$ssid" ]; then
  ssid="$(zenity --entry --width=520 --title="StrayOS Wi-Fi" --text="Enter Wi-Fi SSID manually:" 2>/dev/null)" || exit 0
fi
[ -n "$ssid" ] || exit 0

password="$(zenity --password --width=420 --title="Wi-Fi password for $ssid" 2>/dev/null)"

if [ -n "$password" ]; then
  nmcli device wifi connect "$ssid" password "$password" >/tmp/strayos-wifi-connect.log 2>&1
else
  nmcli device wifi connect "$ssid" >/tmp/strayos-wifi-connect.log 2>&1
fi

if [ "$?" -eq 0 ]; then
  nmcli connection modify "$ssid" connection.autoconnect yes 2>/dev/null || true
  active="$(nmcli -t -f NAME,DEVICE connection show --active 2>/dev/null | awk -F: 'NF>=2 && $2 ~ /^wl|^wlan/ {print $1; exit}')"
  [ -n "$active" ] && nmcli connection modify "$active" connection.autoconnect yes 2>/dev/null || true
  chmod 600 /etc/NetworkManager/system-connections/* 2>/dev/null || true
  msg "Connected to Wi-Fi: $ssid\n\nThis saved profile will be copied into installed StrayOS and autoconnect on boot."
  exit 0
fi

err "Could not connect to $ssid.\n\n$(tail -20 /tmp/strayos-wifi-connect.log 2>/dev/null)"
exit 1
EOF
  sudo chmod +x "$file"
  sudo sh -n "$file"
}

patch_image() {
  local image="$1" mount_dir loop_dev part
  mount_dir="/tmp/strayos-autognome-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  sleep 1
  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  sudo mount "$part" "$mount_dir"
  sudo mkdir -p "$mount_dir/etc/strayos"
  echo "C.UTF-8" | sudo tee "$mount_dir/etc/strayos/locale" >/dev/null

  write_gnome_launcher "$mount_dir"
  write_main_init "$mount_dir/init"
  write_about "$mount_dir"
  write_gui_installer "$mount_dir/usr/local/sbin/strayos-install-gui"
  patch_installer "$mount_dir/usr/local/sbin/strayos-install"
  patch_wifi_gui "$mount_dir/usr/local/bin/strayos-wifi-gui"

  sudo sh -n "$mount_dir/init"
  sudo sh -n "$mount_dir/usr/local/bin/strayos-gnome"
  sudo test ! -e "$mount_dir/usr/local/bin/strayos-gnome-safe"
  sudo grep -q 'strayos-gnome-safe' "$mount_dir/init" && exit 1 || true
  sudo grep -q 'Autostarting GNOME' "$mount_dir/init"
  sudo grep -q 'apply_install_settings' "$mount_dir/usr/local/sbin/strayos-install"
  sudo grep -q 'Password for' "$mount_dir/usr/local/sbin/strayos-install-gui"
  sudo grep -q 'Stage: language' "$mount_dir/usr/local/sbin/strayos-install-gui"
  sudo grep -q 'connection.autoconnect yes' "$mount_dir/usr/local/bin/strayos-wifi-gui"
  sudo sync
  cleanup
  trap - RETURN
}

for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum "$PROJECT_DIR/disks/StrayOS-bootable-5g.img" > "$PROJECT_DIR/disks/StrayOS-bootable-5g.img.sha256"
sha256sum "$PROJECT_DIR/disks/strayos-5g.img" > "$PROJECT_DIR/disks/strayos-5g.img.sha256"
echo "Patched StrayOS autostart GNOME, installer user/language/password, and remembered Wi-Fi."
