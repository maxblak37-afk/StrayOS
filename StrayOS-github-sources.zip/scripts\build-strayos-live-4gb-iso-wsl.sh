#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
KERNEL_SRC="${KERNEL_SRC:-/root/strayos-build-full/linux-master}"
SOURCE_IMG="${SOURCE_IMG:-$PROJECT_DIR/disks/strayos-5g.img}"
OUT_DIR="$PROJECT_DIR/iso"
BUILD_DIR="$PROJECT_DIR/build/live-4gb-iso"
ISO_TREE="$BUILD_DIR/iso-tree"
INITRAMFS_DIR="$BUILD_DIR/initramfs"
ROOT_MOUNT="$BUILD_DIR/root-mount"
LOG_DIR="$PROJECT_DIR/build/logs"
ISO_PATH="$OUT_DIR/StrayOS-live-4gb-amd64.iso"
KERNEL_OUT="$PROJECT_DIR/build/full-kernel/strayos-live-4gb-bzImage"

mkdir -p "$OUT_DIR" "$BUILD_DIR" "$ISO_TREE" "$INITRAMFS_DIR" "$ROOT_MOUNT" "$LOG_DIR"

for cmd in mksquashfs grub-mkrescue cpio gzip busybox; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "Missing command: $cmd" >&2
    exit 1
  }
done

if [[ ! -d "$KERNEL_SRC" ]]; then
  echo "Missing kernel source directory: $KERNEL_SRC" >&2
  exit 1
fi

if [[ ! -f "$SOURCE_IMG" ]]; then
  echo "Missing source image: $SOURCE_IMG" >&2
  exit 1
fi

echo "Configuring kernel for low-RAM live ISO..."
cd "$KERNEL_SRC"
scripts/config \
  --enable CONFIG_BLK_DEV_INITRD \
  --enable CONFIG_DEVTMPFS \
  --enable CONFIG_DEVTMPFS_MOUNT \
  --enable CONFIG_BLK_DEV_LOOP \
  --enable CONFIG_ISO9660_FS \
  --enable CONFIG_SQUASHFS \
  --enable CONFIG_SQUASHFS_ZLIB \
  --enable CONFIG_OVERLAY_FS \
  --enable CONFIG_TMPFS \
  --enable CONFIG_EXT4_FS \
  --enable CONFIG_USB_XHCI_HCD \
  --enable CONFIG_USB_XHCI_PCI \
  --enable CONFIG_USB_EHCI_HCD \
  --enable CONFIG_USB_OHCI_HCD \
  --enable CONFIG_USB_UHCI_HCD \
  --enable CONFIG_USB_STORAGE
make olddefconfig
make -j"$(nproc)" bzImage 2>&1 | tee "$LOG_DIR/live-4gb-kernel-build.log"
cp "$KERNEL_SRC/arch/x86/boot/bzImage" "$KERNEL_OUT"

echo "Building small live initramfs..."
rm -rf "$INITRAMFS_DIR"
mkdir -p "$INITRAMFS_DIR"/{bin,dev,proc,sys,newroot,media,ro,overlay,work,run,tmp}
cp /usr/bin/busybox "$INITRAMFS_DIR/bin/busybox"
for applet in sh mount umount mkdir mknod sleep cat echo ls dmesg switch_root losetup clear blkid grep cut awk sed find; do
  ln -sf busybox "$INITRAMFS_DIR/bin/$applet"
done

cat > "$INITRAMFS_DIR/init" <<'INIT'
#!/bin/sh
set +e
export PATH=/bin:/sbin:/usr/bin:/usr/sbin

mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || {
  mknod /dev/console c 5 1
  mknod /dev/null c 1 3
  mknod /dev/tty c 5 0
}

mkdir -p /media /ro /overlay /work /newroot /run /tmp

echo "StrayOS live loader: searching boot media..."

FOUND=""
i=0
while [ "$i" -lt 30 ]; do
  for dev in /dev/sr0 /dev/sr1 /dev/sd* /dev/hd* /dev/vd*; do
    [ -b "$dev" ] || continue
    umount /media 2>/dev/null || true
    mount -o ro "$dev" /media 2>/dev/null || continue
    if [ -f /media/strayos/rootfs.squashfs ]; then
      FOUND="$dev"
      break 2
    fi
  done
  sleep 1
  i=$((i + 1))
done

if [ -z "$FOUND" ]; then
  echo "ERROR: cannot find /strayos/rootfs.squashfs on USB/CD."
  echo "Available block devices:"
  ls -l /dev/sd* /dev/sr* /dev/vd* 2>/dev/null
  echo
  exec /bin/sh
fi

echo "Found StrayOS media: $FOUND"
mount -t squashfs -o ro /media/strayos/rootfs.squashfs /ro
if [ "$?" -ne 0 ]; then
  echo "ERROR: cannot mount rootfs.squashfs"
  exec /bin/sh
fi

mount -t tmpfs -o size=1024m tmpfs /overlay
mkdir -p /overlay/upper /overlay/work
mount -t overlay overlay -o lowerdir=/ro,upperdir=/overlay/upper,workdir=/overlay/work /newroot
if [ "$?" -ne 0 ]; then
  echo "ERROR: overlay mount failed. Falling back to read-only root."
  mount --move /ro /newroot
fi

mkdir -p /newroot/proc /newroot/sys /newroot/dev /newroot/run /newroot/tmp /newroot/media/strayos
mount --move /proc /newroot/proc
mount --move /sys /newroot/sys
mount --move /dev /newroot/dev
mount --move /media /newroot/media/strayos

echo "Starting StrayOS..."
exec switch_root /newroot /init
echo "ERROR: switch_root failed"
exec /bin/sh
INIT
chmod +x "$INITRAMFS_DIR/init"

(cd "$INITRAMFS_DIR" && find . -print0 | cpio --null -o --format=newc | gzip -9) > "$BUILD_DIR/live-initramfs.cpio.gz"

echo "Building rootfs.squashfs from StrayOS image..."
if mountpoint -q "$ROOT_MOUNT"; then
  sudo umount "$ROOT_MOUNT"
fi
sudo mount -o loop,ro "$SOURCE_IMG" "$ROOT_MOUNT"
cleanup() {
  if mountpoint -q "$ROOT_MOUNT"; then sudo umount "$ROOT_MOUNT"; fi
}
trap cleanup EXIT

rm -rf "$ISO_TREE"
mkdir -p "$ISO_TREE/boot/grub" "$ISO_TREE/strayos"
cp "$KERNEL_OUT" "$ISO_TREE/strayos/vmlinuz"
cp "$BUILD_DIR/live-initramfs.cpio.gz" "$ISO_TREE/strayos/initramfs.cpio.gz"

sudo mksquashfs "$ROOT_MOUNT" "$ISO_TREE/strayos/rootfs.squashfs" \
  -noappend \
  -comp gzip \
  -wildcards \
  -e dev proc sys run tmp mnt media lost+found 'var/cache/apt/archives/*.deb' \
  2>&1 | tee "$LOG_DIR/live-4gb-mksquashfs.log"

cat > "$ISO_TREE/boot/grub/grub.cfg" <<'EOF'
set timeout=5
set default=0

menuentry "StrayOS live 4GB RAM" {
    linux /strayos/vmlinuz init=/init console=tty0 nomodeset panic=0
    initrd /strayos/initramfs.cpio.gz
}

menuentry "StrayOS live debug" {
    linux /strayos/vmlinuz init=/init console=tty0 ignore_loglevel nomodeset panic=0
    initrd /strayos/initramfs.cpio.gz
}
EOF

cat > "$ISO_TREE/README.txt" <<'EOF'
StrayOS live ISO for 4GB RAM.

This ISO keeps the StrayOS base on the USB media instead of loading the full OS
into RAM. Use Rufus DD mode if asked.
EOF

grub-mkrescue -o "$ISO_PATH" "$ISO_TREE" 2>&1 | tee "$LOG_DIR/live-4gb-grub-mkrescue.log"
sha256sum "$ISO_PATH" > "$ISO_PATH.sha256"

cleanup
trap - EXIT

ls -lh "$ISO_PATH" "$ISO_PATH.sha256" "$ISO_TREE/strayos/rootfs.squashfs" "$ISO_TREE/strayos/initramfs.cpio.gz" "$ISO_TREE/strayos/vmlinuz"
echo "Built low-RAM StrayOS live ISO: $ISO_PATH"
