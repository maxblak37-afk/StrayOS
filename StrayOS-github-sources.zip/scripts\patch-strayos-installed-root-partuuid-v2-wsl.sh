#!/usr/bin/env bash
set -euo pipefail

images=(
  /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img
  /mnt/f/StrayOS/disks/strayos-5g.img
)

rewrite_installer() {
  local file="$1" tmp
  tmp="$(mktemp)"
  awk '
    /^write_installed_config\(\) \{/ {
      print "write_installed_config() {"
      print "  local target=\"$1\" uuid partuuid boot_disk=\"$2\" install_grub=\"$3\""
      print "  uuid=\"$(blkid -s UUID -o value \"$TARGET_PARTITION\")\""
      print "  partuuid=\"$(blkid -s PARTUUID -o value \"$TARGET_PARTITION\" 2>/dev/null || true)\""
      print "  [[ -n \"$uuid\" ]] || die \"Could not read UUID for $TARGET_PARTITION.\""
      print "  [[ -n \"$partuuid\" ]] || die \"Could not read PARTUUID for $TARGET_PARTITION. Install to a real partition, not a raw whole device.\""
      print ""
      print "  cat > \"$target/etc/fstab\" <<EOF_FSTAB"
      print "UUID=$uuid / ext4 defaults 0 1"
      print "proc /proc proc defaults 0 0"
      print "sysfs /sys sysfs defaults 0 0"
      print "devpts /dev/pts devpts defaults 0 0"
      print "tmpfs /tmp tmpfs mode=1777 0 0"
      print "EOF_FSTAB"
      print ""
      print "  cat > \"$target/etc/hostname\" <<'\''EOF_HOSTNAME'\''"
      print "strayos"
      print "EOF_HOSTNAME"
      print ""
      print "  cat > \"$target/etc/hosts\" <<'\''EOF_HOSTS'\''"
      print "127.0.0.1 localhost"
      print "127.0.1.1 strayos"
      print "EOF_HOSTS"
      print ""
      print "  mkdir -p \"$target/boot/grub\""
      print "  cat > \"$target/boot/grub/grub.cfg\" <<EOF_GRUB"
      print "set timeout=7"
      print "set default=0"
      print ""
      print "insmod part_msdos"
      print "insmod part_gpt"
      print "insmod ext2"
      print "search --no-floppy --fs-uuid --set=root $uuid"
      print ""
      print "menuentry \"StrayOS\" {"
      print "    search --no-floppy --fs-uuid --set=root $uuid"
      print "    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=15 init=/init console=tty0 nomodeset panic=0"
      print "}"
      print ""
      print "menuentry \"StrayOS hardware graphics (experimental)\" {"
      print "    search --no-floppy --fs-uuid --set=root $uuid"
      print "    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=15 init=/init console=tty0 panic=0"
      print "}"
      print ""
      print "menuentry \"StrayOS debug console\" {"
      print "    search --no-floppy --fs-uuid --set=root $uuid"
      print "    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=15 init=/init console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel"
      print "}"
      print "EOF_GRUB"
      print ""
      print "  if [[ \"$install_grub\" == \"yes\" ]]; then"
      print "    [[ -n \"$boot_disk\" ]] || die \"No boot disk selected for GRUB.\""
      print "    say \"Installing GRUB to $boot_disk\""
      print "    run grub-install --target=i386-pc --boot-directory=\"$target/boot\" --recheck \"$boot_disk\""
      print "  else"
      print "    say \"Skipped GRUB install. Boot files are in $target/boot.\""
      print "  fi"
      print "}"
      skip=1
      next
    }
    /^finish_install\(\) \{/ { skip=0 }
    !skip { print }
  ' "$file" > "$tmp"
  sudo cp "$tmp" "$file"
  rm -f "$tmp"
}

rewrite_repair() {
  local file="$1" tmp
  [[ -f "$file" ]] || return 0
  tmp="$(mktemp)"
  awk '
    /^write_grub_cfg\(\) \{/ {
      print "write_grub_cfg() {"
      print "  local target=\"$1\" root_part=\"$2\" uuid partuuid"
      print "  uuid=\"$(blkid -s UUID -o value \"$root_part\")\""
      print "  partuuid=\"$(blkid -s PARTUUID -o value \"$root_part\" 2>/dev/null || true)\""
      print "  [[ -n \"$uuid\" ]] || die \"Could not read UUID for $root_part.\""
      print "  [[ -n \"$partuuid\" ]] || die \"Could not read PARTUUID for $root_part. Pick the installed StrayOS partition, for example /dev/sda1.\""
      print ""
      print "  mkdir -p \"$target/boot/grub\""
      print "  cat > \"$target/boot/grub/grub.cfg\" <<EOF_GRUB"
      print "set timeout=7"
      print "set default=0"
      print ""
      print "insmod part_msdos"
      print "insmod part_gpt"
      print "insmod ext2"
      print "search --no-floppy --fs-uuid --set=root $uuid"
      print ""
      print "menuentry \"StrayOS\" {"
      print "    search --no-floppy --fs-uuid --set=root $uuid"
      print "    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=15 init=/init console=tty0 nomodeset panic=0"
      print "}"
      print ""
      print "menuentry \"StrayOS hardware graphics (experimental)\" {"
      print "    search --no-floppy --fs-uuid --set=root $uuid"
      print "    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=15 init=/init console=tty0 panic=0"
      print "}"
      print ""
      print "menuentry \"StrayOS debug console\" {"
      print "    search --no-floppy --fs-uuid --set=root $uuid"
      print "    linux /boot/vmlinuz-strayos root=PARTUUID=$partuuid rw rootwait rootdelay=15 init=/init console=ttyS0 console=tty0 nomodeset panic=0 ignore_loglevel"
      print "}"
      print "EOF_GRUB"
      print ""
      print "  cat > \"$target/etc/fstab\" <<EOF_FSTAB"
      print "UUID=$uuid / ext4 defaults 0 1"
      print "proc /proc proc defaults 0 0"
      print "sysfs /sys sysfs defaults 0 0"
      print "devpts /dev/pts devpts defaults 0 0"
      print "tmpfs /tmp tmpfs mode=1777 0 0"
      print "/swapfile none swap sw 0 0"
      print "EOF_FSTAB"
      print ""
      print "  echo \"Root UUID: $uuid\""
      print "  echo \"Root PARTUUID: $partuuid\""
      print "}"
      skip=1
      next
    }
    /^main\(\) \{/ { skip=0 }
    !skip { print }
  ' "$file" > "$tmp"
  sudo cp "$tmp" "$file"
  rm -f "$tmp"
}

patch_image() {
  local image="$1" mount_dir loop_dev part
  mount_dir="/tmp/strayos-partuuid-v2-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"
  sudo mount "$part" "$mount_dir"

  rewrite_installer "$mount_dir/usr/local/sbin/strayos-install"
  rewrite_repair "$mount_dir/usr/local/sbin/strayos-repair-boot"

  sudo bash -n "$mount_dir/usr/local/sbin/strayos-install"
  sudo bash -n "$mount_dir/usr/local/sbin/strayos-repair-boot"
  ! sudo grep -q 'root=UUID=' "$mount_dir/usr/local/sbin/strayos-install"
  ! sudo grep -q 'root=UUID=' "$mount_dir/usr/local/sbin/strayos-repair-boot"
  sudo grep -q 'root=PARTUUID=$partuuid' "$mount_dir/usr/local/sbin/strayos-install"
  sudo grep -q 'root=PARTUUID=$partuuid' "$mount_dir/usr/local/sbin/strayos-repair-boot"

  sudo sync
  cleanup
  trap - RETURN
}

for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img > /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img.sha256
sha256sum /mnt/f/StrayOS/disks/strayos-5g.img > /mnt/f/StrayOS/disks/strayos-5g.img.sha256

echo "Patched installed StrayOS boot root to PARTUUID (v2)."
