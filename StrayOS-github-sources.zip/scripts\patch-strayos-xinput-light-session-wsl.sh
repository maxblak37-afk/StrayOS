#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
BOOT_IMG="${BOOT_IMG:-$PROJECT_DIR/disks/StrayOS-bootable-5g.img}"
SOURCE_IMG="${SOURCE_IMG:-$PROJECT_DIR/disks/strayos-5g.img}"

patch_one() {
  local image="$1" mount_dir="$2" loop_dev part

  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup_one() {
    if mountpoint -q "$mount_dir/dev"; then sudo umount "$mount_dir/dev"; fi
    if mountpoint -q "$mount_dir/proc"; then sudo umount "$mount_dir/proc"; fi
    if mountpoint -q "$mount_dir/sys"; then sudo umount "$mount_dir/sys"; fi
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup_one RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi

  sudo mount "$part" "$mount_dir"
  sudo mkdir -p "$mount_dir/usr/local/bin" "$mount_dir/usr/local/sbin" "$mount_dir/etc/X11/xorg.conf.d"

  sudo mount --bind /dev "$mount_dir/dev"
  sudo mount -t proc proc "$mount_dir/proc"
  sudo mount -t sysfs sysfs "$mount_dir/sys"
  sudo cp /etc/resolv.conf "$mount_dir/etc/resolv.conf"
  sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get update
  sudo chroot "$mount_dir" env DEBIAN_FRONTEND=noninteractive apt-get install -y \
    udev \
    xserver-xorg-input-evdev \
    xserver-xorg-input-libinput \
    openbox \
    xterm \
    x11-xserver-utils \
    x11-utils

  cat <<'EOF' | sudo tee "$mount_dir/etc/X11/xorg.conf.d/20-strayos-input.conf" >/dev/null
Section "InputClass"
    Identifier "StrayOS keyboard evdev"
    MatchIsKeyboard "on"
    Driver "evdev"
EndSection

Section "InputClass"
    Identifier "StrayOS pointer evdev"
    MatchIsPointer "on"
    Driver "evdev"
EndSection
EOF

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/sbin/strayos-start-udev" >/dev/null
#!/bin/sh
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
mkdir -p /dev/pts /run /run/udev
mount -t devpts devpts /dev/pts 2>/dev/null || true

if [ -x /lib/systemd/systemd-udevd ]; then
  /lib/systemd/systemd-udevd --daemon 2>/dev/null || true
elif [ -x /sbin/udevd ]; then
  /sbin/udevd --daemon 2>/dev/null || true
fi

udevadm trigger --action=add 2>/dev/null || true
udevadm settle --timeout=10 2>/dev/null || true
EOF
  sudo chmod +x "$mount_dir/usr/local/sbin/strayos-start-udev"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-light-session" >/dev/null
#!/bin/sh
export LIBGL_ALWAYS_SOFTWARE=1
export XDG_SESSION_TYPE=x11
xsetroot -solid '#202020' 2>/dev/null || true
openbox >/tmp/strayos-openbox.log 2>&1 &
sleep 1
xterm -fa Monospace -fs 12 -geometry 100x30+40+40 -title "StrayOS Xorg test" -e /bin/bash -lc 'echo "StrayOS lightweight X session"; echo; echo "Keyboard test: type commands here."; echo "Try: neofetch"; echo "Exit closes X."; echo; exec /bin/bash -l'
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-light-session"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-light" >/dev/null
#!/bin/sh
swapon /swapfile 2>/dev/null || true
strayos-start-udev
mkdir -p /run/dbus /run/user/0 /tmp
chmod 700 /run/user/0 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true

echo "Starting lightweight StrayOS desktop..."
echo "This is lighter than GNOME and checks Xorg/input stability."
exec dbus-run-session -- startx /usr/local/bin/strayos-light-session -- :0 vt2 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-light"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-xterm-test" >/dev/null
#!/bin/sh
exec strayos-light
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-xterm-test"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-gnome-safe" >/dev/null
#!/bin/sh
export LIBGL_ALWAYS_SOFTWARE=1
export MUTTER_DEBUG_DISABLE_HW_CURSORS=1
export CLUTTER_VBLANK=none
export GSK_RENDERER=cairo
export XDG_SESSION_TYPE=x11
export XDG_CURRENT_DESKTOP=GNOME
export GDMSESSION=gnome

swapon /swapfile 2>/dev/null || true
strayos-start-udev
mkdir -p /run/dbus /run/user/0 /tmp
chmod 700 /run/user/0 2>/dev/null || true
dbus-daemon --system --fork 2>/dev/null || true

gsettings set org.gnome.desktop.interface enable-animations false 2>/dev/null || true
gsettings set org.gnome.mutter experimental-features "[]" 2>/dev/null || true
gnome-extensions disable dash-to-dock@micxgx.gmail.com 2>/dev/null || true
gnome-extensions disable ubuntu-dock@ubuntu.com 2>/dev/null || true

echo "Starting StrayOS GNOME safe mode..."
echo "If this freezes, use: strayos-light"
exec dbus-run-session -- startx /root/.xinitrc -- :0 vt2 -keeptty
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-gnome-safe"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-diag" >/dev/null
#!/bin/sh
echo "--- cmdline ---"
cat /proc/cmdline
echo "--- memory ---"
free -h 2>/dev/null || true
echo "--- swap ---"
swapon --show 2>/dev/null || cat /proc/swaps
echo "--- drm/fb/input devices ---"
ls -l /dev/dri /dev/fb* /dev/input 2>/dev/null || true
echo "--- pci vga ---"
lspci 2>/dev/null | grep -Ei 'vga|3d|display' || true
echo "--- last Xorg errors ---"
grep -E 'EE|WW|No screens|Failed|failed' /var/log/Xorg.0.log 2>/dev/null | tail -80 || true
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-diag"

  if ! grep -q 'echo "  strayos-light"' "$mount_dir/init"; then
    sudo sed -i '/echo "  strayos-xterm-test"/a echo "  strayos-light"\
echo "  strayos-diag"' "$mount_dir/init"
  fi

  sudo sync
  cleanup_one
  trap - RETURN
}

patch_one "$BOOT_IMG" /tmp/strayos-xinput-light-boot
patch_one "$SOURCE_IMG" /tmp/strayos-xinput-light-source

sha256sum "$BOOT_IMG" > "$BOOT_IMG.sha256"
echo "Patched Xorg input and lightweight session."
echo "Updated: $BOOT_IMG"
