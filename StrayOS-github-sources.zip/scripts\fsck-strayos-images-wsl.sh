#!/usr/bin/env bash
set -euo pipefail

for img in /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img /mnt/f/StrayOS/disks/strayos-5g.img; do
  echo "Checking $img"
  loop_dev="$(sudo losetup --find --show --partscan "$img")"
  cleanup() {
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  if [[ ! -b "$part" ]]; then
    part="$loop_dev"
  fi

  sudo e2fsck -fy "$part"
  cleanup
  trap - RETURN
done
