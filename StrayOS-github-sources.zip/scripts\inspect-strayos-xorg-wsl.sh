#!/usr/bin/env bash
set -euo pipefail

IMAGE="${IMAGE:-/mnt/f/StrayOS/disks/strayos-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-xorg-inspect}"

sudo mkdir -p "$MOUNT_DIR"
if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi
sudo mount -o loop,ro "$IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
}
trap cleanup EXIT

echo "--- strayos-gnome ---"
sudo sed -n '1,220p' "$MOUNT_DIR/usr/local/bin/strayos-gnome" 2>/dev/null || true
sudo sed -n '1,220p' "$MOUNT_DIR/usr/local/sbin/strayos-gnome" 2>/dev/null || true

echo "--- xorg configs ---"
sudo find "$MOUNT_DIR/etc/X11" -maxdepth 4 -type f -print -exec sed -n '1,160p' {} \; 2>/dev/null || true

echo "--- xorg packages ---"
sudo chroot "$MOUNT_DIR" sh -lc 'dpkg-query -W -f="${binary:Package} ${Version}\n" xserver-xorg-core xserver-xorg-video-fbdev xserver-xorg-video-vesa xserver-xorg-video-all xinit dbus-x11 gnome-session gnome-shell mutter 2>/dev/null || true'
