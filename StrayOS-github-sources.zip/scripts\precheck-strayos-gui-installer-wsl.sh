#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-pre-gui-check}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

echo "--- grub ---"
sudo sed -n '1,120p' "$MOUNT_DIR/boot/grub/grub.cfg"

echo "--- commands ---"
sudo chroot "$MOUNT_DIR" sh -lc '
for c in zenity openbox xterm strayos-install strayos-light; do
  printf "%-22s " "$c"
  command -v "$c" || true
done
'

echo "--- packages ---"
sudo chroot "$MOUNT_DIR" sh -lc 'dpkg-query -W -f="${binary:Package} ${Status}\n" zenity 2>/dev/null || true'
