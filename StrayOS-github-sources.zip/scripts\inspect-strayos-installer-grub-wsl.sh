#!/usr/bin/env bash
set -euo pipefail

IMG="${IMG:-/mnt/f/StrayOS/disks/StrayOS-bootable-5g.img}"
MOUNT_DIR="${MOUNT_DIR:-/tmp/strayos-installer-debug}"

sudo mkdir -p "$MOUNT_DIR"
LOOP_DEV="$(sudo losetup --find --show --partscan "$IMG")"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then sudo umount "$MOUNT_DIR"; fi
  if [[ -n "${LOOP_DEV:-}" ]]; then sudo losetup -d "$LOOP_DEV" || true; fi
}
trap cleanup EXIT

sudo mount "${LOOP_DEV}p1" "$MOUNT_DIR"

echo "--- installer grub parts ---"
sudo grep -nE 'grub-install|grub.cfg|root=UUID|PARTUUID|write_installed_config|copy_system' "$MOUNT_DIR/usr/local/sbin/strayos-install" || true

echo "--- installer snippet ---"
sudo sed -n '130,260p' "$MOUNT_DIR/usr/local/sbin/strayos-install"

echo "--- live grub cfg ---"
sudo sed -n '1,120p' "$MOUNT_DIR/boot/grub/grub.cfg" 2>/dev/null || true
