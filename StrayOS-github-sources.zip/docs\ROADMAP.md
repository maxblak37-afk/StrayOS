# StrayOS Roadmap

## Phase 0 - Decisions

- Choose target architecture: x86_64
- Choose boot path: UEFI
- Choose libc: glibc for compatibility
- Choose init system: start with BusyBox init or sysvinit, decide on systemd later
- Choose packaging model: start with simple build scripts, design packages after boot works
- Choose build host: Linux environment is strongly recommended

## Phase 1 - Build Environment

- Prepare a Linux build host or WSL2
- Install compiler, linker, make tools, file tools, ISO tools, QEMU
- Create a clean build user and predictable build directories
- Download and checksum upstream source archives

## Phase 2 - Cross Toolchain

- Build binutils for the target
- Build a temporary GCC cross-compiler
- Install Linux kernel headers
- Build glibc
- Rebuild GCC with libc support

## Phase 3 - Temporary Userland

- Build core tools needed to compile the final system
- Build shell, make, sed, grep, awk, tar, gzip, xz, perl, python or minimal substitutes
- Enter an isolated build environment

## Phase 4 - Final Base System

- Build kernel
- Build libc, compiler runtime, shell, core utilities, filesystem tools, networking tools
- Create `/etc`, users, groups, init scripts, device handling, mounts
- Assemble `rootfs`

## Phase 5 - Bootable Image

- Add bootloader
- Add initramfs if needed
- Generate an ISO image
- Boot in QEMU
- Fix boot logs until the system reaches a shell

## Phase 6 - Distribution Layer

- Define package format
- Define package database
- Build binary packages
- Create local repository metadata
- Add upgrade/install/remove commands

## Phase 7 - Installer and Profiles

- Create installer flow
- Add disk partitioning
- Add base profile
- Add optional desktop profile
- Produce versioned StrayOS release ISOs

## First Concrete Milestone

Boot `StrayOS` in QEMU and reach:

```text
strayos login:
```

or a root shell:

```text
sh-5.x#
```
