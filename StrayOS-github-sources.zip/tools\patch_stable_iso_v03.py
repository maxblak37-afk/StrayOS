#!/usr/bin/env python3
import gzip
import hashlib
import io
import pathlib
import re
import struct
import time


ROOT = pathlib.Path(r"F:\StrayOS")
BASE_ISO = ROOT / "iso" / "StrayOS-full-amd64-before-v0.2-tools.iso"
OUT_ISO = ROOT / "iso" / "StrayOS-full-amd64-v0.3-root.iso"
MAIN_ISO = ROOT / "iso" / "StrayOS-full-amd64.iso"


SERVER = "78.17.6.198"
LINKS = [
    f"http://{SERVER}/strayos/updates/manifest.json",
    f"http://{SERVER}/strayos/updates/latest.txt",
    f"http://{SERVER}/strayos/updates/StrayOS-full-amd64.iso.sha256",
    f"http://{SERVER}/strayos/apt/",
    f"http://{SERVER}/strayos/releases/",
]


def pad4(data: bytes) -> bytes:
    return data + b"\0" * ((4 - len(data) % 4) % 4)


def read_cpio(blob: bytes):
    out = []
    pos = 0
    while pos < len(blob):
        if blob[pos:pos + 6] not in (b"070701", b"070702"):
            raise RuntimeError(f"Bad cpio magic at {pos}")
        header = blob[pos:pos + 110]
        vals = [int(header[i:i + 8], 16) for i in range(6, 110, 8)]
        size, namesize = vals[6], vals[11]
        pos += 110
        name = blob[pos:pos + namesize - 1].decode("utf-8", "replace")
        pos += namesize
        pos = (pos + 3) & ~3
        data = blob[pos:pos + size]
        pos += size
        pos = (pos + 3) & ~3
        out.append({"name": name, "vals": vals, "data": data})
        if name == "TRAILER!!!":
            break
    return out


def write_cpio(entries):
    data = bytearray()
    for e in entries:
        vals = e["vals"][:]
        vals[6] = len(e["data"])
        name_b = e["name"].encode() + b"\0"
        vals[11] = len(name_b)
        data += pad4(b"070701" + b"".join(f"{v:08x}".encode() for v in vals) + name_b)
        data += pad4(e["data"])
    return bytes(data)


def add_entry(entries, name, mode, data=b""):
    ino = 60000 + len(entries)
    entries[:] = [e for e in entries if e["name"] != name]
    entries.append({
        "name": name,
        "vals": [ino, mode, 0, 0, 1, int(time.time()), len(data), 0, 0, 0, 0, len(name) + 1, 0],
        "data": data,
    })


def compact_apps():
    info = f'''#!/bin/sh
zenity --info --title='StrayOS' --width=420 --text="StrayOS 0.3
User: root
Kernel: $(uname -r)
Update: {SERVER}" 2>/dev/null||uname -a
'''
    updater = f'''#!/bin/sh
echo 'Обновление системы (ip:{SERVER})'
zenity --question --title='Update {SERVER}' --text='APT update?'||exit
(apt-get update 2>&1|sed 's/^/# /')|zenity --progress --pulsate --auto-close --title='APT update'
'''
    manager = r'''#!/bin/sh
while true; do
 a=$(zenity --list --title='Packages' --width=430 --height=230 --column='Action' 'Search' 'APT update' 'Exit')||exit
 [ "$a" = Exit ]&&exit
 [ "$a" = 'APT update' ]&&{ (apt-get update 2>&1|sed 's/^/# /')|zenity --progress --pulsate --auto-close --title='APT update';continue; }
 q=$(zenity --entry --title='APT search' --text='Package:')||continue
 [ -z "$q" ]&&continue
 p=$(apt-cache search --names-only "$q"|head -80|sed 's/ - /\t/'|zenity --list --width=860 --height=500 --title='Results' --column='Package' --column='Description' --print-column=1)||continue
 [ -n "$p" ]&&zenity --question --text="Install $p?"&&(apt-get install -y "$p" 2>&1|sed 's/^/# /')|zenity --progress --pulsate --auto-close --title="$p"
done
'''
    migrate = r'''#!/bin/sh
set +e
base="${1:-}"
[ -n "$base" ] && cd "$base" || cd /
for f in etc/passwd etc/shadow etc/group etc/gshadow; do
 [ -f "$f" ] || continue
 sed -i '/^stray:/d;s/,stray//g;s/:stray$/:/;s/:stray,/:/' "$f"
done
rm -rf home/stray var/lib/AccountsService/users/stray
mkdir -p root etc/lightdm/lightdm.conf.d
cat > etc/lightdm/lightdm.conf.d/60-strayos-root.conf <<'EOF'
[Seat:*]
autologin-user=root
autologin-user-timeout=0
user-session=strayos-gnome
EOF
'''
    root_init = r'''#!/bin/sh
sed -i 's/stray \/ stray/root \/ root/g;s/autologin-user=stray/autologin-user=root/g' /init.strayos-base;strayos-root-migrate /;exec /init.strayos-base "$@"
'''
    d1 = "[Desktop Entry]\nType=Application\nName=About StrayOS\nExec=strayos-system-info\nTerminal=false\nCategories=System;\n"
    d2 = "[Desktop Entry]\nType=Application\nName=System Update\nName[ru]=Обновление системы\nExec=strayos-updater\nTerminal=true\nCategories=System;\n"
    d3 = "[Desktop Entry]\nType=Application\nName=StrayOS Package Manager\nName[ru]=Менеджер пакетов StrayOS\nExec=strayos-package-manager\nTerminal=true\nCategories=System;\n"
    d2 = "[Desktop Entry]\nType=Application\nName=System Update\nExec=strayos-updater\nTerminal=false\nCategories=System;\n"
    d3 = "[Desktop Entry]\nType=Application\nName=StrayOS Package Manager\nExec=strayos-package-manager\nTerminal=false\nCategories=System;\n"
    osr = f'NAME=StrayOS\nID=strayos\nPRETTY_NAME="StrayOS 0.3"\nVERSION_ID="0.3"\nVERSION="0.3 GNOME/APT"\nHOME_URL="http://{SERVER}/strayos/"\n'
    lsb = 'DISTRIB_ID=StrayOS\nDISTRIB_RELEASE=0.3\nDISTRIB_CODENAME=gnome\nDISTRIB_DESCRIPTION="StrayOS 0.3"\n'
    files = {
        "strayos-overlay/usr/local/bin/strayos-system-info": (0o100755, info.encode()),
        "strayos-overlay/usr/local/bin/strayos-updater": (0o100755, updater.encode()),
        "strayos-overlay/usr/local/bin/strayos-package-manager": (0o100755, manager.encode()),
        "strayos-overlay/usr/local/sbin/strayos-root-migrate": (0o100755, migrate.encode()),
        "strayos-overlay/init": (0o100755, root_init.encode()),
        "strayos-overlay/etc/lightdm/lightdm.conf.d/60-strayos-root.conf": (0o100644, b"[Seat:*]\nautologin-user=root\nautologin-user-timeout=0\nuser-session=strayos-gnome\n"),
        "strayos-overlay/usr/share/applications/strayos-updater.desktop": (0o100644, d2.encode()),
        "strayos-overlay/usr/share/applications/strayos-package-manager.desktop": (0o100644, d3.encode()),
        "strayos-overlay/etc/os-release": (0o100644, osr.encode()),
        "strayos-overlay/etc/lsb-release": (0o100644, lsb.encode()),
    }
    dirs = set()
    for name in files:
        parts = name.split("/")[:-1]
        for i in range(1, len(parts) + 1):
            dirs.add("/".join(parts[:i]))
    return dirs, files


def inject_init(text):
    text = re.sub(
        r"\n# StrayOS v0\.[0-9]+ live feature overlay\nif \[ -d /strayos-overlay \]; then\n.*?fi\n\n",
        "\n",
        text,
        flags=re.S,
    )
    marker = "# StrayOS v0.3 live feature overlay"
    block = f"""\n{marker}
if [ -d /strayos-overlay ]; then
  echo "Applying StrayOS v0.3 feature overlay..."
  [ -f /newroot/init ] && [ ! -f /newroot/init.strayos-base ] && /bin/busybox mv /newroot/init /newroot/init.strayos-base 2>/dev/null || true
  /bin/busybox cp -a /strayos-overlay/. /newroot/ 2>/dev/null || true
  /bin/busybox chmod 755 /newroot/usr/local/bin/strayos-* 2>/dev/null || true
  /bin/busybox chmod 755 /newroot/usr/local/sbin/strayos-root-migrate 2>/dev/null || true
  /bin/busybox chmod 755 /newroot/init 2>/dev/null || true
  [ -x /newroot/usr/local/sbin/strayos-root-migrate ] && /newroot/usr/local/sbin/strayos-root-migrate /newroot 2>/dev/null || true
fi
\n"""
    text = re.sub(
        r'for dev in /dev/sr0 /dev/sr1 /dev/sd\* /dev/hd\* /dev/vd\*; do',
        'for dev in /dev/sr* /dev/cdrom /dev/disk/by-label/* /dev/sd* /dev/hd* /dev/vd*; do',
        text,
    )
    text = re.sub(
        r'umount /media 2>/dev/null \|\| true\n    mount -o ro "\$dev" /media 2>/dev/null \|\| continue',
        'umount /media 2>/dev/null || true\n    mount -t iso9660 -o ro "$dev" /media 2>/dev/null || mount -o ro "$dev" /media 2>/dev/null || continue',
        text,
    )
    text = text.replace(
        'echo "Available block devices:"\n  ls -l /dev/sd* /dev/sr* /dev/vd* 2>/dev/null\n  echo\n  exec /bin/sh',
        'echo "Available block devices:"\n  ls -l /dev/sd* /dev/sr* /dev/vd* /dev/disk/by-label/* 2>/dev/null\n  echo "Emergency shell. Type: ls /dev ; mount -t iso9660 /dev/sr0 /media"\n  while true; do /bin/sh; sleep 1; done',
    )
    text = text.replace(
        'echo "ERROR: cannot mount rootfs.squashfs"\n  exec /bin/sh',
        'echo "ERROR: cannot mount rootfs.squashfs"\n  while true; do /bin/sh; sleep 1; done',
    )
    text = text.replace(
        'echo "ERROR: overlay mount failed. Falling back to read-only root."\n  mount --move /ro /newroot',
        'echo "ERROR: overlay mount failed. Falling back to read-only root."\n  mkdir -p /newroot\n  mount --move /ro /newroot',
    )
    text = text.replace(
        'echo "ERROR: switch_root failed"\nexec /bin/sh',
        'echo "ERROR: switch_root failed"\nwhile true; do /bin/sh; sleep 1; done',
    )
    needle = "mkdir -p /newroot/proc /newroot/sys /newroot/dev /newroot/run /newroot/tmp /newroot/media/strayos\n"
    if needle not in text:
        raise RuntimeError("init injection point not found")
    return text.replace(needle, block + needle)


def rr_name(dr):
    namelen = dr[32]
    pos = 33 + namelen
    if pos % 2:
        pos += 1
    parts = []
    while pos + 4 <= len(dr):
        sig, ln = dr[pos:pos + 2], dr[pos + 2]
        if ln < 4 or pos + ln > len(dr):
            break
        body = dr[pos + 4:pos + ln]
        if sig == b"NM" and body:
            parts.append(body[1:].decode("utf-8", "replace"))
        pos += ln
    return "".join(parts) if parts else None


def parse_dr(dr):
    lba = struct.unpack_from("<I", dr, 2)[0]
    size = struct.unpack_from("<I", dr, 10)[0]
    flags = dr[25]
    namelen = dr[32]
    raw = dr[33:33 + namelen]
    if raw == b"\0":
        name = "."
    elif raw == b"\1":
        name = ".."
    else:
        name = raw.decode("ascii", "replace").split(";")[0]
    return rr_name(dr) or name, lba, size, flags


def walk_iso_records(f, wanted=None):
    found = []
    f.seek(16 * 2048)
    pvd = f.read(2048)
    _, root_lba, root_size, _ = parse_dr(pvd[156:156 + pvd[156]])

    def walk(path, lba, size, seen):
        if (lba, size) in seen:
            return
        seen.add((lba, size))
        f.seek(lba * 2048)
        data = f.read(size)
        pos = 0
        while pos < len(data):
            ln = data[pos]
            if ln == 0:
                pos = ((pos // 2048) + 1) * 2048
                continue
            dr_pos = lba * 2048 + pos
            dr = data[pos:pos + ln]
            name, elba, esize, flags = parse_dr(dr)
            if name not in (".", ".."):
                full = (path + "/" + name).replace("//", "/")
                if wanted is None or full == wanted:
                    found.append((full, dr_pos, elba, esize, flags))
                if flags & 2:
                    walk(full, elba, esize, seen)
            pos += ln

    walk("", root_lba, root_size, set())
    return found


def find_iso_file(iso, wanted):
    with iso.open("rb") as f:
        matches = walk_iso_records(f, wanted)
        if not matches:
            raise RuntimeError(f"{wanted} not found")
        _, _, lba, size, _ = matches[0]
        return lba, size


def patch_iso_record(f, wanted, new_lba, new_size):
    matches = walk_iso_records(f, wanted)
    if not matches:
        raise RuntimeError(f"{wanted} not found for patch")
    for _, dr_pos, _, _, _ in matches:
        f.seek(dr_pos + 2)
        f.write(struct.pack("<I", new_lba))
        f.write(struct.pack(">I", new_lba))
        f.seek(dr_pos + 10)
        f.write(struct.pack("<I", new_size))
        f.write(struct.pack(">I", new_size))


def patch_volume_size(f, sectors):
    for sector in range(16, 64):
        f.seek(sector * 2048)
        vd = f.read(2048)
        if vd[1:6] != b"CD001":
            continue
        if vd[0] == 1:
            f.seek(sector * 2048 + 80)
            f.write(struct.pack("<I", sectors))
            f.write(struct.pack(">I", sectors))
        if vd[0] == 255:
            break


def old_find_iso_file_unused(iso, wanted):
    with iso.open("rb") as f:
        f.seek(16 * 2048)
        pvd = f.read(2048)
        _, root_lba, root_size, _ = parse_dr(pvd[156:156 + pvd[156]])

        def walk(path, lba, size, seen):
            if (lba, size) in seen:
                return None
            seen.add((lba, size))
            f.seek(lba * 2048)
            data = f.read(size)
            pos = 0
            while pos < len(data):
                ln = data[pos]
                if ln == 0:
                    pos = ((pos // 2048) + 1) * 2048
                    continue
                dr = data[pos:pos + ln]
                name, elba, esize, flags = parse_dr(dr)
                if name not in (".", ".."):
                    full = (path + "/" + name).replace("//", "/")
                    if full == wanted:
                        return elba, esize
                    if flags & 2:
                        got = walk(full, elba, esize, seen)
                        if got:
                            return got
                pos += ln
            return None

        got = walk("", root_lba, root_size, set())
        if not got:
            raise RuntimeError(f"{wanted} not found")
        return got


def build_initramfs(old_gz):
    raw = gzip.decompress(old_gz)
    entries = [e for e in read_cpio(raw) if e["name"] != "TRAILER!!!"]
    for e in entries:
        if e["name"] == "init":
            e["data"] = inject_init(e["data"].decode()).encode()
            break
    else:
        raise RuntimeError("init not found")
    dirs, files = compact_apps()
    existing = {e["name"] for e in entries}
    for d in sorted(dirs, key=lambda x: (x.count("/"), x)):
        if d not in existing:
            add_entry(entries, d, 0o40755)
    for name, (mode, data) in files.items():
        add_entry(entries, name, mode, data)
    add_entry(entries, "TRAILER!!!", 0)
    bio = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=bio, compresslevel=9, mtime=0) as gz:
        gz.write(write_cpio(entries))
    return bio.getvalue()


def main():
    OUT_ISO.write_bytes(BASE_ISO.read_bytes())
    lba, old_size = find_iso_file(OUT_ISO, "/strayos/initramfs.cpio.gz")
    with OUT_ISO.open("r+b") as f:
        f.seek(lba * 2048)
        old_gz = f.read(old_size)
        new_gz = build_initramfs(old_gz)
        print(f"initramfs old={old_size} new={len(new_gz)} lba={lba}")
        max_size = ((old_size + 2047) // 2048) * 2048
        if len(new_gz) > max_size:
            raise RuntimeError(f"compact initramfs is still too large for in-place patch: {len(new_gz)} > {max_size}")
        f.seek(lba * 2048)
        f.write(new_gz)
        f.write(b"\0" * (max_size - len(new_gz)))
        if len(new_gz) != old_size:
            patch_iso_record(f, "/strayos/initramfs.cpio.gz", lba, len(new_gz))
        print("patched initramfs in-place")
    digest = hashlib.sha256(OUT_ISO.read_bytes()).hexdigest()
    (OUT_ISO.with_suffix(OUT_ISO.suffix + ".sha256")).write_text(f"{digest}  {OUT_ISO.name}\n", encoding="ascii")
    MAIN_ISO.write_bytes(OUT_ISO.read_bytes())
    (MAIN_ISO.with_suffix(MAIN_ISO.suffix + ".sha256")).write_text(f"{digest}  {MAIN_ISO.name}\n", encoding="ascii")
    print(OUT_ISO)
    print(digest)


if __name__ == "__main__":
    main()
