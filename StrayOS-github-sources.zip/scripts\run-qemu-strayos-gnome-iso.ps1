$ErrorActionPreference = "Stop"

wsl sh -lc "qemu-system-x86_64 -m 4096 -smp 4 -cdrom /mnt/f/StrayOS/iso/StrayOS-GNOME-Ubuntu-jammy-amd64.iso -boot d -display sdl -vga virtio -nic user,model=virtio-net-pci"
