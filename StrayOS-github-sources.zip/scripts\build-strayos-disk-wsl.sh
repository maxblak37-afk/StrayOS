#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/f/StrayOS}"
WORK_DIR="${WORK_DIR:-$HOME/strayos-disk-work}"
ROOTFS="${ROOTFS:-$HOME/strayos-apt-rootfs/rootfs}"
DISK_DIR="$PROJECT_DIR/disks"
OUT_DIR="$PROJECT_DIR/build/disk"
LOG_DIR="$PROJECT_DIR/build/logs"
WORK_IMAGE="$WORK_DIR/strayos-5g.img"
FINAL_IMAGE="$DISK_DIR/strayos-5g.img"
MOUNT_DIR="$WORK_DIR/mnt"

mkdir -p "$WORK_DIR" "$DISK_DIR" "$OUT_DIR" "$LOG_DIR" "$MOUNT_DIR"

if [[ ! -d "$ROOTFS/bin" ]]; then
  echo "Missing rootfs: $ROOTFS" >&2
  echo "Run /mnt/f/StrayOS/scripts/build-apt-rootfs-wsl.sh first." >&2
  exit 1
fi

if mountpoint -q "$MOUNT_DIR"; then
  sudo umount "$MOUNT_DIR"
fi

rm -f "$WORK_IMAGE"
truncate -s 5G "$WORK_IMAGE"
mkfs.ext4 -F -L STRAYOS "$WORK_IMAGE" | tee "$LOG_DIR/strayos-disk-mkfs.log"

sudo mount -o loop "$WORK_IMAGE" "$MOUNT_DIR"
cleanup() {
  if mountpoint -q "$MOUNT_DIR"; then
    sudo umount "$MOUNT_DIR"
  fi
}
trap cleanup EXIT

sudo rsync -aH --numeric-ids --delete "$ROOTFS"/ "$MOUNT_DIR"/

sudo tee "$MOUNT_DIR/etc/os-release" >/dev/null <<'EOF'
NAME=StrayOS
ID=strayos
PRETTY_NAME="StrayOS"
VERSION_ID=0.0.3
ID_LIKE=debian
EOF

sudo tee "$MOUNT_DIR/etc/issue" >/dev/null <<'EOF'
StrayOS 0.0.3 \n \l

EOF

sudo tee "$MOUNT_DIR/etc/fstab" >/dev/null <<'EOF'
LABEL=STRAYOS / ext4 defaults 0 1
proc /proc proc defaults 0 0
sysfs /sys sysfs defaults 0 0
devpts /dev/pts devpts defaults 0 0
tmpfs /tmp tmpfs mode=1777 0 0
EOF

sudo tee "$MOUNT_DIR/init" >/dev/null <<'EOF'
#!/bin/sh
set +e
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TERM=linux

mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /run /tmp /root
mount -t devpts devpts /dev/pts 2>/dev/null
chmod 1777 /tmp
hostname strayos 2>/dev/null

ip link set lo up 2>/dev/null
ip link set eth0 up 2>/dev/null
dhclient -1 eth0 2>/dev/null || true

clear
cat /etc/issue 2>/dev/null
echo "Kernel: $(uname -r)"
echo "Disk: 5 GB persistent ext4 image"
echo
echo "Try: neofetch, apt --version, apt-get update, nano test.txt"
echo "Power off: poweroff -f"
echo

if grep -q 'strayos.autotest=1' /proc/cmdline 2>/dev/null; then
  echo "[autotest] /etc/os-release:"
  cat /etc/os-release
  echo
  echo "[autotest] disk:"
  df -h /
  echo
  echo "[autotest] apt:"
  apt --version
  echo
  echo "[autotest] dpkg packages:"
  dpkg-query -f '${binary:Package}\n' -W | wc -l
  echo
  poweroff -f
fi

cd /root
exec /bin/busybox cttyhack /bin/bash -l
EOF
sudo chmod +x "$MOUNT_DIR/init"

sudo ln -sf busybox "$MOUNT_DIR/bin/poweroff"
sudo ln -sf busybox "$MOUNT_DIR/bin/reboot"

sudo mkdir -p "$MOUNT_DIR/root" "$MOUNT_DIR/var/lib/apt/lists/partial" "$MOUNT_DIR/var/cache/apt/archives/partial"
sudo sync
cleanup
trap - EXIT

cp --sparse=always "$WORK_IMAGE" "$FINAL_IMAGE"

cat > "$OUT_DIR/run-qemu-gui.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"
qemu-system-x86_64 \
  -m 2048M \
  -kernel "$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage" \
  -append "root=/dev/sda rw init=/init console=tty0 nomodeset panic=-1" \
  -drive file="$PROJECT_DIR/disks/strayos-5g.img",format=raw,if=ide,index=0,media=disk \
  -netdev user,id=net0 \
  -device e1000,netdev=net0 \
  -display gtk \
  -vga std \
  -no-reboot
EOF
chmod +x "$OUT_DIR/run-qemu-gui.sh"

cat > "$OUT_DIR/run-qemu-test.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$DIR/../.." && pwd)"
qemu-system-x86_64 \
  -m 2048M \
  -kernel "$PROJECT_DIR/build/full-kernel/strayos-full-source-bzImage" \
  -append "root=/dev/sda rw init=/init console=ttyS0 quiet panic=-1 strayos.autotest=1" \
  -drive file="$PROJECT_DIR/disks/strayos-5g.img",format=raw,if=ide,index=0,media=disk \
  -netdev user,id=net0 \
  -device e1000,netdev=net0 \
  -serial stdio \
  -display none \
  -no-reboot
EOF
chmod +x "$OUT_DIR/run-qemu-test.sh"

cat > "$OUT_DIR/README.md" <<EOF
# StrayOS Persistent Disk

- Disk image: \`$FINAL_IMAGE\`
- Size: 5 GB
- Filesystem: ext4
- OS identity: StrayOS
- Package system: Debian APT/dpkg

Run graphical QEMU from WSL:

\`\`\`sh
cd "$OUT_DIR"
./run-qemu-gui.sh
\`\`\`
EOF

ls -lh "$FINAL_IMAGE"
du -h "$FINAL_IMAGE"
echo "Built StrayOS 5 GB disk at $FINAL_IMAGE"
