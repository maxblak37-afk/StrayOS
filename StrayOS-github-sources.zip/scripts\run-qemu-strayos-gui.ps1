$ErrorActionPreference = "Stop"

wsl sh -lc "cd /mnt/f/StrayOS/build/disk && ./run-qemu-gui.sh"
