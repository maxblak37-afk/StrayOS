#!/usr/bin/env bash
set -euo pipefail

images=(
  /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img
  /mnt/f/StrayOS/disks/strayos-5g.img
)

patch_image() {
  local image="$1" mount_dir loop_dev part
  mount_dir="/tmp/strayos-gnome-reset-$(basename "$image" .img)"
  sudo mkdir -p "$mount_dir"
  loop_dev="$(sudo losetup --find --show --partscan "$image")"
  cleanup() {
    if mountpoint -q "$mount_dir"; then sudo umount "$mount_dir"; fi
    sudo losetup -d "$loop_dev" || true
  }
  trap cleanup RETURN

  part="${loop_dev}p1"
  [[ -b "$part" ]] || part="$loop_dev"
  sudo mount "$part" "$mount_dir"

  cat <<'EOF' | sudo tee "$mount_dir/usr/local/bin/strayos-gnome-reset" >/dev/null
#!/bin/sh
set +e

echo "Stopping stuck GNOME/Xorg processes..."
pkill -TERM gnome-shell gnome-session-binary gnome-session Xorg Xwayland openbox xterm 2>/dev/null
sleep 2
pkill -KILL gnome-shell gnome-session-binary gnome-session Xorg Xwayland openbox xterm 2>/dev/null

echo "Cleaning display locks and crash caches..."
rm -f /tmp/.X0-lock /tmp/.X1-lock /tmp/.X11-unix/X0 /tmp/.X11-unix/X1
rm -rf /tmp/dbus-* /tmp/.ICE-unix /tmp/.font-unix /tmp/.Test-unix
mkdir -p /tmp/.X11-unix /tmp/.ICE-unix /tmp/.font-unix /tmp/.Test-unix
chmod 1777 /tmp /tmp/.X11-unix /tmp/.ICE-unix /tmp/.font-unix /tmp/.Test-unix 2>/dev/null

echo "Resetting root GNOME state..."
rm -f /root/.Xauthority /root/.ICEauthority /root/.xsession-errors /root/.xsession-errors.old
rm -rf /root/.cache/gnome-shell /root/.cache/gstreamer-1.0 /root/.cache/mesa_shader_cache
rm -rf /root/.local/share/gnome-shell /root/.local/share/gvfs-metadata
rm -f /root/.config/monitors.xml
rm -f /root/.config/dconf/user

echo "Rebuilding runtime directories..."
rm -rf /run/user/0
mkdir -p /run/user/0 /run/dbus
chmod 700 /run/user/0
dbus-daemon --system --fork 2>/dev/null || true
strayos-start-udev 2>/dev/null || true
swapon /swapfile 2>/dev/null || true
sync

echo
echo "GNOME reset complete."
echo "Try now:"
echo "  strayos-light"
echo "or:"
echo "  strayos-gnome-safe"
EOF
  sudo chmod +x "$mount_dir/usr/local/bin/strayos-gnome-reset"

  for launcher in "$mount_dir/usr/local/bin/strayos-gnome" "$mount_dir/usr/local/bin/strayos-gnome-safe"; do
    if [[ -f "$launcher" ]] && ! sudo grep -q 'rm -f /tmp/.X0-lock' "$launcher"; then
      sudo sed -i '/dbus-daemon --system --fork/i rm -f /tmp/.X0-lock /tmp/.X1-lock /tmp/.X11-unix/X0 /tmp/.X11-unix/X1\nmkdir -p /tmp/.X11-unix\nchmod 1777 /tmp /tmp/.X11-unix 2>/dev/null || true' "$launcher"
    fi
  done

  if ! sudo grep -q 'echo "  strayos-gnome-reset"' "$mount_dir/init"; then
    sudo sed -i '/echo "  strayos-gnome-safe"/a echo "  strayos-gnome-reset"' "$mount_dir/init" 2>/dev/null || true
  fi

  sudo sh -n "$mount_dir/usr/local/bin/strayos-gnome-reset"
  sudo sync
  cleanup
  trap - RETURN
}

for image in "${images[@]}"; do
  patch_image "$image"
done

sha256sum /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img > /mnt/f/StrayOS/disks/StrayOS-bootable-5g.img.sha256
sha256sum /mnt/f/StrayOS/disks/strayos-5g.img > /mnt/f/StrayOS/disks/strayos-5g.img.sha256
echo "Patched StrayOS GNOME reset helper."
